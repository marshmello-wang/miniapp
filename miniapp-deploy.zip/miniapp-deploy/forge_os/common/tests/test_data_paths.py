"""Pure-function tests for common.data_paths.

These don't touch the filesystem — every helper is a path computation,
which lets us assert exact paths regardless of where the test repo lives.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from common import data_paths


@pytest.fixture
def root(tmp_path) -> Path:
    return tmp_path / "forge_data"


def test_default_root_uses_env(monkeypatch, tmp_path):
    monkeypatch.setenv("FORGE_DATA_ROOT", str(tmp_path / "envroot"))
    assert data_paths.default_root() == (tmp_path / "envroot").resolve()


def test_default_root_falls_back_to_repo_data(monkeypatch):
    monkeypatch.delenv("FORGE_DATA_ROOT", raising=False)
    # Resolved from common/data_paths.py → <repo>/data
    expected = Path(__file__).resolve().parent.parent.parent / "data"
    assert data_paths.default_root() == expected


def test_skill_root_under_data_root(root):
    assert data_paths.skill_root(root=root) == root / "skills"


def test_skill_company_dir_keyed_by_company_only(root):
    p = data_paths.skill_company_dir(7, root=root)
    assert p == root / "skills" / "company_7"


def test_skill_package_dir_uses_skill_id(root):
    """v2 layout: bundles are keyed by OA's skill_id, not by name."""
    p = data_paths.skill_package_dir(7, 42, root=root)
    assert p == root / "skills" / "company_7" / "skill_42"


def test_observer_log_root_under_data_root(root):
    assert data_paths.observer_log_root(root=root) == root / "observer_log"


def test_observer_skill_dir_nests_company_employee_skill(root):
    p = data_paths.observer_skill_dir(7, 42, 99, root=root)
    assert p == (root / "observer_log" / "company_7"
                 / "employee_42" / "skill_99")


def test_segment_dir_is_observer_skill_dir_plus_segment_name(root):
    p = data_paths.segment_dir(7, 42, 99, "seg_1234.567", root=root)
    assert p == (root / "observer_log" / "company_7" / "employee_42"
                 / "skill_99" / "seg_1234.567")


def test_int_coercion_rejects_garbage(root):
    """IDs come from JWT claims and must be ints. Passing a string would
    silently sneak path segments in via formatting; we coerce + raise."""
    with pytest.raises((TypeError, ValueError)):
        data_paths.skill_package_dir("evil/../etc", 42, root=root)
    with pytest.raises((TypeError, ValueError)):
        data_paths.observer_skill_dir(7, "bad", 99, root=root)
