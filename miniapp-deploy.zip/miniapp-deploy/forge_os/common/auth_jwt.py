"""Shared OA JWT decoding utilities.

`skill_oa` issues HS256 JWTs that other services in the monorepo
(`skill_creator`, `skill_observer`, future agents) need to verify in order to
identify the calling employee. Rather than reach into `skill_oa.backend.auth`,
those services import from here so they only depend on PyJWT plus this small
dataclass — and stay decoupled from `skill_oa`'s settings/config wiring.

Token payload contract (issued by `skill_oa.backend.routers.auth`):

    {
      "kind": "super" | "employee",
      "sub":  "super:<id>" | "emp:<id>",
      "company_id": int,
      "factory_id": int | null,    # employee tokens only
      "roles":      [str],         # informational; receivers SHOULD NOT trust
      "iat": int, "exp": int
    }

Receivers MUST verify signature + expiry (this module does both via PyJWT).
The `roles` claim is intentionally NOT exposed in `JwtPrincipal` because OA
re-derives roles from the DB on every request (see skill_oa/backend/deps.py);
trusting the claim across services would let stale tokens carry stale roles.
For services that need authoritative role info, call OA's /api/me directly.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Dict, Literal, Optional

import jwt


class JwtError(Exception):
    """Raised for any JWT decode/verify failure (bad signature, expired, malformed)."""


@dataclass
class JwtPrincipal:
    """Identity extracted from an OA-issued JWT.

    Only fields that are stable across every issuer/consumer are included.
    Use `id` for the numeric subject (super_admin id when kind='super',
    employee id when kind='employee').
    """
    kind: Literal["super", "employee"]
    id: int
    company_id: int
    factory_id: Optional[int] = None
    # Raw sub claim, kept around for diagnostics / audit logs.
    sub: str = ""

    @property
    def employee_id(self) -> Optional[int]:
        """Convenience: numeric employee id, or None if this is a super-admin token."""
        return self.id if self.kind == "employee" else None

    @property
    def super_admin_id(self) -> Optional[int]:
        return self.id if self.kind == "super" else None


def decode_oa_token(
    token: str,
    secret: str,
    algorithm: str = "HS256",
) -> Dict[str, Any]:
    """Verify signature + expiry, return raw claims dict.

    Use `decode_oa_principal` instead when you want a typed `JwtPrincipal`.
    """
    try:
        return jwt.decode(token, secret, algorithms=[algorithm])
    except jwt.PyJWTError as e:
        raise JwtError(str(e)) from e


def decode_oa_principal(
    token: str,
    secret: str,
    algorithm: str = "HS256",
) -> JwtPrincipal:
    """Verify the token and parse it into a `JwtPrincipal`.

    Raises JwtError on bad signature, expired tokens, or malformed payloads
    (missing kind/sub/company_id, sub without "kind:id" shape, etc).
    """
    payload = decode_oa_token(token, secret, algorithm)

    kind = payload.get("kind")
    sub = payload.get("sub", "")
    if kind not in ("super", "employee") or not isinstance(sub, str) or ":" not in sub:
        raise JwtError("malformed token: missing/invalid kind or sub")

    try:
        pid = int(sub.split(":", 1)[1])
    except (ValueError, IndexError) as e:
        raise JwtError(f"malformed token: sub not numeric: {sub}") from e

    if "company_id" not in payload:
        raise JwtError("malformed token: missing company_id")

    return JwtPrincipal(
        kind=kind,
        id=pid,
        company_id=int(payload["company_id"]),
        factory_id=payload.get("factory_id"),
        sub=sub,
    )


def encode_oa_token(
    payload: Dict[str, Any],
    secret: str,
    algorithm: str = "HS256",
    ttl_seconds: int = 7 * 24 * 3600,
) -> str:
    """Sign a payload with the OA-style claims (auto-fills iat/exp if absent).

    Primarily exists so `skill_oa.backend.auth.encode_token` can stay a thin
    wrapper; downstream services should never need to issue tokens themselves.
    """
    body = dict(payload)
    body.setdefault("iat", int(time.time()))
    body.setdefault("exp", int(time.time()) + ttl_seconds)
    return jwt.encode(body, secret, algorithm=algorithm)
