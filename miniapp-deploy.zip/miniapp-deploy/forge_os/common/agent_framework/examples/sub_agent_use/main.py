"""
Sub Agent as Tool Demo - 演示模型通过 create_sub_agent 工具派遣子 Agent

场景：一个总管 Agent 拥有两个子 Agent 专家：
    - analyst: 代码分析专家
    - writer: 技术文档撰写专家

总管 Agent 的 system prompt 中会自动列出可用子 Agent，
模型根据用户请求通过 create_sub_agent(agent_name="analyst", message="...") 派遣。

运行方式:
    export MOONSHOT_API_KEY="your-api-key"
    cd forge_os
    python3 -m common.agent_framework.examples.sub_agent_use.main
"""
import os
import sys

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
)
sys.path.insert(0, PROJECT_ROOT)

from common.llm import LLMClient, LLMConfig
from common.agent_framework.agent_loop.react_agent import ReactAgent
from common.agent_framework.agent_loop.config import ReactAgentConfig, SubAgentConfig
from common.agent_framework.sub_agent import SubAgentDefinition
from common.agent_framework.tool_adapter.registry import ToolRegistry
from common.agent_framework.context_strategy.default_strategy import DefaultContextStrategy
from common.agent_framework.user_interface.inputs import TaskInput, Message
from common.agent_framework.user_interface.content_blocks import (
    TextBlock, ToolCallBlock, ToolResultBlock, ThinkingBlock,
)


# ============================================================
# LLM 配置
# ============================================================

def make_llm_client() -> LLMClient:
    api_key = os.environ.get("MOONSHOT_API_KEY") or os.environ.get("KIMI_API_KEY")
    if not api_key:
        raise ValueError(
            "请设置环境变量 MOONSHOT_API_KEY 或 KIMI_API_KEY\n"
            "  export MOONSHOT_API_KEY='your-api-key'"
        )
    return LLMClient(LLMConfig(
        provider="kimi",
        base_url="https://api.moonshot.cn/v1",
        api_key=api_key,
        model="kimi-k2.5",
    ))


# ============================================================
# 构建 Agent
# ============================================================

def create_parent_agent() -> ReactAgent:
    """创建带有两个子 Agent 的父 Agent"""

    # 子 Agent 1: 代码分析专家
    analyst = ReactAgent(ReactAgentConfig(
        llm_client=make_llm_client(),
        tool_registry=ToolRegistry(),
        context_strategy=DefaultContextStrategy(),
        system_prompt=(
            "你是一位资深代码分析专家。"
            "请对给定的代码进行专业分析，包括代码质量、潜在问题、性能建议等。"
            "回答请简洁专业。"
        ),
        max_iterations=5,
        max_tokens=2048,
    ))

    # 子 Agent 2: 技术文档专家
    writer = ReactAgent(ReactAgentConfig(
        llm_client=make_llm_client(),
        tool_registry=ToolRegistry(),
        context_strategy=DefaultContextStrategy(),
        system_prompt=(
            "你是一位技术文档撰写专家。"
            "请根据给定的内容，撰写清晰、结构化的技术文档。"
            "使用 Markdown 格式，回答请简洁专业。"
        ),
        max_iterations=5,
        max_tokens=2048,
    ))

    # 配置子 Agent
    sub_agent_config = SubAgentConfig(agents={
        "analyst": SubAgentDefinition(
            name="analyst",
            description="代码分析专家，擅长代码质量评审、安全性检查、性能分析",
            agent=analyst,
        ),
        "writer": SubAgentDefinition(
            name="writer",
            description="技术文档专家，擅长撰写 API 文档、README、技术方案",
            agent=writer,
        ),
    })

    # 父 Agent: 总管
    parent = ReactAgent(ReactAgentConfig(
        llm_client=make_llm_client(),
        tool_registry=ToolRegistry(),
        context_strategy=DefaultContextStrategy(),
        system_prompt=(
            "你是一个智能助手，可以调度专家子 Agent 来完成专业任务。"
            "当用户的请求涉及代码分析或文档撰写时，请使用 create_sub_agent 工具派遣对应的专家。"
            "回答请使用中文。"
        ),
        max_iterations=10,
        max_tokens=4096,
        sub_agent_config=sub_agent_config,
    ))

    return parent


# ============================================================
# 运行
# ============================================================

def run_task(agent: ReactAgent, user_message: str):
    print(f"\n{'='*60}")
    print(f"  用户: {user_message}")
    print(f"{'='*60}")

    task_input = TaskInput(
        session_id="demo-session",
        task_id="demo-sub-agent",
        messages=[Message.from_role_and_text("user", user_message)],
    )

    for event in agent.run(task_input):
        iteration = event.metadata.get("iteration", "") if event.metadata else ""
        prefix = f"[Round {iteration}]" if iteration != "" else "[完成]"

        for block in event.content:
            if isinstance(block, ThinkingBlock):
                print(f"  {prefix} 思考: {block.thinking[:80]}...")
            elif isinstance(block, TextBlock):
                print(f"  {prefix} 回复: {block.text[:200]}{'...' if len(block.text) > 200 else ''}")
            elif isinstance(block, ToolCallBlock):
                args_preview = str(block.tool_input)
                if len(args_preview) > 100:
                    args_preview = args_preview[:100] + "..."
                print(f"  {prefix} 调用工具: {block.tool_name}({args_preview})")
            elif isinstance(block, ToolResultBlock):
                if block.is_error:
                    print(f"  {prefix} 工具错误: {block.error_message}")
                else:
                    result_str = str(block.result) if block.result else ""
                    if len(result_str) > 200:
                        result_str = result_str[:200] + "..."
                    print(f"  {prefix} 工具结果: {result_str}")


def main():
    print("=" * 60)
    print("  Sub Agent as Tool Demo")
    print("=" * 60)

    try:
        agent = create_parent_agent()
        print("[初始化] 父 Agent 创建成功")
        print("[初始化] 注册子 Agent: analyst, writer")
        print("[初始化] 注册工具: create_sub_agent")
    except ValueError as e:
        print(f"错误: {e}")
        return

    tasks = [
        "请帮我分析以下 Python 代码的质量：\ndef fibonacci(n):\n    if n <= 1: return n\n    return fibonacci(n-1) + fibonacci(n-2)",
    ]

    for task in tasks:
        try:
            run_task(agent, task)
        except Exception as e:
            print(f"  [错误] 任务执行失败: {e}")
            import traceback
            traceback.print_exc()

    print(f"\n{'='*60}")
    print("  Demo 完成！")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
