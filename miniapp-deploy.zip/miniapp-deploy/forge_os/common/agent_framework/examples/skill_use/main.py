"""
Calculator Skill Demo - 演示在 ReactAgent loop 中使用 Skill binding BashTool

完整流程:
    1. 注册 BashTool 到 ToolRegistry
    2. 通过 SkillConfig 定义 calculator skill (binding bash 工具, 读取 skills/ 目录下的 SKILL.md)
    3. ReactAgent 自动注入 skill 候选列表到 system prompt，并注册 load_skill 工具
    4. 模型根据用户问题调用 load_skill("calculator") -> 获得 skill 指令 + bash 工具
    5. 模型使用 bash 工具执行计算命令
    6. 返回计算结果给用户

目录结构:
    examples/skill_use/
    ├── main.py                         <- 本文件
    └── skills/
        └── calculator/
            └── SKILL.md                <- skill 指令内容

运行方式:
    export MOONSHOT_API_KEY="your-api-key"
    cd forge_os
    python3 -m common.agent_framework.examples.skill_use.main
"""
import dataclasses
import json
import os
import sys
from pathlib import Path
from typing import Any

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, PROJECT_ROOT)

from common.llm import LLMClient, LLMConfig
from common.agent_framework.agent_loop.react_agent import ReactAgent
from common.agent_framework.agent_loop.config import ReactAgentConfig, SkillConfig
from common.agent_framework.tool_adapter.registry import ToolRegistry
from common.agent_framework.context_strategy.default_strategy import DefaultContextStrategy
from common.agent_framework.user_interface.inputs import TaskInput, Message
from common.agent_framework.user_interface.content_blocks import (
    TextBlock,
    ToolCallBlock,
    ToolResultBlock,
    ThinkingBlock,
)
from common.agent_framework.builtin_tools.bash_tool import BashTool
from common.agent_framework.builtin_tools.bash_executors import LocalBashExecutor


# 当前目录（skill_use/）
DEMO_DIR = Path(__file__).parent
SKILLS_DIR = DEMO_DIR / "skills"


# ============================================================
# 调试用 LLMClient 包装器
# ============================================================

def to_jsonable(value: Any) -> Any:
    """将 ChatRequest 中的 dataclass 递归转换为可 JSON 序列化的结构"""
    if dataclasses.is_dataclass(value):
        return {
            field.name: to_jsonable(getattr(value, field.name))
            for field in dataclasses.fields(value)
        }
    if isinstance(value, list):
        return [to_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {key: to_jsonable(item) for key, item in value.items()}
    return value


class ContextPrintingLLMClient:
    """在调用真实 LLM 前打印 ReactAgent 构造出的完整 ChatRequest"""

    def __init__(self, inner: LLMClient):
        self._inner = inner
        self.config = inner.config

    def chat_with_request(self, request):
        print("\n" + "#" * 80)
        print("MODEL CONTEXT / ChatRequest")
        print("#" * 80)
        print(json.dumps(to_jsonable(request), ensure_ascii=False, indent=2))
        print("#" * 80 + "\n")
        return self._inner.chat_with_request(request)

    def chat(self, *args, **kwargs):
        return self._inner.chat(*args, **kwargs)


# ============================================================
# Agent 构建
# ============================================================

def create_agent() -> ReactAgent:
    """创建配置了 calculator skill 的 ReactAgent"""

    # 1. LLM 配置
    api_key = os.environ.get("MOONSHOT_API_KEY") or os.environ.get("KIMI_API_KEY")
    if not api_key:
        raise ValueError(
            "请设置环境变量 MOONSHOT_API_KEY 或 KIMI_API_KEY\n"
            "  export MOONSHOT_API_KEY='your-api-key'"
        )

    llm_config = LLMConfig(
        provider="kimi",
        base_url="https://api.moonshot.cn/v1",
        api_key=api_key,
        model="kimi-k2.5",
    )
    llm_client = ContextPrintingLLMClient(LLMClient(llm_config))

    # 2. 注册 BashTool
    executor = LocalBashExecutor()
    bash_tool = BashTool(executor=executor, default_timeout=15.0)

    registry = ToolRegistry()
    registry.register(bash_tool)

    # 3. SkillConfig - 引用 skills/calculator/SKILL.md
    skill_config = SkillConfig(
        skills_config={
            "calculator": {
                "description": "数学计算器，通过 bash 执行计算命令（支持四则运算、浮点数、科学计算）",
                "content_file_path": "calculator/SKILL.md",
                "load_type": "dynamic",
                "keep_task_round": 5,
                "binding_tools": ["bash"],
            }
        },
        base_path=str(SKILLS_DIR),
    )

    # 4. 创建 ReactAgent
    context_strategy = DefaultContextStrategy()

    system_prompt_template = """\
你是一个智能助手。回答请使用中文。

## 可用 Skills

当用户的请求匹配以下 skill 时，先使用 load_skill 工具加载对应 skill，然后按照 skill 指引使用工具完成任务。

{% for skill in skills %}
- **{{ skill.name }}**: {{ skill.description }} (路径: {{ skill.local_path }})
{% endfor %}
"""

    agent_config = ReactAgentConfig(
        llm_client=llm_client,
        tool_registry=registry,
        context_strategy=context_strategy,
        system_prompt=system_prompt_template,
        max_iterations=10,
        max_tokens=4096,
        temperature=1.0,
        skill_config=skill_config,
    )

    print(f"[初始化] Skills 目录: {SKILLS_DIR}")
    print(f"[初始化] 注册工具: bash")
    print(f"[初始化] 配置 skill: calculator (dynamic, binding_tools=['bash'])")

    return ReactAgent(agent_config)


# ============================================================
# 运行任务
# ============================================================

def run_task(agent: ReactAgent, user_message: str):
    """运行一个任务并打印 ReAct 循环的事件流"""
    print(f"\n{'='*60}")
    print(f"  用户: {user_message}")
    print(f"{'='*60}")

    task_input = TaskInput(
        session_id="demo-session",
        task_id="demo-task",
        messages=[Message.from_role_and_text("user", user_message)],
    )

    for event in agent.run(task_input):
        iteration = event.metadata.get("iteration", "") if event.metadata else ""
        prefix = f"[Round {iteration}]" if iteration != "" else "[完成]"

        for block in event.content:
            if isinstance(block, ThinkingBlock):
                print(f"  {prefix} 思考: {block.thinking[:100]}...")
            elif isinstance(block, TextBlock):
                print(f"  {prefix} 回复: {block.text}")
            elif isinstance(block, ToolCallBlock):
                print(f"  {prefix} 调用工具: {block.tool_name}({block.tool_input})")
            elif isinstance(block, ToolResultBlock):
                if block.is_error:
                    print(f"  {prefix} 工具错误: {block.error_message}")
                else:
                    result_str = str(block.result)
                    if len(result_str) > 200:
                        result_str = result_str[:200] + "..."
                    print(f"  {prefix} 工具结果: {result_str}")


# ============================================================
# Main
# ============================================================

def main():
    print("=" * 60)
    print("  Calculator Skill Demo - ReactAgent + BashTool")
    print("=" * 60)

    try:
        agent = create_agent()
        print("[初始化] Agent 创建成功！\n")
    except ValueError as e:
        print(f"错误: {e}")
        return

    tasks = [
        # "帮我计算 1234 * 5678 等于多少",
        "计算圆周率的前 10 位小数",
    ]

    for task in tasks:
        try:
            run_task(agent, task)
        except Exception as e:
            print(f"  [错误] 任务执行失败: {e}")
            import traceback
            traceback.print_exc()

    print(f"\n{'='*60}")
    print("  Demo 完成！")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
