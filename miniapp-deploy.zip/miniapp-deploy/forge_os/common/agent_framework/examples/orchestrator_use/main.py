"""
OrchestratorAgent Demo - 演示多 Agent + 函数节点编排

场景：简单的 "计划-执行-审查" 循环
    1. planner (ReactAgent): 根据用户请求生成一个执行计划
    2. parse_plan (函数节点): 解析计划，提取待执行步骤
    3. executor (ReactAgent): 执行具体步骤
    4. reviewer (函数节点): 检查结果，决定是否通过或需要重试
    5. 条件路由: 通过 -> END, 重试 -> planner

图结构:

    START -> planner -> parse_plan -> executor -> reviewer
                ^                                   |
                |_____(retry)_______________________/
                                                    |
                                            (approved) -> END

运行方式:
    export MOONSHOT_API_KEY="your-api-key"
    cd forge_os
    python3 -m common.agent_framework.examples.orchestrator_use.main
"""
import os
import sys
from pathlib import Path

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
)
sys.path.insert(0, PROJECT_ROOT)

from common.llm import LLMClient, LLMConfig
from common.agent_framework.agent_loop.react_agent import ReactAgent
from common.agent_framework.agent_loop.config import ReactAgentConfig
from common.agent_framework.agent_loop.graph import (
    StateGraph, AgentNode, END,
)
from common.agent_framework.agent_loop.orchestrator_agent import (
    OrchestratorAgent, OrchestratorConfig,
)
from common.agent_framework.tool_adapter.registry import ToolRegistry
from common.agent_framework.context_strategy.default_strategy import DefaultContextStrategy
from common.agent_framework.user_interface.inputs import TaskInput, Message
from common.agent_framework.user_interface.content_blocks import (
    TextBlock, ToolCallBlock, ToolResultBlock, ThinkingBlock,
)


# ============================================================
# 辅助: 创建一个 ReactAgent
# ============================================================

def make_llm_client() -> LLMClient:
    api_key = os.environ.get("MOONSHOT_API_KEY") or os.environ.get("KIMI_API_KEY")
    if not api_key:
        raise ValueError(
            "请设置环境变量 MOONSHOT_API_KEY 或 KIMI_API_KEY\n"
            "  export MOONSHOT_API_KEY='your-api-key'"
        )
    return LLMClient(LLMConfig(
        provider="kimi",
        base_url="https://api.moonshot.cn/v1",
        api_key=api_key,
        model="kimi-k2.5",
    ))


def make_agent(system_prompt: str) -> ReactAgent:
    return ReactAgent(ReactAgentConfig(
        llm_client=make_llm_client(),
        tool_registry=ToolRegistry(),
        context_strategy=DefaultContextStrategy(),
        system_prompt=system_prompt,
        max_iterations=5,
        max_tokens=2048,
        temperature=0.7,
    ))


# ============================================================
# 函数节点
# ============================================================

def parse_plan(state: dict) -> dict:
    """从 planner 输出中提取执行步骤（简单示例：直接透传）"""
    plan_text = state.get("plan", "")
    print(f"  [parse_plan] 解析计划: {plan_text[:80]}...")
    return {
        "current_step": plan_text,
        "step_count": state.get("step_count", 0) + 1,
    }


def review_result(state: dict) -> dict:
    """
    审查执行结果，决定是否通过。
    简单策略：第一轮总是通过（演示用）。
    """
    step_count = state.get("step_count", 0)
    execution_result = state.get("execution_result", "")

    approved = step_count >= 1
    route = "approved" if approved else "retry"

    print(f"  [reviewer] 第 {step_count} 轮审查, 结果: {route}")
    print(f"  [reviewer] 执行输出摘要: {execution_result[:80]}...")

    return {"approved": approved, "route": route}


# ============================================================
# 构建编排图
# ============================================================

def build_graph() -> StateGraph:
    planner_agent = make_agent(
        "你是一个任务规划专家。根据用户的请求，生成一个简洁的执行计划。"
        "直接输出计划内容，不要加多余的前缀。"
    )
    executor_agent = make_agent(
        "你是一个任务执行专家。根据给定的计划步骤，输出执行结果。"
        "直接输出结果，不要加多余的前缀。"
    )

    graph = StateGraph(initial_state={"step_count": 0, "approved": False})

    # Agent 节点
    graph.add_node("planner", AgentNode(
        name="planner",
        agent=planner_agent,
        input_mapper=lambda state: TaskInput(
            session_id=state["session_id"],
            task_id="plan",
            messages=[Message.from_role_and_text(
                "user",
                state.get("user_request", "请帮我制定一个学习 Python 的计划"),
            )],
        ),
        output_key="plan",
    ))

    graph.add_node("executor", AgentNode(
        name="executor",
        agent=executor_agent,
        input_mapper=lambda state: TaskInput(
            session_id=state["session_id"],
            task_id="execute",
            messages=[Message.from_role_and_text(
                "user",
                f"请执行以下计划步骤:\n{state.get('current_step', '')}",
            )],
        ),
        output_key="execution_result",
    ))

    # 函数节点
    graph.add_node("parse_plan", parse_plan)
    graph.add_node("reviewer", review_result)

    # 边
    graph.set_entry_point("planner")
    graph.add_edge("planner", "parse_plan")
    graph.add_edge("parse_plan", "executor")
    graph.add_edge("executor", "reviewer")
    graph.add_conditional_edges(
        "reviewer",
        router=lambda state: state["route"],
        path_map={"approved": END, "retry": "planner"},
    )

    return graph


# ============================================================
# 运行
# ============================================================

def main():
    print("=" * 60)
    print("  OrchestratorAgent Demo - 计划/执行/审查 循环")
    print("=" * 60)

    try:
        graph = build_graph()
        compiled = graph.compile()
        print("[初始化] 图编译成功")
        print(f"[初始化] 节点: {list(compiled.nodes.keys())}")
        print(f"[初始化] 入口: {compiled.entry_point}")
    except ValueError as e:
        print(f"错误: {e}")
        return

    orchestrator = OrchestratorAgent(OrchestratorConfig(
        graph=compiled,
        max_node_executions=10,
    ))

    task_input = TaskInput(
        session_id="demo-session",
        task_id="demo-orchestration",
        messages=[Message.from_role_and_text("user", "帮我制定一个周末两天的北京旅游计划")],
        context={"user_request": "帮我制定一个周末两天的北京旅游计划"},
    )

    print(f"\n{'='*60}")
    print(f"  用户请求: 帮我制定一个周末两天的北京旅游计划")
    print(f"{'='*60}\n")

    for event in orchestrator.run(task_input):
        etype = event.event_type
        meta = event.metadata or {}

        if etype == "orchestration_start":
            print(f"[编排开始] 入口节点: {meta.get('entry_point')}")
        elif etype == "node_start":
            print(f"\n--- 节点开始: {meta.get('node_name')} (第 {meta.get('execution_count')} 次) ---")
        elif etype == "node_complete":
            keys = meta.get("state_updates_keys", [])
            print(f"--- 节点完成: {meta.get('node_name')} | 更新 keys: {keys} ---")
        elif etype == "orchestration_complete":
            print(f"\n[编排完成] 总执行次数: {meta.get('total_executions')}, 原因: {meta.get('reason')}")
        elif etype == "reasoning":
            node_name = meta.get("orchestrator_node", "?")
            for block in event.content:
                if isinstance(block, TextBlock) and block.text:
                    preview = block.text[:120]
                    print(f"  [{node_name}] 回复: {preview}{'...' if len(block.text) > 120 else ''}")
                elif isinstance(block, ThinkingBlock):
                    print(f"  [{node_name}] 思考中...")
        elif etype == "error":
            for block in event.content:
                if isinstance(block, TextBlock):
                    print(f"  [错误] {block.text}")

    print(f"\n{'='*60}")
    print("  Demo 完成！")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
