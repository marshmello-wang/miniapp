"""
Memory 模块测试用例

测试覆盖:
- CollapseStrategyConfig / HistoryCollapseConfig / AllocationBudgetConfig 配置验证
- InMemoryStore: save / load / 冲突处理
- collapse: thinking / tool_call / tool_response 各策略折叠
- L1AllocationBudget: budget 截断 + 历史折叠 + 最近一轮保护
- L2MicroCompaction: 三阶段微折叠 + 白名单 + protected_steps + fallback
- ContextMemoryHelper: 统一入口 apply_l1 / apply_l2
"""
import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..'))

from common.llm import Message as LLMMessage, ToolCall
from common.agent_framework.context_strategy.memory.config import (
    CollapseStrategyConfig,
    HistoryCollapseConfig,
    AllocationBudgetConfig,
    L1Config,
    L2Config,
    MemoryConfig,
)
from common.agent_framework.context_strategy.memory.store import InMemoryStore
from common.agent_framework.context_strategy.memory.collapse import (
    collapse_thinking,
    collapse_tool_calls,
    collapse_tool_response,
    collapse_message,
    collapse_messages,
)
from common.agent_framework.context_strategy.memory.token_utils import (
    estimate_message_tokens,
    estimate_messages_tokens,
)
from common.agent_framework.context_strategy.memory.l1_budget import L1AllocationBudget
from common.agent_framework.context_strategy.memory.l2_compaction import L2MicroCompaction
from common.agent_framework.context_strategy.memory.helper import ContextMemoryHelper


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def store():
    return InMemoryStore()


@pytest.fixture
def long_thinking():
    return "A" * 500


@pytest.fixture
def long_tool_response():
    return "Result data: " + "B" * 500


@pytest.fixture
def assistant_msg(long_thinking):
    return LLMMessage(
        role="assistant",
        content="Answer text",
        thinking=long_thinking,
        tool_calls=[
            ToolCall(id="tc1", name="search", arguments={"q": "test"}),
            ToolCall(id="tc2", name="read_file", arguments={"path": "/tmp/x"}),
        ],
    )


@pytest.fixture
def tool_msg(long_tool_response):
    return LLMMessage(
        role="tool",
        content=long_tool_response,
        tool_call_id="tc1",
        name="search",
    )


def _make_conversation(num_rounds=3, tool_response_len=200):
    """构造多轮对话消息列表"""
    msgs = [LLMMessage(role="system", content="You are a helpful assistant.")]
    for i in range(num_rounds):
        msgs.append(LLMMessage(role="user", content=f"Question {i}"))
        msgs.append(LLMMessage(
            role="assistant",
            content="",
            thinking=f"Thinking about question {i} " + "x" * 100,
            tool_calls=[ToolCall(id=f"tc_{i}", name="tool_a", arguments={"i": i})],
        ))
        msgs.append(LLMMessage(
            role="tool",
            content=f"Tool result {i}: " + "y" * tool_response_len,
            tool_call_id=f"tc_{i}",
            name="tool_a",
        ))
        msgs.append(LLMMessage(role="assistant", content=f"Final answer {i}"))
    return msgs


# ============================================================================
# Config Tests
# ============================================================================

class TestConfig:
    def test_allocation_budget_max_history(self):
        cfg = AllocationBudgetConfig(
            max_total_tokens=128000,
            system_prompt_tokens=4000,
            memory_tokens=4000,
            react_stack_reserve=10000,
            final_output_reserve=16000,
        )
        assert cfg.max_history_tokens == 94000

    def test_allocation_budget_invalid(self):
        with pytest.raises(ValueError, match="max_history_tokens <= 0"):
            AllocationBudgetConfig(
                max_total_tokens=100,
                system_prompt_tokens=50,
                memory_tokens=50,
                react_stack_reserve=50,
                final_output_reserve=50,
            )

    def test_tool_call_collapse_type_validation(self):
        with pytest.raises(ValueError, match="tool_call_collapse.type"):
            HistoryCollapseConfig(
                tool_call_collapse=CollapseStrategyConfig(type="prefix")
            )

    def test_l2_config_validation(self):
        with pytest.raises(ValueError):
            L2Config(protected_steps=-1)
        with pytest.raises(ValueError):
            L2Config(after_collapse_max_length=0)


# ============================================================================
# Store Tests
# ============================================================================

class TestInMemoryStore:
    def test_save_and_load(self, store):
        ref_id = store.save("hello world", "tool")
        assert ref_id.startswith("tool_")
        assert store.load(ref_id) == "hello world"

    def test_load_nonexistent(self, store):
        assert store.load("nonexistent") is None

    def test_same_content_same_id(self, store):
        id1 = store.save("same content", "tool")
        id2 = store.save("same content", "tool")
        assert id1 == id2

    def test_hash_collision_handling(self, store):
        id1 = store.save("content_a", "tool")
        # Force same hash by directly manipulating
        store._data[id1] = "content_a"
        # Different content should get different id if hash collides
        # (unlikely in practice, but the logic handles it)
        assert len(store) == 1

    def test_clear(self, store):
        store.save("data", "think")
        assert len(store) == 1
        store.clear()
        assert len(store) == 0


# ============================================================================
# Collapse Tests
# ============================================================================

class TestCollapseThinking:
    def test_none_strategy(self, assistant_msg):
        strategy = CollapseStrategyConfig(type="none")
        result = collapse_thinking(assistant_msg, strategy)
        assert result.thinking == assistant_msg.thinking

    def test_remove_strategy(self, assistant_msg):
        strategy = CollapseStrategyConfig(type="remove")
        result = collapse_thinking(assistant_msg, strategy)
        assert result.thinking is None

    def test_empty_str_strategy(self, assistant_msg):
        strategy = CollapseStrategyConfig(type="empty_str")
        result = collapse_thinking(assistant_msg, strategy)
        assert result.thinking == ""

    def test_prefix_strategy(self, assistant_msg):
        strategy = CollapseStrategyConfig(type="prefix", collapse_prefix_length=50)
        result = collapse_thinking(assistant_msg, strategy)
        assert len(result.thinking) == 53  # 50 + "..."
        assert result.thinking.endswith("...")

    def test_prefix_ref_strategy(self, assistant_msg, store):
        strategy = CollapseStrategyConfig(type="prefix_ref", collapse_prefix_length=50)
        result = collapse_thinking(assistant_msg, strategy, store)
        assert "ref_id:think_" in result.thinking
        assert "read_expire_history" in result.thinking
        assert len(store) == 1

    def test_short_thinking_not_truncated(self):
        msg = LLMMessage(role="assistant", content="", thinking="short")
        strategy = CollapseStrategyConfig(type="prefix", collapse_prefix_length=200)
        result = collapse_thinking(msg, strategy)
        assert result.thinking == "short"

    def test_non_assistant_ignored(self):
        msg = LLMMessage(role="user", content="hello")
        strategy = CollapseStrategyConfig(type="remove")
        result = collapse_thinking(msg, strategy)
        assert result is msg  # unchanged

    def test_no_thinking_ignored(self):
        msg = LLMMessage(role="assistant", content="hello")
        strategy = CollapseStrategyConfig(type="remove")
        result = collapse_thinking(msg, strategy)
        assert result is msg


class TestCollapseToolCalls:
    def test_none_strategy(self, assistant_msg):
        strategy = CollapseStrategyConfig(type="none")
        result = collapse_tool_calls(assistant_msg, strategy)
        assert result.tool_calls == assistant_msg.tool_calls

    def test_remove_all(self, assistant_msg):
        strategy = CollapseStrategyConfig(type="remove")
        result = collapse_tool_calls(assistant_msg, strategy)
        assert result.tool_calls is None

    def test_remove_with_whitelist(self, assistant_msg):
        strategy = CollapseStrategyConfig(type="remove")
        result = collapse_tool_calls(assistant_msg, strategy, whitelist={"search"})
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0].name == "search"

    def test_non_assistant_ignored(self):
        msg = LLMMessage(role="tool", content="result", tool_call_id="tc1")
        strategy = CollapseStrategyConfig(type="remove")
        result = collapse_tool_calls(msg, strategy)
        assert result is msg


class TestCollapseToolResponse:
    def test_none_strategy(self, tool_msg):
        strategy = CollapseStrategyConfig(type="none")
        result = collapse_tool_response(tool_msg, strategy)
        assert result is tool_msg

    def test_remove_strategy(self, tool_msg):
        strategy = CollapseStrategyConfig(type="remove")
        result = collapse_tool_response(tool_msg, strategy)
        assert result.content == ""

    def test_empty_str_strategy(self, tool_msg):
        strategy = CollapseStrategyConfig(type="empty_str")
        result = collapse_tool_response(tool_msg, strategy)
        assert result.content == ""

    def test_prefix_strategy(self, tool_msg):
        strategy = CollapseStrategyConfig(type="prefix", collapse_prefix_length=30)
        result = collapse_tool_response(tool_msg, strategy)
        assert len(result.content) == 33  # 30 + "..."
        assert result.content.startswith("Result data:")

    def test_prefix_ref_strategy(self, tool_msg, store):
        strategy = CollapseStrategyConfig(type="prefix_ref", collapse_prefix_length=30)
        result = collapse_tool_response(tool_msg, strategy, store)
        assert "ref_id:tool_" in result.content
        assert len(store) == 1
        # Verify store contains original content
        ref_id = list(store._data.keys())[0]
        assert store.load(ref_id) == tool_msg.content

    def test_whitelist_skips(self, tool_msg):
        strategy = CollapseStrategyConfig(type="remove")
        result = collapse_tool_response(tool_msg, strategy, whitelist={"search"})
        assert result is tool_msg  # skipped due to whitelist

    def test_non_tool_ignored(self):
        msg = LLMMessage(role="assistant", content="hello")
        strategy = CollapseStrategyConfig(type="remove")
        result = collapse_tool_response(msg, strategy)
        assert result is msg


class TestCollapseMessage:
    def test_collapses_assistant(self, assistant_msg, store):
        config = HistoryCollapseConfig(
            thinking_collapse=CollapseStrategyConfig(type="remove"),
            tool_call_collapse=CollapseStrategyConfig(type="remove"),
            tool_response_collapse=CollapseStrategyConfig(type="none"),
        )
        result = collapse_message(assistant_msg, config, store)
        assert result.thinking is None
        assert result.tool_calls is None
        assert result.content == "Answer text"

    def test_collapses_tool(self, tool_msg, store):
        config = HistoryCollapseConfig(
            thinking_collapse=CollapseStrategyConfig(type="none"),
            tool_call_collapse=CollapseStrategyConfig(type="none"),
            tool_response_collapse=CollapseStrategyConfig(type="empty_str"),
        )
        result = collapse_message(tool_msg, config, store)
        assert result.content == ""

    def test_user_message_untouched(self):
        msg = LLMMessage(role="user", content="hello")
        config = HistoryCollapseConfig()
        result = collapse_message(msg, config)
        assert result is msg


class TestCollapseMessages:
    def test_skip_indices(self):
        msgs = [
            LLMMessage(role="assistant", content="a1", thinking="long " * 100),
            LLMMessage(role="assistant", content="a2", thinking="long " * 100),
            LLMMessage(role="assistant", content="a3", thinking="long " * 100),
        ]
        config = HistoryCollapseConfig(
            thinking_collapse=CollapseStrategyConfig(type="remove"),
        )
        result = collapse_messages(msgs, config, skip_indices={2})
        assert result[0].thinking is None
        assert result[1].thinking is None
        assert result[2].thinking is not None  # protected


# ============================================================================
# Token Utils Tests
# ============================================================================

class TestTokenUtils:
    def test_estimate_message_tokens(self):
        msg = LLMMessage(role="user", content="Hello world")
        tokens = estimate_message_tokens(msg)
        assert tokens > 0

    def test_estimate_with_thinking(self):
        msg = LLMMessage(role="assistant", content="Answer", thinking="x" * 300)
        tokens = estimate_message_tokens(msg)
        msg_no_think = LLMMessage(role="assistant", content="Answer")
        tokens_no_think = estimate_message_tokens(msg_no_think)
        assert tokens > tokens_no_think

    def test_estimate_messages_tokens(self):
        msgs = [
            LLMMessage(role="user", content="Hello"),
            LLMMessage(role="assistant", content="World"),
        ]
        total = estimate_messages_tokens(msgs)
        individual = sum(estimate_message_tokens(m) for m in msgs)
        assert total == individual

    def test_empty_content(self):
        msg = LLMMessage(role="assistant", content="")
        tokens = estimate_message_tokens(msg)
        assert tokens >= 4  # at least overhead


# ============================================================================
# L1 Tests
# ============================================================================

class TestL1AllocationBudget:
    def _make_l1(self, max_total=1000, store=None):
        config = L1Config(
            budget=AllocationBudgetConfig(
                max_total_tokens=max_total,
                system_prompt_tokens=50,
                memory_tokens=50,
                react_stack_reserve=50,
                final_output_reserve=50,
            ),
            history_collapse=HistoryCollapseConfig(
                thinking_collapse=CollapseStrategyConfig(type="remove"),
                tool_call_collapse=CollapseStrategyConfig(type="none"),
                tool_response_collapse=CollapseStrategyConfig(
                    type="prefix", collapse_prefix_length=20
                ),
            ),
        )
        return L1AllocationBudget(config, store)

    def test_empty_messages(self):
        l1 = self._make_l1()
        assert l1.truncate([]) == []

    def test_system_only(self):
        l1 = self._make_l1()
        msgs = [LLMMessage(role="system", content="SP")]
        result = l1.truncate(msgs)
        assert len(result) == 1
        assert result[0].role == "system"

    def test_preserves_system_prompt(self):
        l1 = self._make_l1()
        msgs = _make_conversation(num_rounds=2)
        result = l1.truncate(msgs)
        assert result[0].role == "system"

    def test_truncates_old_history(self):
        l1 = self._make_l1(max_total=300)
        msgs = _make_conversation(num_rounds=5, tool_response_len=500)
        result = l1.truncate(msgs)
        assert len(result) < len(msgs)
        assert result[0].role == "system"

    def test_latest_round_thinking_preserved(self):
        l1 = self._make_l1(max_total=5000)
        msgs = _make_conversation(num_rounds=3)
        result = l1.truncate(msgs)
        last_user_idx = max(
            i for i, m in enumerate(result) if m.role == "user"
        )
        for m in result[last_user_idx:]:
            if m.role == "assistant" and m.thinking:
                assert m.thinking is not None

    def test_historical_thinking_collapsed(self):
        l1 = self._make_l1(max_total=5000)
        msgs = _make_conversation(num_rounds=3)
        result = l1.truncate(msgs)
        last_user_idx = max(
            i for i, m in enumerate(result) if m.role == "user"
        )
        for m in result[1:last_user_idx]:
            if m.role == "assistant":
                assert m.thinking is None

    def test_whitelist(self, store):
        config = L1Config(
            budget=AllocationBudgetConfig(
                max_total_tokens=5000,
                system_prompt_tokens=100,
                memory_tokens=100,
                react_stack_reserve=200,
                final_output_reserve=200,
            ),
            history_collapse=HistoryCollapseConfig(
                thinking_collapse=CollapseStrategyConfig(type="remove"),
                tool_call_collapse=CollapseStrategyConfig(type="remove"),
                tool_response_collapse=CollapseStrategyConfig(type="remove"),
            ),
            tool_call_collapse_whitelist=["tool_a"],
            tool_response_collapse_whitelist=["tool_a"],
        )
        l1 = L1AllocationBudget(config, store)
        msgs = _make_conversation(num_rounds=2)
        result = l1.truncate(msgs)
        for m in result:
            if m.role == "tool" and m.name == "tool_a":
                assert m.content != ""

    def test_truncation_at_round_boundary(self):
        """截断必须以 user-round 为单位，结果中 system 之后第一条必须是 user"""
        l1 = self._make_l1(max_total=400)
        msgs = _make_conversation(num_rounds=5, tool_response_len=300)
        result = l1.truncate(msgs)
        non_system = [m for m in result if m.role != "system"]
        assert len(non_system) > 0
        assert non_system[0].role == "user", (
            f"History should start with 'user', got '{non_system[0].role}'"
        )

    def test_no_orphan_tool_or_assistant(self):
        """截断不能产生孤儿 tool/assistant 消息"""
        l1 = self._make_l1(max_total=350)
        msgs = _make_conversation(num_rounds=4, tool_response_len=400)
        result = l1.truncate(msgs)
        non_system = [m for m in result if m.role != "system"]
        if non_system:
            assert non_system[0].role == "user"

    def test_collapse_before_truncation(self):
        """折叠先于截断：折叠后腾出空间，应保留更多轮次"""
        # 构造 3 轮对话，每轮 tool response 很长 (600 chars ≈ 200 tokens)
        # max_history = 500-50-50-50-50 = 300 tokens
        # 不折叠时：每轮 ~220 tokens，3 轮 ~660，只能保留 1 轮
        # 折叠后：非最近轮 tool response 截断到 20 chars，~30 tokens/轮
        #   折叠后 round1 + round2 ≈ 60, round3(不折叠) ≈ 220, 总 ≈ 280 < 300
        #   所以应该保留全部 3 轮
        config = L1Config(
            budget=AllocationBudgetConfig(
                max_total_tokens=500,
                system_prompt_tokens=50,
                memory_tokens=50,
                react_stack_reserve=50,
                final_output_reserve=50,
            ),
            history_collapse=HistoryCollapseConfig(
                thinking_collapse=CollapseStrategyConfig(type="remove"),
                tool_call_collapse=CollapseStrategyConfig(type="none"),
                tool_response_collapse=CollapseStrategyConfig(
                    type="prefix", collapse_prefix_length=20
                ),
            ),
        )
        l1 = L1AllocationBudget(config)
        msgs = [LLMMessage(role="system", content="SP")]
        for i in range(3):
            msgs.append(LLMMessage(role="user", content=f"Q{i}"))
            msgs.append(LLMMessage(
                role="assistant", content=f"A{i}",
                thinking=f"think{i} " + "x" * 100,
            ))
            msgs.append(LLMMessage(
                role="tool", content=f"R{i}: " + "d" * 600,
                tool_call_id=f"tc{i}", name="t",
            ))

        result = l1.truncate(msgs)
        user_msgs = [m for m in result if m.role == "user"]
        assert len(user_msgs) >= 2, (
            f"Collapse-first should retain at least 2 rounds, got {len(user_msgs)}"
        )

    def test_leading_orphan_messages_discarded(self):
        """history 开头的孤儿 assistant/tool 消息应被丢弃"""
        l1 = self._make_l1(max_total=5000)
        msgs = [
            LLMMessage(role="system", content="SP"),
            LLMMessage(role="assistant", content="orphan assistant"),
            LLMMessage(role="tool", content="orphan tool", tool_call_id="x", name="t"),
            LLMMessage(role="user", content="real question"),
            LLMMessage(role="assistant", content="real answer"),
        ]
        result = l1.truncate(msgs)
        non_system = [m for m in result if m.role != "system"]
        assert non_system[0].role == "user"
        assert non_system[0].content == "real question"


# ============================================================================
# L2 Tests
# ============================================================================

class TestL2MicroCompaction:
    def _make_l2(self, max_length=500, store=None, protected_steps=1):
        config = L2Config(
            history_collapse=HistoryCollapseConfig(
                thinking_collapse=CollapseStrategyConfig(type="remove"),
                tool_call_collapse=CollapseStrategyConfig(type="remove"),
                tool_response_collapse=CollapseStrategyConfig(
                    type="prefix", collapse_prefix_length=10
                ),
            ),
            after_collapse_max_length=max_length,
            protected_steps=protected_steps,
            fallback_strategy="abandon",
        )
        return L2MicroCompaction(config, store)

    def test_no_compaction_when_within_budget(self):
        l2 = self._make_l2(max_length=100000)
        msgs = _make_conversation(num_rounds=2)
        result = l2.compact(msgs, current_step=2)
        assert len(result) == len(msgs)

    def test_compaction_reduces_tokens(self):
        l2 = self._make_l2(max_length=200)
        msgs = _make_conversation(num_rounds=3, tool_response_len=500)
        result = l2.compact(msgs, current_step=3)
        original_tokens = estimate_messages_tokens(msgs)
        result_tokens = estimate_messages_tokens(result)
        assert result_tokens < original_tokens

    def test_protected_steps_preserved(self):
        l2 = self._make_l2(max_length=300, protected_steps=1)
        msgs = [
            LLMMessage(role="system", content="SP"),
            LLMMessage(role="user", content="Do task"),
            LLMMessage(
                role="assistant", content="step 1",
                thinking="long " * 100,
                tool_calls=[ToolCall(id="tc1", name="t1", arguments={})],
            ),
            LLMMessage(role="tool", content="result " * 100, tool_call_id="tc1", name="t1"),
            LLMMessage(role="assistant", content="Final answer."),
        ]
        result = l2.compact(msgs, current_step=2)
        # Final assistant message should always be preserved
        assert any(m.content == "Final answer." for m in result)

    def test_whitelist_preserves_tool(self):
        config = L2Config(
            history_collapse=HistoryCollapseConfig(
                thinking_collapse=CollapseStrategyConfig(type="remove"),
                tool_call_collapse=CollapseStrategyConfig(type="remove"),
                tool_response_collapse=CollapseStrategyConfig(type="remove"),
            ),
            after_collapse_max_length=200,
            tool_response_collapse_whitelist=["important_tool"],
        )
        l2 = L2MicroCompaction(config)
        msgs = [
            LLMMessage(role="system", content="SP"),
            LLMMessage(role="user", content="Task"),
            LLMMessage(
                role="assistant", content="",
                tool_calls=[ToolCall(id="tc1", name="important_tool", arguments={})],
            ),
            LLMMessage(
                role="tool", content="important data " * 50,
                tool_call_id="tc1", name="important_tool",
            ),
            LLMMessage(role="assistant", content="Done"),
        ]
        result = l2.compact(msgs, current_step=1)
        # important_tool's response should not be emptied
        tool_msgs = [m for m in result if m.role == "tool" and m.name == "important_tool"]
        for m in tool_msgs:
            assert m.content != ""

    def test_abandon_fallback(self):
        l2 = self._make_l2(max_length=100, protected_steps=0)
        msgs = _make_conversation(num_rounds=5, tool_response_len=1000)
        result = l2.compact(msgs, current_step=5)
        result_tokens = estimate_messages_tokens(result)
        assert result_tokens <= 100 or len(result) < len(msgs)


# ============================================================================
# Helper Tests
# ============================================================================

class TestContextMemoryHelper:
    def test_apply_l1_only(self):
        config = MemoryConfig(l1=L1Config())
        helper = ContextMemoryHelper(config)
        msgs = _make_conversation(num_rounds=2)
        result = helper.apply_l1(msgs)
        assert isinstance(result, list)
        assert len(result) > 0

    def test_apply_l2_without_config(self):
        config = MemoryConfig(l1=L1Config(), l2=None)
        helper = ContextMemoryHelper(config)
        msgs = _make_conversation(num_rounds=2)
        result = helper.apply_l2(msgs, current_step=1)
        assert result is msgs  # no-op

    def test_apply_l2_with_config(self):
        config = MemoryConfig(
            l1=L1Config(),
            l2=L2Config(after_collapse_max_length=200),
        )
        helper = ContextMemoryHelper(config)
        msgs = _make_conversation(num_rounds=3, tool_response_len=500)
        result = helper.apply_l2(msgs, current_step=3)
        assert isinstance(result, list)

    def test_shared_store(self):
        store = InMemoryStore()
        config = MemoryConfig(
            l1=L1Config(
                history_collapse=HistoryCollapseConfig(
                    thinking_collapse=CollapseStrategyConfig(
                        type="prefix_ref", collapse_prefix_length=10
                    ),
                ),
            ),
        )
        helper = ContextMemoryHelper(config, store=store)
        msgs = _make_conversation(num_rounds=3)
        helper.apply_l1(msgs)
        # Store should have entries from prefix_ref folding
        assert len(store) > 0

    def test_empty_messages(self):
        config = MemoryConfig(l1=L1Config())
        helper = ContextMemoryHelper(config)
        assert helper.apply_l1([]) == []
        assert helper.apply_l2([], current_step=0) == []

    def test_properties(self):
        store = InMemoryStore()
        config = MemoryConfig(l1=L1Config())
        helper = ContextMemoryHelper(config, store=store)
        assert helper.config is config
        assert helper.store is store
