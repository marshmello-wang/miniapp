"""
交互式 Web Chatbot 后端

串联 MessageStore，支持 user/session 管理和 round 存储。
默认 mock 模式，可选 --llm 接入真实 LLM。

启动方式:
    python -m common.agent_framework.tests.chatbot_server [--llm]
"""
import argparse
import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

from common.agent_framework.message_store import MessageStore


@asynccontextmanager
async def lifespan(app: FastAPI):
    global store
    store = MessageStore(db_path=str(DB_PATH))
    yield
    if store:
        store.close()


app = FastAPI(title="Agent Chatbot", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

HTML_PATH = Path(__file__).parent / "chatbot.html"
DB_PATH = Path(__file__).parent / "chatbot.db"

store: Optional[MessageStore] = None
use_llm = False


# ── Pydantic models ────────────────────────────────────────────────────

class CreateUserReq(BaseModel):
    user_id: str

class CreateSessionReq(BaseModel):
    session_id: Optional[str] = None

class ChatReq(BaseModel):
    content: str

class SetMemoryReq(BaseModel):
    data: Dict[str, Any]
    version: int = 1


# ── Helpers ─────────────────────────────────────────────────────────────

def _mock_reply(user_text: str) -> tuple:
    """
    Mock 模式：返回 (ai_content, trajectory)

    ai_content: [{"type":"text","content":"..."}]
    trajectory: agent 执行事件列表
    """
    trajectory = []

    if user_text.startswith("/tool "):
        tool_arg = user_text[6:].strip()
        trajectory = [
            {"event": "reasoning", "content": f"User requested tool call with: {tool_arg}"},
            {"event": "tool_call", "name": "mock_tool", "arguments": {"input": tool_arg}},
            {"event": "tool_result", "name": "mock_tool", "content": f"Mock result for: {tool_arg}"},
            {"event": "response", "content": f"Tool returned result for '{tool_arg}'. Task complete."},
        ]
        ai_content = [{"type": "text", "content": f"Tool returned result for '{tool_arg}'. Task complete."}]
    else:
        trajectory = [
            {"event": "reasoning", "content": f"Processing: {user_text}"},
            {"event": "response", "content": f"[Mock] You said: {user_text}"},
        ]
        ai_content = [{"type": "text", "content": f"[Mock] You said: {user_text}"}]

    return ai_content, trajectory


def _round_to_dict(rnd) -> dict:
    return {
        "round_idx": rnd.round_idx,
        "user_content": rnd.user_content,
        "ai_content": rnd.ai_content,
        "trajectory": rnd.trajectory,
        "created_at": rnd.created_at,
        "updated_at": rnd.updated_at,
    }


# ── Routes ──────────────────────────────────────────────────────────────

@app.get("/")
async def index():
    return FileResponse(HTML_PATH, media_type="text/html")


# ── User ──

@app.get("/api/users")
async def list_users():
    return {"users": store.list_users()}


@app.post("/api/users")
async def create_user(req: CreateUserReq):
    store.ensure_user(req.user_id)
    return {"user_id": req.user_id}


# ── Session ──

@app.get("/api/users/{uid}/sessions")
async def list_sessions(uid: str):
    sessions = store.list_sessions(uid)
    return {
        "sessions": [
            {
                "session_id": s.session_id,
                "created_at": s.created_at,
                "updated_at": s.updated_at,
                "round_count": s.round_count,
            }
            for s in sessions
        ]
    }


@app.post("/api/users/{uid}/sessions")
async def create_session(uid: str, req: CreateSessionReq):
    sid = store.create_session(uid, req.session_id)
    return {"session_id": sid}


# ── Rounds ──

@app.get("/api/sessions/{sid}/rounds")
async def get_rounds(sid: str):
    rounds = store.get_rounds(sid)
    return {"rounds": [_round_to_dict(r) for r in rounds]}


@app.get("/api/sessions/{sid}/rounds/{round_idx}")
async def get_round(sid: str, round_idx: int):
    rnd = store.get_round(sid, round_idx)
    if not rnd:
        return {"error": "Round not found"}, 404
    return {"round": _round_to_dict(rnd)}


@app.post("/api/sessions/{sid}/chat")
async def chat(sid: str, req: ChatReq):
    session_info = store.get_session(sid)
    if not session_info:
        return {"error": "Session not found"}, 404

    user_content = [{"type": "text", "content": req.content}]
    round_idx = store.start_round(sid, user_content)

    ai_content, trajectory = _mock_reply(req.content)
    store.complete_round(sid, round_idx, ai_content, trajectory)

    rnd = store.get_round(sid, round_idx)
    return {"round": _round_to_dict(rnd)}


# ── User Memory ──

@app.get("/api/users/{uid}/memory")
async def get_memory(uid: str):
    mem = store.get_user_memory(uid)
    return {
        "user_id": mem.user_id,
        "version": mem.version,
        "data": mem.data,
        "updated_at": mem.updated_at,
    }


@app.put("/api/users/{uid}/memory")
async def set_memory(uid: str, req: SetMemoryReq):
    store.set_user_memory(uid, req.data, req.version)
    return {"ok": True}


if __name__ == "__main__":
    import uvicorn

    parser = argparse.ArgumentParser()
    parser.add_argument("--llm", action="store_true", help="Use real LLM instead of mock")
    parser.add_argument("--port", type=int, default=8680)
    args = parser.parse_args()
    use_llm = args.llm

    uvicorn.run(app, host="127.0.0.1", port=args.port)
