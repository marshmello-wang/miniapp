"""
BashTool 测试用例

测试覆盖：
- BashTool: 正常执行、timeout 熔断、executor 异常、参数校验、输出截断
- LocalBashExecutor: 本地命令执行、非零 exit code、超时 kill
"""
import pytest
import asyncio
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..'))

from common.agent_framework.builtin_tools.bash_tool import (
    BashTool,
    BashExecutor,
    BashResult,
)
from common.agent_framework.builtin_tools.bash_executors import LocalBashExecutor


# ============================================================
# Mock Executor
# ============================================================

class MockBashExecutor:
    """可控的 mock executor，用于测试 BashTool 逻辑"""

    def __init__(
        self,
        result: BashResult = None,
        raise_timeout: bool = False,
        raise_exception: Exception = None,
        delay: float = 0,
    ):
        self._result = result or BashResult(exit_code=0, stdout="", stderr="")
        self._raise_timeout = raise_timeout
        self._raise_exception = raise_exception
        self._delay = delay
        self.last_command: str = ""
        self.last_timeout: float = 0
        self.call_count: int = 0

    async def execute(self, command: str, timeout: float) -> BashResult:
        self.last_command = command
        self.last_timeout = timeout
        self.call_count += 1

        if self._delay > 0:
            await asyncio.sleep(self._delay)

        if self._raise_timeout:
            raise asyncio.TimeoutError()

        if self._raise_exception:
            raise self._raise_exception

        return self._result


def _run(coro):
    """同步运行 async 协程的辅助函数"""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


# ============================================================
# TestBashTool - BashTool 单元测试
# ============================================================

class TestBashTool:
    """BashTool 单元测试（使用 mock executor）"""

    def test_schema(self):
        """schema 结构正确"""
        executor = MockBashExecutor()
        tool = BashTool(executor=executor)

        assert tool.name == "bash"
        assert "command" in tool.schema.schema["properties"]
        assert "timeout" in tool.schema.schema["properties"]
        assert "command" in tool.schema.schema["required"]

    def test_schema_json(self):
        """to_json_schema 输出完整"""
        executor = MockBashExecutor()
        tool = BashTool(executor=executor)
        json_schema = tool.schema.to_json_schema()

        assert json_schema["name"] == "bash"
        assert "parameters" in json_schema
        assert json_schema["parameters"]["properties"]["command"]["type"] == "string"

    def test_execute_success(self):
        """正常执行返回 stdout/stderr/exit_code"""
        executor = MockBashExecutor(
            result=BashResult(exit_code=0, stdout="hello\n", stderr="")
        )
        tool = BashTool(executor=executor)

        result = _run(tool.execute({"command": "echo hello"}))

        assert result.success is True
        assert result.data["exit_code"] == 0
        assert result.data["stdout"] == "hello\n"
        assert result.data["stderr"] == ""
        assert "Exit code: 0" in result.formatted_data
        assert "hello" in result.formatted_data
        assert executor.last_command == "echo hello"

    def test_execute_with_stderr(self):
        """命令有 stderr 输出"""
        executor = MockBashExecutor(
            result=BashResult(exit_code=1, stdout="", stderr="error msg\n")
        )
        tool = BashTool(executor=executor)

        result = _run(tool.execute({"command": "failing_cmd"}))

        assert result.success is True
        assert result.data["exit_code"] == 1
        assert "error msg" in result.formatted_data
        assert "--- stderr ---" in result.formatted_data

    def test_execute_empty_command(self):
        """空命令返回错误"""
        executor = MockBashExecutor()
        tool = BashTool(executor=executor)

        result = _run(tool.execute({"command": ""}))
        assert result.success is False
        assert "required" in result.error

    def test_execute_missing_command(self):
        """缺少 command 参数"""
        executor = MockBashExecutor()
        tool = BashTool(executor=executor)

        result = _run(tool.execute({}))
        assert result.success is False
        assert "required" in result.error

    def test_timeout_from_executor(self):
        """executor 抛出 TimeoutError 时返回熔断错误"""
        executor = MockBashExecutor(raise_timeout=True)
        tool = BashTool(executor=executor, default_timeout=5.0)

        result = _run(tool.execute({"command": "sleep 100"}))

        assert result.success is False
        assert "timed out" in result.error.lower()
        assert result.metadata["timeout"] == 5.0

    def test_timeout_override(self):
        """参数中的 timeout 覆盖默认值"""
        executor = MockBashExecutor(
            result=BashResult(exit_code=0, stdout="ok", stderr="")
        )
        tool = BashTool(executor=executor, default_timeout=60.0)

        _run(tool.execute({"command": "echo ok", "timeout": 10}))

        assert executor.last_timeout == 10.0

    def test_executor_exception(self):
        """executor 抛出非超时异常"""
        executor = MockBashExecutor(
            raise_exception=RuntimeError("connection lost")
        )
        tool = BashTool(executor=executor)

        result = _run(tool.execute({"command": "echo hi"}))

        assert result.success is False
        assert "connection lost" in result.error

    def test_output_truncation(self):
        """超长输出被截断"""
        long_output = "x" * 100000
        executor = MockBashExecutor(
            result=BashResult(exit_code=0, stdout=long_output, stderr="")
        )
        tool = BashTool(executor=executor, max_output_length=1000)

        result = _run(tool.execute({"command": "big_output"}))

        assert result.success is True
        assert len(result.data["stdout"]) < len(long_output)
        assert "truncated" in result.data["stdout"]

    def test_no_truncation_within_limit(self):
        """输出未超限时不截断"""
        output = "hello world"
        executor = MockBashExecutor(
            result=BashResult(exit_code=0, stdout=output, stderr="")
        )
        tool = BashTool(executor=executor, max_output_length=50000)

        result = _run(tool.execute({"command": "echo hello world"}))

        assert result.data["stdout"] == output

    def test_formatted_data_no_empty_sections(self):
        """stdout 为空时不输出 --- stdout --- 段"""
        executor = MockBashExecutor(
            result=BashResult(exit_code=0, stdout="", stderr="warn\n")
        )
        tool = BashTool(executor=executor)

        result = _run(tool.execute({"command": "cmd"}))

        assert "--- stdout ---" not in result.formatted_data
        assert "--- stderr ---" in result.formatted_data


# ============================================================
# TestLocalBashExecutor - 本地执行器集成测试
# ============================================================

class TestLocalBashExecutor:
    """LocalBashExecutor 集成测试（实际执行本地命令）"""

    def test_echo(self):
        """执行简单 echo 命令"""
        executor = LocalBashExecutor()
        result = _run(executor.execute("echo hello", timeout=5.0))

        assert result.exit_code == 0
        assert result.stdout.strip() == "hello"
        assert result.stderr == ""

    def test_nonzero_exit(self):
        """非零 exit code"""
        executor = LocalBashExecutor()
        result = _run(executor.execute("exit 42", timeout=5.0))

        assert result.exit_code == 42

    def test_stderr_output(self):
        """stderr 输出"""
        executor = LocalBashExecutor()
        result = _run(executor.execute("echo err >&2", timeout=5.0))

        assert result.exit_code == 0
        assert "err" in result.stderr

    def test_timeout_kills_process(self):
        """超时时 kill 进程并抛出 TimeoutError"""
        executor = LocalBashExecutor()

        with pytest.raises(asyncio.TimeoutError):
            _run(executor.execute("sleep 60", timeout=0.5))

    def test_multiline_output(self):
        """多行输出"""
        executor = LocalBashExecutor()
        result = _run(executor.execute("echo line1; echo line2", timeout=5.0))

        assert result.exit_code == 0
        lines = result.stdout.strip().split("\n")
        assert lines == ["line1", "line2"]
