"""
Tool Adapter 模块测试用例

测试覆盖：
- ToolContext: 上下文管理
- ToolSchema / ToolResult: 协议数据结构
- tool 装饰器: 参数推导和工具创建
- LocalTool: 本地工具执行
- ToolRegistry: 工具注册中心
- ToolExecutor: 工具执行器
- MCPTool: MCP 工具包装（基础功能）
"""
import pytest
import asyncio
import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..'))

from common.agent_framework.tool_adapter import (
    Tool, ToolSchema, ToolResult, ToolContext,
    tool, LocalTool,
    ToolRegistry, ToolExecutor,
    MCPTool
)
from common.agent_framework.tool_adapter.decorators import (
    _type_to_schema, _infer_parameters_from_signature
)


# ============================================================
# ToolContext 测试
# ============================================================

class TestToolContext:
    """ToolContext 测试类"""
    
    def test_init_empty(self):
        """测试空初始化"""
        ctx = ToolContext()
        assert ctx.session_id is None
        assert ctx.to_dict() == {}
    
    def test_init_with_session_id(self):
        """测试带 session_id 初始化"""
        ctx = ToolContext(session_id="test-session-123")
        assert ctx.session_id == "test-session-123"
        assert ctx.to_dict() == {"session_id": "test-session-123"}
    
    def test_init_with_initial_data(self):
        """测试带初始数据初始化"""
        ctx = ToolContext(initial_data={"key1": "value1", "key2": 42})
        assert ctx.get("key1") == "value1"
        assert ctx.get("key2") == 42
    
    def test_set_and_get(self):
        """测试 set 和 get 方法"""
        ctx = ToolContext()
        ctx.set("name", "test")
        ctx.set("count", 100)
        ctx.set("data", {"nested": True})
        
        assert ctx.get("name") == "test"
        assert ctx.get("count") == 100
        assert ctx.get("data") == {"nested": True}
    
    def test_get_with_default(self):
        """测试 get 默认值"""
        ctx = ToolContext()
        assert ctx.get("nonexistent") is None
        assert ctx.get("nonexistent", "default") == "default"
        assert ctx.get("nonexistent", 0) == 0
    
    def test_update(self):
        """测试批量更新"""
        ctx = ToolContext()
        ctx.set("existing", "value")
        ctx.update({"new1": 1, "new2": 2, "existing": "updated"})
        
        assert ctx.get("existing") == "updated"
        assert ctx.get("new1") == 1
        assert ctx.get("new2") == 2
    
    def test_has(self):
        """测试 has 方法"""
        ctx = ToolContext()
        ctx.set("key1", "value1")
        
        assert ctx.has("key1") is True
        assert ctx.has("key2") is False
    
    def test_clear(self):
        """测试清空"""
        ctx = ToolContext(session_id="session", initial_data={"k": "v"})
        ctx.set("another", "value")
        ctx.clear()
        
        assert ctx.get("k") is None
        assert ctx.get("another") is None
        # session_id 不受 clear 影响
        assert ctx.session_id == "session"
    
    def test_to_dict(self):
        """测试转换为字典"""
        ctx = ToolContext(session_id="sess-001")
        ctx.set("key1", "value1")
        ctx.set("key2", 42)
        
        result = ctx.to_dict()
        assert result == {
            "session_id": "sess-001",
            "key1": "value1",
            "key2": 42
        }

# ============================================================
# Decorators 测试
# ============================================================

class TestTypeToSchema:
    """_type_to_schema 函数测试"""
    
    def test_basic_types(self):
        """测试基础类型映射"""
        assert _type_to_schema(str) == "string"
        assert _type_to_schema(int) == "integer"
        assert _type_to_schema(float) == "number"
        assert _type_to_schema(bool) == "boolean"
        assert _type_to_schema(list) == "array"
        assert _type_to_schema(dict) == "object"
    
    def test_unknown_type_defaults_to_string(self):
        """测试未知类型默认为 string"""
        class CustomType:
            pass
        assert _type_to_schema(CustomType) == "string"


class TestInferParametersFromSignature:
    """_infer_parameters_from_signature 函数测试"""
    
    def test_simple_function(self):
        """测试简单函数参数推导"""
        async def simple_func(name: str, count: int):
            pass
        
        params = _infer_parameters_from_signature(simple_func)
        
        assert len(params) == 2
        assert params[0]["name"] == "name"
        assert params[0]["type"] == "string"
        assert params[0]["required"] is True
        assert params[1]["name"] == "count"
        assert params[1]["type"] == "integer"
        assert params[1]["required"] is True
    
    def test_function_with_defaults(self):
        """测试带默认值函数参数推导"""
        async def func_with_defaults(query: str, limit: int = 10, active: bool = True):
            pass
        
        params = _infer_parameters_from_signature(func_with_defaults)
        
        assert len(params) == 3
        assert params[0]["required"] is True
        assert params[1]["required"] is False
        assert params[1]["default"] == 10
        assert params[2]["required"] is False
        assert params[2]["default"] is True
    
    def test_function_with_context(self):
        """测试带 context 参数的函数（context 应被排除）"""
        async def func_with_context(query: str, context: ToolContext = None):
            pass
        
        params = _infer_parameters_from_signature(func_with_context)
        
        assert len(params) == 1
        assert params[0]["name"] == "query"
    
    def test_function_with_complex_types(self):
        """测试复杂类型参数推导"""
        async def func_complex(items: list, config: dict):
            pass
        
        params = _infer_parameters_from_signature(func_complex)
        
        assert params[0]["type"] == "array"
        assert params[1]["type"] == "object"
    
    def test_function_with_list_of_struct(self):
        """测试 List[struct] 类型参数推导"""
        from typing import List, Dict
        from dataclasses import dataclass
        
        @dataclass
        class Item:
            name: str
            value: int
        
        # 测试 List[Dict] 类型
        async def func_list_dict(items: List[Dict[str, str]]):
            pass
        
        params = _infer_parameters_from_signature(func_list_dict)
        assert len(params) == 1
        assert params[0]["name"] == "items"
        assert params[0]["type"] == "array"  # List 被推导为 array
        assert params[0]["items"]["type"] == "object"
        
        # 测试 List[dataclass] 类型
        async def func_list_dataclass(records: List[Item], count: int = 10):
            pass
        
        params = _infer_parameters_from_signature(func_list_dataclass)
        assert len(params) == 2
        assert params[0]["name"] == "records"
        assert params[0]["type"] == "array"  # List[Item] 被推导为 array
        assert params[0]["items"]["type"] == "string"
        assert params[1]["name"] == "count"
        assert params[1]["type"] == "integer"
        
        # 测试 list[dict] (Python 3.9+ 内置泛型语法)
        async def func_builtin_generic(data: list[dict]):
            pass
        
        params = _infer_parameters_from_signature(func_builtin_generic)
        assert len(params) == 1
        assert params[0]["name"] == "data"
        assert params[0]["type"] == "array"
        assert params[0]["items"]["type"] == "object"


class TestToolDecorator:
    """@tool 装饰器测试"""
    
    def test_basic_decorator(self):
        """测试基础装饰器使用"""
        @tool(description="A simple test tool")
        async def simple_tool(name: str):
            return f"Hello, {name}!"
        
        assert isinstance(simple_tool, LocalTool)
        assert simple_tool.name == "simple_tool"
        assert simple_tool.description == "A simple test tool"
    
    def test_decorator_with_custom_name(self):
        """测试自定义工具名"""
        @tool(name="custom_name", description="Custom named tool")
        async def original_name(x: int):
            return x * 2
        
        assert original_name.name == "custom_name"
    
    def test_decorator_with_explicit_parameters(self):
        """测试显式指定参数 schema"""
        @tool(
            description="Tool with explicit params",
            parameters=[
                {"name": "path", "type": "string", "description": "File path", "required": True},
                {"name": "mode", "type": "string", "description": "Read mode", "required": False, "default": "r"}
            ]
        )
        async def read_tool(path: str, mode: str = "r"):
            return "content"
        
        schema = read_tool.schema.to_json_schema()
        assert "path" in schema["parameters"]["properties"]
        assert schema["parameters"]["properties"]["path"]["description"] == "File path"

    def test_decorator_preserves_array_items_schema(self):
        """测试显式 parameters 的 items 字段会保留"""
        @tool(
            description="Array param tool",
            parameters=[
                {
                    "name": "new_lines",
                    "type": "array",
                    "items": {"type": "string"},
                    "required": True,
                }
            ],
        )
        async def array_tool(new_lines):
            return len(new_lines)

        schema = array_tool.schema.to_json_schema()
        prop = schema["parameters"]["properties"]["new_lines"]
        assert prop["type"] == "array"
        assert prop["items"]["type"] == "string"


# ============================================================
# LocalTool 测试
# ============================================================

class TestLocalTool:
    """LocalTool 测试类"""
    
    def test_properties(self):
        """测试工具属性"""
        @tool(description="Test tool properties")
        async def test_func(arg1: str, arg2: int = 5):
            return arg1 * arg2
        
        assert test_func.name == "test_func"
        assert test_func.description == "Test tool properties"
        
        schema = test_func.schema
        assert schema.name == "test_func"
        assert "arg1" in schema.schema["properties"]
        assert "arg2" in schema.schema["properties"]
    
    @pytest.mark.asyncio
    async def test_execute_async_function(self):
        """测试执行异步函数"""
        @tool(description="Async tool")
        async def async_tool(x: int, y: int):
            await asyncio.sleep(0.01)
            return x + y
        
        result = await async_tool.execute({"x": 3, "y": 5})
        
        assert result.success is True
        assert result.data == 8
        assert result.tool_name == "async_tool"
    
    @pytest.mark.asyncio
    async def test_execute_sync_function(self):
        """测试执行同步函数（自动包装）"""
        @tool(description="Sync tool")
        def sync_tool(message: str):
            return message.upper()
        
        result = await sync_tool.execute({"message": "hello"})
        
        assert result.success is True
        assert result.data == "HELLO"
    
    @pytest.mark.asyncio
    async def test_execute_with_context(self):
        """测试执行时传入 context"""
        @tool(description="Tool with context")
        async def context_tool(value: str, context: ToolContext = None):
            if context:
                context.set("last_value", value)
            return f"Processed: {value}"
        
        ctx = ToolContext()
        result = await context_tool.execute({"value": "test"}, context=ctx)
        
        assert result.success is True
        assert ctx.get("last_value") == "test"
    
    @pytest.mark.asyncio
    async def test_execute_with_error(self):
        """测试执行时发生错误"""
        @tool(description="Error tool")
        async def error_tool(x: int):
            raise ValueError("Intentional error")
        
        result = await error_tool.execute({"x": 1})
        
        assert result.success is False
        assert "Intentional error" in result.error
    
    @pytest.mark.asyncio
    async def test_result_formatter(self):
        """测试自定义结果格式化"""
        @tool(
            description="Formatted tool",
            result_formatter=lambda items: f"Found {len(items)} items"
        )
        async def search_tool(query: str):
            return ["item1", "item2", "item3"]
        
        result = await search_tool.execute({"query": "test"})
        
        assert result.success is True
        assert result.data == ["item1", "item2", "item3"]
        assert result.formatted_data == "Found 3 items"
    
    @pytest.mark.asyncio
    async def test_max_result_length(self):
        """测试结果长度截断"""
        @tool(
            description="Long result tool",
            max_result_length=50
        )
        async def long_result_tool():
            return "A" * 100
        
        result = await long_result_tool.execute({})
        
        assert result.success is True
        assert len(result.formatted_data) < 100
        assert "truncated" in result.formatted_data


# ============================================================
# ToolRegistry 测试
# ============================================================

class TestToolRegistry:
    """ToolRegistry 测试类"""
    
    def test_register_and_get(self):
        """测试注册和获取工具"""
        registry = ToolRegistry()
        
        @tool(description="Tool 1")
        async def tool1():
            pass
        
        registry.register(tool1)
        
        retrieved = registry.get("tool1")
        assert retrieved is tool1
    
    def test_register_duplicate_raises_error(self):
        """测试重复注册抛出异常"""
        registry = ToolRegistry()
        
        @tool(description="Tool")
        async def my_tool():
            pass
        
        registry.register(my_tool)
        
        with pytest.raises(ValueError, match="already registered"):
            registry.register(my_tool)
    
    def test_unregister(self):
        """测试注销工具"""
        registry = ToolRegistry()
        
        @tool(description="Tool")
        async def temp_tool():
            pass
        
        registry.register(temp_tool)
        assert registry.has_tool("temp_tool") is True
        
        registry.unregister("temp_tool")
        assert registry.has_tool("temp_tool") is False
    
    def test_unregister_nonexistent_no_error(self):
        """测试注销不存在的工具不报错"""
        registry = ToolRegistry()
        registry.unregister("nonexistent")  # Should not raise
    
    def test_has_tool(self):
        """测试 has_tool 方法"""
        registry = ToolRegistry()
        
        @tool(description="Tool")
        async def check_tool():
            pass
        
        assert registry.has_tool("check_tool") is False
        registry.register(check_tool)
        assert registry.has_tool("check_tool") is True
    
    def test_list_tools(self):
        """测试列出所有工具"""
        registry = ToolRegistry()
        
        @tool(description="Tool 1")
        async def tool_a():
            pass
        
        @tool(description="Tool 2")
        async def tool_b():
            pass
        
        registry.register(tool_a)
        registry.register(tool_b)
        
        tools = registry.list_tools()
        assert len(tools) == 2
        names = [t.name for t in tools]
        assert "tool_a" in names
        assert "tool_b" in names
    
    def test_get_tools_schema(self):
        """测试获取所有工具的 schema"""
        registry = ToolRegistry()
        
        @tool(description="Search tool")
        async def search(query: str, limit: int = 10):
            pass
        
        registry.register(search)
        
        schemas = registry.get_tools_schema()
        assert len(schemas) == 1
        assert schemas[0]["name"] == "search"
        assert schemas[0]["description"] == "Search tool"
        assert "parameters" in schemas[0]
    
    def test_clear(self):
        """测试清空注册中心"""
        registry = ToolRegistry()
        
        @tool(description="Tool")
        async def clear_test_tool():
            pass
        
        registry.register(clear_test_tool)
        assert len(registry) == 1
        
        registry.clear()
        assert len(registry) == 0
    
    def test_len(self):
        """测试 len() 方法"""
        registry = ToolRegistry()
        assert len(registry) == 0
        
        @tool(description="Tool 1")
        async def t1():
            pass
        
        @tool(description="Tool 2")
        async def t2():
            pass
        
        registry.register(t1)
        assert len(registry) == 1
        
        registry.register(t2)
        assert len(registry) == 2


# ============================================================
# ToolExecutor 测试
# ============================================================

class TestToolExecutor:
    """ToolExecutor 测试类"""
    
    @pytest.fixture
    def setup_executor(self):
        """设置执行器和工具"""
        registry = ToolRegistry()
        executor = ToolExecutor(registry)
        
        @tool(description="Add two numbers")
        async def add(a: int, b: int):
            return a + b
        
        @tool(description="Tool with context")
        async def stateful_tool(value: str, context: ToolContext = None):
            if context:
                context.set("processed", value)
            return f"OK: {value}"
        
        @tool(description="Error tool")
        async def fail_tool():
            raise RuntimeError("Intentional failure")
        
        registry.register(add)
        registry.register(stateful_tool)
        registry.register(fail_tool)
        
        return executor
    
    @pytest.mark.asyncio
    async def test_execute_success(self, setup_executor):
        """测试成功执行工具"""
        executor = setup_executor
        
        result = await executor.execute("add", {"a": 3, "b": 7})
        
        assert result.success is True
        assert result.data == 10
        assert result.tool_name == "add"
    
    @pytest.mark.asyncio
    async def test_execute_nonexistent_tool(self, setup_executor):
        """测试执行不存在的工具"""
        executor = setup_executor
        
        result = await executor.execute("nonexistent_tool", {})
        
        assert result.success is False
        assert "not found" in result.error
        assert result.tool_name == "nonexistent_tool"
    
    @pytest.mark.asyncio
    async def test_execute_with_context(self, setup_executor):
        """测试执行时传递 context"""
        executor = setup_executor
        ctx = ToolContext(session_id="test-session")
        
        result = await executor.execute(
            "stateful_tool",
            {"value": "hello"},
            context=ctx
        )
        
        assert result.success is True
        assert ctx.get("processed") == "hello"
    
    @pytest.mark.asyncio
    async def test_execute_with_call_id(self, setup_executor):
        """测试执行时设置 call_id"""
        executor = setup_executor
        
        result = await executor.execute(
            "add",
            {"a": 1, "b": 2},
            call_id="call-abc-123"
        )
        
        assert result.success is True
        assert result.call_id == "call-abc-123"
    
    @pytest.mark.asyncio
    async def test_execute_with_exception(self, setup_executor):
        """测试执行时捕获异常"""
        executor = setup_executor
        
        result = await executor.execute("fail_tool", {})
        
        assert result.success is False
        assert "Intentional failure" in result.error


# ============================================================
# MCPTool 测试（基础功能）
# ============================================================

class TestMCPTool:
    """MCPTool 测试类"""
    
    def test_name_with_namespace(self):
        """测试带命名空间的工具名"""
        mcp_tool = MCPTool(
            mcp_tool_info={"name": "read_file", "description": "Read a file"},
            session=None,
            namespace="fs"
        )
        
        assert mcp_tool.name == "fs:read_file"
    
    def test_description(self):
        """测试描述获取"""
        mcp_tool = MCPTool(
            mcp_tool_info={"name": "tool", "description": "Tool description"},
            session=None,
            namespace="ns"
        )
        
        assert mcp_tool.description == "Tool description"
    
    def test_description_empty(self):
        """测试空描述"""
        mcp_tool = MCPTool(
            mcp_tool_info={"name": "tool"},
            session=None,
            namespace="ns"
        )
        
        assert mcp_tool.description == ""
    
    def test_schema(self):
        """测试 schema 属性"""
        mcp_tool = MCPTool(
            mcp_tool_info={
                "name": "search",
                "description": "Search tool",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"}
                    },
                    "required": ["query"]
                }
            },
            session=None,
            namespace="remote"
        )
        
        schema = mcp_tool.schema
        assert schema.name == "remote:search"
        assert schema.description == "Search tool"
        assert schema.schema["type"] == "object"
        assert "query" in schema.schema["properties"]
    
    def test_schema_empty_input_schema(self):
        """测试空 inputSchema 情况"""
        mcp_tool = MCPTool(
            mcp_tool_info={"name": "simple_tool"},
            session=None,
            namespace="ns"
        )
        
        schema = mcp_tool.schema
        # 当 inputSchema 不存在时，返回空字典（实际代码行为）
        assert schema.schema == {}
    
    @pytest.mark.asyncio
    async def test_execute_not_implemented(self):
        """测试执行返回 NotImplementedError（MCP 未完全实现）"""
        mcp_tool = MCPTool(
            mcp_tool_info={"name": "tool"},
            session=None,
            namespace="ns"
        )
        
        result = await mcp_tool.execute({"param": "value"})
        
        assert result.success is False
        assert "not yet implemented" in result.error.lower()


# ============================================================
# 集成测试
# ============================================================

class TestIntegration:
    """集成测试"""
    
    @pytest.mark.asyncio
    async def test_full_workflow(self):
        """测试完整工作流程"""
        # 1. 创建注册中心和执行器
        registry = ToolRegistry()
        executor = ToolExecutor(registry)
        
        # 2. 定义工具
        @tool(description="记录消息")
        async def log_message(message: str, context: ToolContext = None):
            if context:
                logs = context.get("logs", [])
                logs.append(message)
                context.set("logs", logs)
            return f"Logged: {message}"
        
        @tool(description="获取日志数量")
        async def get_log_count(context: ToolContext = None):
            if context:
                logs = context.get("logs", [])
                return len(logs)
            return 0
        
        # 3. 注册工具
        registry.register(log_message)
        registry.register(get_log_count)
        
        # 4. 验证工具 schema
        schemas = registry.get_tools_schema()
        assert len(schemas) == 2
        
        # 5. 创建上下文并执行工具链
        ctx = ToolContext(session_id="integration-test")
        
        await executor.execute("log_message", {"message": "First"}, context=ctx)
        await executor.execute("log_message", {"message": "Second"}, context=ctx)
        
        result = await executor.execute("get_log_count", {}, context=ctx)
        
        assert result.success is True
        assert result.data == 2
        assert ctx.get("logs") == ["First", "Second"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
