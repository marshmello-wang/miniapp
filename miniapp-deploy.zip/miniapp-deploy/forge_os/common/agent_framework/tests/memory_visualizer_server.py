"""
Memory L1/L2 可视化测试后端

直接 import 真实的 memory 模块代码，通过 HTTP API 暴露给前端。
启动方式: python -m common.agent_framework.tests.memory_visualizer_server
"""
import json
import os
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

from common.agent_framework.context_strategy.memory.config import (
    AllocationBudgetConfig,
    CollapseStrategyConfig,
    HistoryCollapseConfig,
    L1Config,
    L2Config,
    MemoryConfig,
)
from common.agent_framework.context_strategy.memory.helper import ContextMemoryHelper
from common.agent_framework.context_strategy.memory.store import InMemoryStore
from common.agent_framework.context_strategy.memory.token_utils import (
    estimate_message_tokens,
    estimate_messages_tokens,
)
from common.llm import Message, ToolCall

app = FastAPI(title="Memory L1/L2 Visualizer")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

HTML_PATH = Path(__file__).parent / "memory_visualizer.html"


# ── Request / Response models ──────────────────────────────────────────

class ToolCallData(BaseModel):
    id: str
    name: str
    arguments: Dict[str, Any] = {}

class MessageData(BaseModel):
    role: str
    content: str = ""
    tool_call_id: Optional[str] = None
    name: Optional[str] = None
    tool_calls: Optional[List[ToolCallData]] = None
    thinking: Optional[str] = None

class CollapseConfigData(BaseModel):
    type: str = "none"
    collapse_prefix_length: int = 200

class HistoryCollapseData(BaseModel):
    thinking_collapse: CollapseConfigData = CollapseConfigData(type="remove")
    tool_call_collapse: CollapseConfigData = CollapseConfigData(type="none")
    tool_response_collapse: CollapseConfigData = CollapseConfigData(type="prefix", collapse_prefix_length=200)

class BudgetData(BaseModel):
    max_total: int = 2000
    sp: int = 100
    memory: int = 100
    react: int = 200
    final_out: int = 200

class L1ConfigData(BaseModel):
    budget: BudgetData = BudgetData()
    collapse: HistoryCollapseData = HistoryCollapseData()
    tc_whitelist: List[str] = []
    tr_whitelist: List[str] = []

class L2ConfigData(BaseModel):
    enabled: bool = True
    after_collapse_max: int = 800
    protected_steps: int = 1
    fallback: str = "abandon"
    current_step: int = 3
    collapse: HistoryCollapseData = HistoryCollapseData()
    tc_whitelist: List[str] = []
    tr_whitelist: List[str] = []

class ProcessRequest(BaseModel):
    messages: List[MessageData]
    l1: L1ConfigData
    l2: L2ConfigData


# ── Conversion helpers ─────────────────────────────────────────────────

def _to_message(d: MessageData) -> Message:
    tool_calls = None
    if d.tool_calls:
        tool_calls = [ToolCall(id=tc.id, name=tc.name, arguments=tc.arguments) for tc in d.tool_calls]
    return Message(
        role=d.role,
        content=d.content,
        tool_call_id=d.tool_call_id,
        name=d.name,
        tool_calls=tool_calls,
        thinking=d.thinking,
    )


def _tag_orig_idx(messages: List[Message]) -> List[Message]:
    """为每条消息打上原始索引标记，便于处理后追溯来源"""
    for i, m in enumerate(messages):
        m._orig_idx = i
    return messages


def _from_message(m: Message) -> dict:
    d: Dict[str, Any] = {"role": m.role, "content": m.content if m.content is not None else ""}
    if m.tool_call_id is not None:
        d["tool_call_id"] = m.tool_call_id
    if m.name is not None:
        d["name"] = m.name
    if m.tool_calls:
        d["tool_calls"] = [{"id": tc.id, "name": tc.name, "arguments": tc.arguments} for tc in m.tool_calls]
    if m.thinking is not None:
        d["thinking"] = m.thinking
    orig_idx = getattr(m, '_orig_idx', None)
    if orig_idx is not None:
        d["_orig_idx"] = orig_idx
    return d


def _build_collapse(cfg: HistoryCollapseData) -> HistoryCollapseConfig:
    return HistoryCollapseConfig(
        thinking_collapse=CollapseStrategyConfig(type=cfg.thinking_collapse.type, collapse_prefix_length=cfg.thinking_collapse.collapse_prefix_length),
        tool_call_collapse=CollapseStrategyConfig(type=cfg.tool_call_collapse.type),
        tool_response_collapse=CollapseStrategyConfig(type=cfg.tool_response_collapse.type, collapse_prefix_length=cfg.tool_response_collapse.collapse_prefix_length),
    )


def _build_l1(cfg: L1ConfigData) -> L1Config:
    return L1Config(
        budget=AllocationBudgetConfig(
            max_total_tokens=cfg.budget.max_total,
            system_prompt_tokens=cfg.budget.sp,
            memory_tokens=cfg.budget.memory,
            react_stack_reserve=cfg.budget.react,
            final_output_reserve=cfg.budget.final_out,
        ),
        history_collapse=_build_collapse(cfg.collapse),
        tool_call_collapse_whitelist=cfg.tc_whitelist,
        tool_response_collapse_whitelist=cfg.tr_whitelist,
    )


def _build_l2(cfg: L2ConfigData) -> Optional[L2Config]:
    if not cfg.enabled:
        return None
    return L2Config(
        history_collapse=_build_collapse(cfg.collapse),
        after_collapse_max_length=cfg.after_collapse_max,
        tool_call_collapse_whitelist=cfg.tc_whitelist,
        tool_response_collapse_whitelist=cfg.tr_whitelist,
        protected_steps=cfg.protected_steps,
        fallback_strategy=cfg.fallback,
    )


# ── Routes ─────────────────────────────────────────────────────────────

@app.get("/")
async def index():
    return FileResponse(HTML_PATH, media_type="text/html")


@app.post("/process")
async def process(req: ProcessRequest):
    messages = _tag_orig_idx([_to_message(m) for m in req.messages])
    l1_config = _build_l1(req.l1)
    l2_config = _build_l2(req.l2)
    current_step = req.l2.current_step

    # L1 only
    l1_store = InMemoryStore()
    l1_helper = ContextMemoryHelper(MemoryConfig(l1=l1_config), store=l1_store)
    l1_result = l1_helper.apply_l1(deepcopy(messages))

    # L2 only (on original messages)
    l2_store = InMemoryStore()
    if l2_config:
        l2_helper = ContextMemoryHelper(MemoryConfig(l1=l1_config, l2=l2_config), store=l2_store)
        l2_result = l2_helper.apply_l2(deepcopy(messages), current_step)
    else:
        l2_result = deepcopy(messages)

    # L1 + L2
    both_store = InMemoryStore()
    both_helper = ContextMemoryHelper(MemoryConfig(l1=l1_config, l2=l2_config), store=both_store)
    both_after_l1 = both_helper.apply_l1(deepcopy(messages))
    both_result = both_helper.apply_l2(both_after_l1, current_step) if l2_config else both_after_l1

    return {
        "l1": [_from_message(m) for m in l1_result],
        "l2": [_from_message(m) for m in l2_result],
        "both": [_from_message(m) for m in both_result],
        "stores": {
            "l1": dict(l1_store._data),
            "l2": dict(l2_store._data),
            "both": dict(both_store._data),
        },
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8679)
