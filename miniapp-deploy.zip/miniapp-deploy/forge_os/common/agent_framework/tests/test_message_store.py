"""
MessageStore 单元测试

覆盖:
- User CRUD
- Session CRUD
- Round 创建 (start_round / complete_round)
- Round 查询 (get_rounds / get_round)
- Session store KV 读写
- Cross-session user memory
- SqliteExpiredContentStore 协议兼容
"""
import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..'))

from common.agent_framework.message_store import (
    MessageStore,
    SessionInfo,
    Round,
    UserMemory,
    SqliteExpiredContentStore,
)


@pytest.fixture
def store():
    s = MessageStore(db_path=":memory:")
    yield s
    s.close()


@pytest.fixture
def session(store):
    """创建一个预置 user + session"""
    sid = store.create_session("user_a")
    return store, sid


# ============================================================================
# User Tests
# ============================================================================

class TestUser:
    def test_ensure_user_idempotent(self, store):
        store.ensure_user("u1")
        store.ensure_user("u1")
        assert store.list_users() == ["u1"]

    def test_list_users_ordered(self, store):
        store.ensure_user("u2")
        store.ensure_user("u1")
        users = store.list_users()
        assert "u1" in users
        assert "u2" in users


# ============================================================================
# Session Tests
# ============================================================================

class TestSession:
    def test_create_session_auto_id(self, store):
        sid = store.create_session("u1")
        assert sid.startswith("sess_")

    def test_create_session_custom_id(self, store):
        sid = store.create_session("u1", session_id="my_session")
        assert sid == "my_session"

    def test_create_session_ensures_user(self, store):
        store.create_session("new_user")
        assert "new_user" in store.list_users()

    def test_list_sessions(self, store):
        store.create_session("u1", "s1")
        store.create_session("u1", "s2")
        store.create_session("u2", "s3")
        sessions = store.list_sessions("u1")
        assert len(sessions) == 2
        sids = {s.session_id for s in sessions}
        assert sids == {"s1", "s2"}

    def test_get_session(self, store):
        store.create_session("u1", "s1")
        info = store.get_session("s1")
        assert info is not None
        assert info.session_id == "s1"
        assert info.user_id == "u1"
        assert info.round_count == 0

    def test_get_session_not_found(self, store):
        assert store.get_session("nonexistent") is None

    def test_session_round_count(self, session):
        store, sid = session
        store.start_round(sid, [{"type": "text", "content": "hi"}])
        store.start_round(sid, [{"type": "text", "content": "hello"}])
        info = store.get_session(sid)
        assert info.round_count == 2


# ============================================================================
# Round Tests
# ============================================================================

class TestRounds:
    def test_start_round_returns_sequential_idx(self, session):
        store, sid = session
        idx0 = store.start_round(sid, [{"type": "text", "content": "Q1"}])
        idx1 = store.start_round(sid, [{"type": "text", "content": "Q2"}])
        assert idx0 == 0
        assert idx1 == 1

    def test_start_round_stores_user_content(self, session):
        store, sid = session
        user_content = [
            {"type": "text", "content": "你好"},
            {"type": "image", "content": "base64data"},
        ]
        idx = store.start_round(sid, user_content)
        rnd = store.get_round(sid, idx)
        assert rnd is not None
        assert rnd.user_content == user_content
        assert rnd.ai_content is None
        assert rnd.trajectory is None

    def test_complete_round(self, session):
        store, sid = session
        idx = store.start_round(sid, [{"type": "text", "content": "Q"}])
        ai = [{"type": "text", "content": "A"}]
        traj = [
            {"event": "reasoning", "content": "thinking..."},
            {"event": "tool_call", "name": "search", "args": {}},
            {"event": "tool_result", "content": "found it"},
            {"event": "response", "content": "A"},
        ]
        store.complete_round(sid, idx, ai, traj)
        rnd = store.get_round(sid, idx)
        assert rnd.ai_content == ai
        assert rnd.trajectory == traj

    def test_complete_round_without_trajectory(self, session):
        store, sid = session
        idx = store.start_round(sid, [{"type": "text", "content": "Q"}])
        ai = [{"type": "text", "content": "A"}]
        store.complete_round(sid, idx, ai)
        rnd = store.get_round(sid, idx)
        assert rnd.ai_content == ai
        assert rnd.trajectory is None

    def test_get_rounds_ordering(self, session):
        store, sid = session
        for i in range(3):
            idx = store.start_round(sid, [{"type": "text", "content": f"Q{i}"}])
            store.complete_round(sid, idx, [{"type": "text", "content": f"A{i}"}])
        rounds = store.get_rounds(sid)
        assert len(rounds) == 3
        for i, rnd in enumerate(rounds):
            assert rnd.round_idx == i
            assert rnd.user_content == [{"type": "text", "content": f"Q{i}"}]
            assert rnd.ai_content == [{"type": "text", "content": f"A{i}"}]

    def test_get_round_not_found(self, session):
        store, sid = session
        assert store.get_round(sid, 999) is None

    def test_get_rounds_empty_session(self, session):
        store, sid = session
        assert store.get_rounds(sid) == []

    def test_incomplete_round(self, session):
        """start_round 后未 complete_round，ai_content 和 trajectory 应为 None"""
        store, sid = session
        idx = store.start_round(sid, [{"type": "text", "content": "pending"}])
        rounds = store.get_rounds(sid)
        assert len(rounds) == 1
        assert rounds[0].ai_content is None
        assert rounds[0].trajectory is None

    def test_multimodal_content(self, session):
        """多模态内容的序列化/反序列化"""
        store, sid = session
        user_content = [
            {"type": "text", "content": "看看这个图片"},
            {"type": "image", "content": "data:image/png;base64,iVBOR..."},
            {"type": "video", "content": "https://example.com/video.mp4"},
        ]
        ai_content = [
            {"type": "text", "content": "这张图片展示了..."},
        ]
        idx = store.start_round(sid, user_content)
        store.complete_round(sid, idx, ai_content)
        rnd = store.get_round(sid, idx)
        assert rnd.user_content == user_content
        assert rnd.ai_content == ai_content

    def test_timestamps(self, session):
        store, sid = session
        idx = store.start_round(sid, [{"type": "text", "content": "Q"}])
        rnd = store.get_round(sid, idx)
        assert rnd.created_at > 0
        assert rnd.updated_at > 0
        old_updated = rnd.updated_at
        store.complete_round(sid, idx, [{"type": "text", "content": "A"}])
        rnd = store.get_round(sid, idx)
        assert rnd.updated_at >= old_updated

    def test_session_updated_at_on_round(self, session):
        """start_round / complete_round 应更新 session 的 updated_at"""
        store, sid = session
        info_before = store.get_session(sid)
        store.start_round(sid, [{"type": "text", "content": "Q"}])
        info_after = store.get_session(sid)
        assert info_after.updated_at >= info_before.updated_at


# ============================================================================
# Session Store Tests
# ============================================================================

class TestSessionStore:
    def test_save_and_load(self, session):
        store, sid = session
        store.session_store_save(sid, "key1", "value1")
        assert store.session_store_load(sid, "key1") == "value1"

    def test_load_nonexistent(self, session):
        store, sid = session
        assert store.session_store_load(sid, "nope") is None

    def test_overwrite(self, session):
        store, sid = session
        store.session_store_save(sid, "k", "v1")
        store.session_store_save(sid, "k", "v2")
        assert store.session_store_load(sid, "k") == "v2"

    def test_clear_by_type(self, session):
        store, sid = session
        store.session_store_save(sid, "e1", "data", "expire")
        store.session_store_save(sid, "c1", "data", "compress")
        store.session_store_clear(sid, store_type="expire")
        assert store.session_store_load(sid, "e1") is None
        assert store.session_store_load(sid, "c1") == "data"

    def test_clear_all(self, session):
        store, sid = session
        store.session_store_save(sid, "a", "1", "expire")
        store.session_store_save(sid, "b", "2", "compress")
        store.session_store_clear(sid)
        assert store.session_store_load(sid, "a") is None
        assert store.session_store_load(sid, "b") is None


# ============================================================================
# User Memory Tests
# ============================================================================

class TestUserMemory:
    def test_default_empty(self, store):
        store.ensure_user("u1")
        mem = store.get_user_memory("u1")
        assert mem.user_id == "u1"
        assert mem.data == {}
        assert mem.version == 1

    def test_set_and_get(self, store):
        store.set_user_memory("u1", {"prefs": {"lang": "zh"}}, version=2)
        mem = store.get_user_memory("u1")
        assert mem.version == 2
        assert mem.data == {"prefs": {"lang": "zh"}}
        assert mem.updated_at > 0

    def test_overwrite(self, store):
        store.set_user_memory("u1", {"v": 1}, version=1)
        store.set_user_memory("u1", {"v": 2}, version=2)
        mem = store.get_user_memory("u1")
        assert mem.version == 2
        assert mem.data == {"v": 2}


# ============================================================================
# SqliteExpiredContentStore Tests
# ============================================================================

class TestSqliteExpiredContentStore:
    def test_save_and_load(self, session):
        ms, sid = session
        es = SqliteExpiredContentStore(ms, sid)
        ref_id = es.save("full content here", "tool")
        assert ref_id.startswith("tool_")
        assert es.load(ref_id) == "full content here"

    def test_same_content_same_id(self, session):
        ms, sid = session
        es = SqliteExpiredContentStore(ms, sid)
        id1 = es.save("same", "think")
        id2 = es.save("same", "think")
        assert id1 == id2

    def test_load_nonexistent(self, session):
        ms, sid = session
        es = SqliteExpiredContentStore(ms, sid)
        assert es.load("nope") is None

    def test_len(self, session):
        ms, sid = session
        es = SqliteExpiredContentStore(ms, sid)
        assert len(es) == 0
        es.save("a", "tool")
        es.save("b", "tool")
        assert len(es) == 2

    def test_clear(self, session):
        ms, sid = session
        es = SqliteExpiredContentStore(ms, sid)
        es.save("data", "tool")
        assert len(es) == 1
        es.clear()
        assert len(es) == 0
