"""
Skill 模块测试用例

测试覆盖：
- SkillProtocol: 数据结构
- SkillRegistry: 注册中心
- SkillLoader: 文件加载
- SkillHooks: 加载前钩子
- SkillManager: 生命周期管理
- LoadSkillTool: load_skill 工具
- ContextBuilder Skill Tools: 分离存储与 merge
"""
import pytest
import asyncio
import sys
import os
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..'))

from common.agent_framework.skill import (
    SkillLoadType,
    SkillHookConfig,
    SkillDefinition,
    SkillState,
    SkillContent,
    SkillLoadResult,
    SkillRegistry,
    SkillLoader,
    SkillManager,
    LoadSkillTool,
    HookDecision,
    PermissionCheckHook,
    run_hooks,
)
from common.agent_framework.tool_adapter import (
    ToolSchema,
    ToolRegistry,
    tool,
)
from common.agent_framework.context_strategy.builder import ContextBuilder
from common.agent_framework.context_strategy.default_strategy import DefaultContextStrategy
from common.agent_framework.context_strategy.truncation import NoTruncation
from common.agent_framework.user_interface.inputs import TaskInput, Message


# ============================================================
# TestSkillProtocol - 数据结构测试
# ============================================================

class TestSkillProtocol:
    """数据结构测试"""

    def test_skill_definition_creation(self):
        """基本创建 + 默认值"""
        sd = SkillDefinition(
            name="test_skill",
            description="A test skill",
            content_file_path="./skills/test/skill.md",
        )
        assert sd.name == "test_skill"
        assert sd.load_type == SkillLoadType.DYNAMIC
        assert sd.keep_task_round == 3
        assert sd.env_config == {}
        assert sd.binding_tools == []
        assert sd.load_hooks == []

    def test_skill_definition_static_type(self):
        """load_type=static"""
        sd = SkillDefinition(
            name="static_skill",
            description="Always loaded",
            content_file_path="./skill.md",
            load_type=SkillLoadType.STATIC,
        )
        assert sd.load_type == SkillLoadType.STATIC

    def test_skill_definition_dynamic_type(self):
        """load_type=dynamic"""
        sd = SkillDefinition(
            name="dyn",
            description="Dynamic",
            content_file_path="./skill.md",
            load_type=SkillLoadType.DYNAMIC,
        )
        assert sd.load_type == SkillLoadType.DYNAMIC

    def test_skill_state_initial(self):
        """初始状态 unloaded"""
        state = SkillState(skill_name="test")
        assert state.is_loaded is False
        assert state.loaded_at_round == -1
        assert state.should_offload(10) is False

    def test_skill_state_loaded(self):
        """加载后状态变更"""
        state = SkillState(skill_name="test", keep_task_round=3)
        state.mark_loaded(5)
        assert state.is_loaded is True
        assert state.loaded_at_round == 5
        assert state.should_offload(7) is False  # 5+3=8 > 7
        assert state.should_offload(8) is True   # 8-5=3 >= 3

    def test_skill_content_dataclass(self):
        """SkillContent 字段验证"""
        sc = SkillContent(
            skill_name="my_skill",
            instructions="Do something",
            binding_tool_schemas=[
                ToolSchema(name="t1", description="tool 1", schema={"type": "object", "properties": {}})
            ],
        )
        assert sc.skill_name == "my_skill"
        assert sc.instructions == "Do something"
        assert len(sc.binding_tool_schemas) == 1

    def test_skill_content_format_for_model(self):
        """format_for_model 输出格式"""
        sc = SkillContent(skill_name="calc", instructions="Use calculator.")
        output = sc.format_for_model()
        assert '<skill_content name="calc">' in output
        assert "Use calculator." in output
        assert "</skill_content>" in output


# ============================================================
# TestSkillRegistry - 注册中心测试
# ============================================================

class TestSkillRegistry:
    """注册中心测试"""

    def test_register_and_get(self):
        reg = SkillRegistry()
        sd = SkillDefinition(name="s1", description="d1", content_file_path="p1")
        reg.register(sd)
        assert reg.get("s1") is sd
        assert reg.has("s1") is True

    def test_register_duplicate_raises(self):
        reg = SkillRegistry()
        sd = SkillDefinition(name="s1", description="d1", content_file_path="p1")
        reg.register(sd)
        with pytest.raises(ValueError, match="already registered"):
            reg.register(sd)

    def test_unregister(self):
        reg = SkillRegistry()
        sd = SkillDefinition(name="s1", description="d1", content_file_path="p1")
        reg.register(sd)
        reg.unregister("s1")
        assert reg.get("s1") is None
        assert reg.has("s1") is False

    def test_list_static_skills(self):
        reg = SkillRegistry()
        reg.register(SkillDefinition(name="s1", description="", content_file_path="", load_type=SkillLoadType.STATIC))
        reg.register(SkillDefinition(name="s2", description="", content_file_path="", load_type=SkillLoadType.DYNAMIC))
        statics = reg.list_static()
        assert len(statics) == 1
        assert statics[0].name == "s1"

    def test_list_dynamic_skills(self):
        reg = SkillRegistry()
        reg.register(SkillDefinition(name="s1", description="", content_file_path="", load_type=SkillLoadType.STATIC))
        reg.register(SkillDefinition(name="s2", description="", content_file_path="", load_type=SkillLoadType.DYNAMIC))
        dynamics = reg.list_dynamic()
        assert len(dynamics) == 1
        assert dynamics[0].name == "s2"

    def test_load_from_yaml(self):
        reg = SkillRegistry()
        config = {
            "calculator": {
                "description": "Math calculator",
                "content_file_path": "./skills/calc/skill.md",
                "load_type": "static",
                "keep_task_round": 5,
                "binding_tools": ["add", "multiply"],
                "env_config": {"api_key": "xxx"},
                "load_hooks": [
                    {"hook_name": "permission_check", "permissions": ["env/api_key"]}
                ],
            }
        }
        reg.load_from_config(config)
        sd = reg.get("calculator")
        assert sd is not None
        assert sd.description == "Math calculator"
        assert sd.load_type == SkillLoadType.STATIC
        assert sd.keep_task_round == 5
        assert sd.binding_tools == ["add", "multiply"]
        assert len(sd.load_hooks) == 1
        assert sd.load_hooks[0].hook_name == "permission_check"

    def test_load_from_yaml_missing_fields(self):
        """字段缺失时使用默认值"""
        reg = SkillRegistry()
        config = {
            "minimal": {
                "description": "Minimal skill",
            }
        }
        reg.load_from_config(config)
        sd = reg.get("minimal")
        assert sd is not None
        assert sd.content_file_path == ""
        assert sd.load_type == SkillLoadType.DYNAMIC
        assert sd.keep_task_round == 3


# ============================================================
# TestSkillLoader - 文件加载测试
# ============================================================

class TestSkillLoader:
    """文件加载测试"""

    def test_load_skill_md_content(self, tmp_path):
        """读取 skill.md 文件内容"""
        skill_file = tmp_path / "skill.md"
        skill_file.write_text("# My Skill\nDo things.", encoding="utf-8")

        tool_reg = ToolRegistry()
        loader = SkillLoader(base_path=str(tmp_path))
        sd = SkillDefinition(
            name="test", description="", content_file_path="skill.md"
        )
        content = loader.load_content(sd, tool_reg)
        assert content.instructions == "# My Skill\nDo things."
        assert content.skill_name == "test"

    def test_load_skill_md_not_found(self):
        """文件不存在"""
        tool_reg = ToolRegistry()
        loader = SkillLoader(base_path="/nonexistent")
        sd = SkillDefinition(
            name="test", description="", content_file_path="missing.md"
        )
        with pytest.raises(FileNotFoundError):
            loader.load_content(sd, tool_reg)

    def test_resolve_binding_tools(self, tmp_path):
        """从 ToolRegistry 解析 binding tool schemas"""
        skill_file = tmp_path / "skill.md"
        skill_file.write_text("instructions", encoding="utf-8")

        @tool(description="Add numbers")
        async def add(a: int, b: int):
            return a + b

        tool_reg = ToolRegistry()
        tool_reg.register(add)

        loader = SkillLoader(base_path=str(tmp_path))
        sd = SkillDefinition(
            name="calc", description="", content_file_path="skill.md",
            binding_tools=["add"],
        )
        content = loader.load_content(sd, tool_reg)
        assert len(content.binding_tool_schemas) == 1
        assert content.binding_tool_schemas[0].name == "add"

    def test_resolve_binding_tools_partial(self, tmp_path):
        """部分 tool 不存在时跳过"""
        skill_file = tmp_path / "skill.md"
        skill_file.write_text("instructions", encoding="utf-8")

        @tool(description="Add numbers")
        async def add(a: int, b: int):
            return a + b

        tool_reg = ToolRegistry()
        tool_reg.register(add)

        loader = SkillLoader(base_path=str(tmp_path))
        sd = SkillDefinition(
            name="calc", description="", content_file_path="skill.md",
            binding_tools=["add", "nonexistent_tool"],
        )
        content = loader.load_content(sd, tool_reg)
        assert len(content.binding_tool_schemas) == 1

    def test_format_skill_content(self, tmp_path):
        """验证 <skill_content> 格式输出"""
        skill_file = tmp_path / "skill.md"
        skill_file.write_text("Use this skill wisely.", encoding="utf-8")

        tool_reg = ToolRegistry()
        loader = SkillLoader(base_path=str(tmp_path))
        sd = SkillDefinition(
            name="wise", description="", content_file_path="skill.md",
        )
        content = loader.load_content(sd, tool_reg)
        formatted = content.format_for_model()
        assert formatted == '<skill_content name="wise">\nUse this skill wisely.\n</skill_content>'


# ============================================================
# TestSkillHooks - 加载前钩子测试
# ============================================================

class TestSkillHooks:
    """加载前钩子测试"""

    def test_permission_check_all_present(self):
        """所有 env key 都存在 -> allow"""
        hook = PermissionCheckHook()
        decision = hook.execute(
            envs={"user_id": "123", "location": "beijing"},
            parameters={"permissions": ["env/user_id", "env/location"]},
        )
        assert decision.type == "allow"

    def test_permission_check_missing_key(self):
        """缺少 env key -> ask"""
        hook = PermissionCheckHook()
        decision = hook.execute(
            envs={"user_id": "123"},
            parameters={"permissions": ["env/user_id", "env/location"]},
        )
        assert decision.type == "ask"
        assert "env/location" in decision.ask_permissions

    def test_permission_check_empty_value(self):
        """env key 存在但为空 -> ask"""
        hook = PermissionCheckHook()
        decision = hook.execute(
            envs={"user_id": "123", "location": ""},
            parameters={"permissions": ["env/user_id", "env/location"]},
        )
        assert decision.type == "ask"
        assert "env/location" in decision.ask_permissions

    def test_hook_decision_allow(self):
        d = HookDecision.allow()
        assert d.type == "allow"
        assert d.ask_permissions == []
        assert d.deny_reason == ""

    def test_hook_decision_deny_with_reason(self):
        d = HookDecision.deny("not authorized")
        assert d.type == "deny"
        assert d.deny_reason == "not authorized"

    def test_multiple_hooks_chain(self):
        """多个 hook 顺序执行，第一个 deny 即中断"""
        hook_configs = [
            SkillHookConfig(
                hook_name="permission_check",
                parameters={"permissions": ["env/key1"]},
            ),
            SkillHookConfig(
                hook_name="permission_check",
                parameters={"permissions": ["env/key2"]},
            ),
        ]
        # key1 缺失 -> 第一个 hook 就返回 ask
        decision = run_hooks(hook_configs, {"key2": "val2"})
        assert decision.type == "ask"
        assert "env/key1" in decision.ask_permissions

    def test_all_hooks_pass(self):
        """所有 hook 通过"""
        hook_configs = [
            SkillHookConfig(
                hook_name="permission_check",
                parameters={"permissions": ["env/key1"]},
            ),
            SkillHookConfig(
                hook_name="permission_check",
                parameters={"permissions": ["env/key2"]},
            ),
        ]
        decision = run_hooks(hook_configs, {"key1": "v1", "key2": "v2"})
        assert decision.type == "allow"


# ============================================================
# TestSkillManager - 生命周期管理测试
# ============================================================

class TestSkillManager:
    """生命周期管理测试"""

    def _make_manager(self, tmp_path, skills_config=None):
        """创建测试用的 SkillManager"""
        skill_reg = SkillRegistry()
        tool_reg = ToolRegistry()
        loader = SkillLoader(base_path=str(tmp_path))

        if skills_config:
            for name, conf in skills_config.items():
                # 创建 skill.md 文件
                skill_file = tmp_path / f"{name}.md"
                skill_file.write_text(
                    conf.get("content_text", f"Instructions for {name}"),
                    encoding="utf-8",
                )
                sd = SkillDefinition(
                    name=name,
                    description=conf.get("description", ""),
                    content_file_path=f"{name}.md",
                    load_type=SkillLoadType(conf.get("load_type", "dynamic")),
                    keep_task_round=conf.get("keep_task_round", 3),
                    binding_tools=conf.get("binding_tools", []),
                    load_hooks=conf.get("load_hooks", []),
                )
                skill_reg.register(sd)

        manager = SkillManager(
            skill_registry=skill_reg,
            tool_registry=tool_reg,
            skill_loader=loader,
        )
        return manager, skill_reg, tool_reg

    def test_static_skill_prompt_generation(self, tmp_path):
        """生成 static skills 的 SP 片段"""
        manager, _, _ = self._make_manager(tmp_path, {
            "helper": {"load_type": "static", "description": "A helper", "content_text": "Help instructions"},
        })
        prompt = manager.get_static_skill_prompt()
        assert "Static Skills" in prompt
        assert "Help instructions" in prompt
        assert '<skill_content name="helper">' in prompt

    def test_dynamic_candidates_prompt(self, tmp_path):
        """生成 dynamic skill 候选描述列表"""
        manager, _, _ = self._make_manager(tmp_path, {
            "search": {"load_type": "dynamic", "description": "Web search skill"},
        })
        prompt = manager.get_dynamic_skill_candidates_prompt()
        assert "Dynamic Skills" in prompt
        assert "search" in prompt
        assert "Web search skill" in prompt

    def test_handle_load_skill_success(self, tmp_path):
        """正常加载"""
        manager, _, _ = self._make_manager(tmp_path, {
            "calc": {"load_type": "dynamic", "description": "Calculator"},
        })
        result = manager.handle_load_skill("calc", current_round=2)
        assert result.success is True
        assert result.content is not None
        assert result.content.skill_name == "calc"
        assert manager.is_loaded("calc") is True

    def test_handle_load_skill_not_found(self, tmp_path):
        """skill_name 不存在"""
        manager, _, _ = self._make_manager(tmp_path, {})
        result = manager.handle_load_skill("nonexistent")
        assert result.success is False
        assert result.error_code == "not_found"

    def test_handle_load_skill_hook_deny(self, tmp_path):
        """hook 拒绝"""
        manager, _, _ = self._make_manager(tmp_path, {
            "restricted": {
                "load_type": "dynamic",
                "description": "Restricted",
                "load_hooks": [
                    SkillHookConfig(
                        hook_name="permission_check",
                        parameters={"permissions": ["env/secret_key"]},
                    )
                ],
            },
        })
        result = manager.handle_load_skill("restricted", envs={})
        assert result.success is False
        assert result.error_code == "permission_denied"

    def test_handle_load_skill_already_loaded(self, tmp_path):
        """重复加载幂等"""
        manager, _, _ = self._make_manager(tmp_path, {
            "calc": {"load_type": "dynamic", "description": "Calculator"},
        })
        r1 = manager.handle_load_skill("calc", current_round=0)
        r2 = manager.handle_load_skill("calc", current_round=1)
        assert r1.success is True
        assert r2.success is True
        assert r2.content.skill_name == "calc"

    def test_check_offload_not_expired(self, tmp_path):
        """未超过 keep_task_round 不卸载"""
        manager, _, _ = self._make_manager(tmp_path, {
            "calc": {"load_type": "dynamic", "keep_task_round": 3},
        })
        manager.handle_load_skill("calc", current_round=5)
        offloads = manager.check_offload(7)  # 7-5=2 < 3
        assert offloads == []

    def test_check_offload_expired(self, tmp_path):
        """超过 keep_task_round 触发卸载"""
        manager, _, _ = self._make_manager(tmp_path, {
            "calc": {"load_type": "dynamic", "keep_task_round": 3},
        })
        manager.handle_load_skill("calc", current_round=5)
        offloads = manager.check_offload(8)  # 8-5=3 >= 3
        assert "calc" in offloads

    def test_offload_message_format(self, tmp_path):
        """卸载引导文案"""
        manager, _, _ = self._make_manager(tmp_path, {})
        msg = manager.get_offload_message(["skill_a", "skill_b"])
        assert "skill_a" in msg
        assert "skill_b" in msg
        assert "load_skill" in msg

    def test_offload_removes_binding_tools(self, tmp_path):
        """卸载后 binding tools 被移除"""
        @tool(description="Add")
        async def add(a: int, b: int):
            return a + b

        skill_reg = SkillRegistry()
        tool_reg = ToolRegistry()
        tool_reg.register(add)
        loader = SkillLoader(base_path=str(tmp_path))

        skill_file = tmp_path / "calc.md"
        skill_file.write_text("Calculator", encoding="utf-8")

        skill_reg.register(SkillDefinition(
            name="calc", description="", content_file_path="calc.md",
            load_type=SkillLoadType.DYNAMIC, keep_task_round=2,
            binding_tools=["add"],
        ))

        manager = SkillManager(skill_reg, tool_reg, loader)
        manager.handle_load_skill("calc", current_round=0)

        assert len(manager.get_skill_binding_tools("calc")) == 1

        offloads = manager.check_offload(2)
        assert "calc" in offloads
        manager.execute_offload(offloads)

        assert manager.is_loaded("calc") is False
        assert manager.get_skill_binding_tools("calc") == []

    def test_two_skills_share_binding_tool(self, tmp_path):
        """两个 skill 绑定同一 tool，卸载一个不影响另一个"""
        @tool(description="Shared tool")
        async def shared(x: str):
            return x

        skill_reg = SkillRegistry()
        tool_reg = ToolRegistry()
        tool_reg.register(shared)
        loader = SkillLoader(base_path=str(tmp_path))

        for name in ["skill_a", "skill_b"]:
            f = tmp_path / f"{name}.md"
            f.write_text(f"Skill {name}", encoding="utf-8")
            skill_reg.register(SkillDefinition(
                name=name, description="", content_file_path=f"{name}.md",
                load_type=SkillLoadType.DYNAMIC, keep_task_round=2,
                binding_tools=["shared"],
            ))

        manager = SkillManager(skill_reg, tool_reg, loader)
        manager.handle_load_skill("skill_a", current_round=0)
        manager.handle_load_skill("skill_b", current_round=1)

        active = manager.get_active_binding_tools()
        assert "skill_a" in active
        assert "skill_b" in active

        # Offload skill_a (round 2, loaded at 0, keep=2)
        offloads = manager.check_offload(2)
        assert "skill_a" in offloads
        assert "skill_b" not in offloads

        manager.execute_offload(offloads)
        active = manager.get_active_binding_tools()
        assert "skill_a" not in active
        assert "skill_b" in active

    def test_multiple_dynamic_skills_lifecycle(self, tmp_path):
        """多个 dynamic skill 交叉加载/卸载"""
        skill_reg = SkillRegistry()
        tool_reg = ToolRegistry()
        loader = SkillLoader(base_path=str(tmp_path))

        for name in ["a", "b", "c"]:
            f = tmp_path / f"{name}.md"
            f.write_text(f"Skill {name}", encoding="utf-8")
            skill_reg.register(SkillDefinition(
                name=name, description="", content_file_path=f"{name}.md",
                load_type=SkillLoadType.DYNAMIC, keep_task_round=2,
            ))

        manager = SkillManager(skill_reg, tool_reg, loader)

        manager.handle_load_skill("a", current_round=0)
        manager.handle_load_skill("b", current_round=1)
        manager.handle_load_skill("c", current_round=3)

        # Round 2: a should offload (2-0=2>=2)
        offloads = manager.check_offload(2)
        assert "a" in offloads
        assert "b" not in offloads
        manager.execute_offload(offloads)

        # Round 3: b should offload (3-1=2>=2)
        offloads = manager.check_offload(3)
        assert "b" in offloads
        assert "c" not in offloads
        manager.execute_offload(offloads)

        # Round 5: c should offload (5-3=2>=2)
        offloads = manager.check_offload(5)
        assert "c" in offloads
        manager.execute_offload(offloads)

        assert manager.is_loaded("a") is False
        assert manager.is_loaded("b") is False
        assert manager.is_loaded("c") is False


# ============================================================
# TestLoadSkillTool - load_skill 工具测试
# ============================================================

class TestLoadSkillTool:
    """load_skill 工具测试"""

    def _make_tool(self, tmp_path):
        """创建测试用的 LoadSkillTool"""
        @tool(description="Add numbers")
        async def add(a: int, b: int):
            return a + b

        skill_reg = SkillRegistry()
        tool_reg = ToolRegistry()
        tool_reg.register(add)
        loader = SkillLoader(base_path=str(tmp_path))

        skill_file = tmp_path / "calc.md"
        skill_file.write_text("Calculator instructions", encoding="utf-8")

        skill_reg.register(SkillDefinition(
            name="calc", description="Calculator", content_file_path="calc.md",
            load_type=SkillLoadType.DYNAMIC, binding_tools=["add"],
        ))

        manager = SkillManager(skill_reg, tool_reg, loader)
        load_tool = LoadSkillTool(manager)
        return load_tool

    def test_tool_schema(self, tmp_path):
        """验证 tool schema 格式"""
        load_tool = self._make_tool(tmp_path)
        schema = load_tool.schema
        assert schema.name == "load_skill"
        assert "skill_name" in schema.schema["properties"]
        assert "skill_name" in schema.schema["required"]

    def test_execute_success(self, tmp_path):
        """正常执行"""
        load_tool = self._make_tool(tmp_path)
        result = asyncio.get_event_loop().run_until_complete(
            load_tool.execute({"skill_name": "calc"})
        )
        assert result.success is True
        assert "Calculator instructions" in result.formatted_data
        assert '<skill_content name="calc">' in result.formatted_data

    def test_execute_returns_binding_tools_in_metadata(self, tmp_path):
        """metadata 中包含 binding tool schemas"""
        load_tool = self._make_tool(tmp_path)
        result = asyncio.get_event_loop().run_until_complete(
            load_tool.execute({"skill_name": "calc"})
        )
        assert result.metadata is not None
        assert "binding_tools" in result.metadata
        assert len(result.metadata["binding_tools"]) == 1
        assert result.metadata["binding_tools"][0]["name"] == "add"

    def test_execute_skill_not_found(self, tmp_path):
        """skill 不存在"""
        load_tool = self._make_tool(tmp_path)
        result = asyncio.get_event_loop().run_until_complete(
            load_tool.execute({"skill_name": "nonexistent"})
        )
        assert result.success is False
        assert result.metadata["error_code"] == "not_found"

    def test_execute_permission_denied(self, tmp_path):
        """权限不足"""
        skill_reg = SkillRegistry()
        tool_reg = ToolRegistry()
        loader = SkillLoader(base_path=str(tmp_path))

        skill_file = tmp_path / "restricted.md"
        skill_file.write_text("Restricted", encoding="utf-8")

        skill_reg.register(SkillDefinition(
            name="restricted", description="", content_file_path="restricted.md",
            load_type=SkillLoadType.DYNAMIC,
            load_hooks=[SkillHookConfig(
                hook_name="permission_check",
                parameters={"permissions": ["env/secret"]},
            )],
        ))

        manager = SkillManager(skill_reg, tool_reg, loader)
        load_tool = LoadSkillTool(manager)

        result = asyncio.get_event_loop().run_until_complete(
            load_tool.execute({"skill_name": "restricted"})
        )
        assert result.success is False
        assert result.metadata["error_code"] == "permission_denied"


# ============================================================
# TestContextBuilderSkillTools - ContextBuilder 扩展测试
# ============================================================

class TestContextBuilderSkillTools:
    """ContextBuilder Skill Tools 分离存储测试"""

    def _make_builder(self):
        """创建测试用 ContextBuilder"""
        strategy = DefaultContextStrategy()
        builder = ContextBuilder(
            strategy=strategy,
            base_system_prompt="You are helpful.",
            tools=[ToolSchema(name="base_tool", description="Base", schema={"type": "object", "properties": {}})],
        )
        task = TaskInput(
            session_id="s1", task_id="t1",
            messages=[Message.from_role_and_text("user", "hello")],
        )
        builder.reset(task)
        return builder

    def test_add_skill_tools(self):
        """添加后 get_all_tools 包含 skill tools"""
        builder = self._make_builder()
        skill_schema = ToolSchema(name="skill_tool", description="ST", schema={"type": "object", "properties": {}})
        builder.add_skill_tools("my_skill", [skill_schema])

        all_tools = builder.get_all_tools()
        names = [t.name for t in all_tools]
        assert "base_tool" in names
        assert "skill_tool" in names

    def test_remove_skill_tools(self):
        """移除后 get_all_tools 不再包含"""
        builder = self._make_builder()
        skill_schema = ToolSchema(name="skill_tool", description="ST", schema={"type": "object", "properties": {}})
        builder.add_skill_tools("my_skill", [skill_schema])
        builder.remove_skill_tools("my_skill")

        all_tools = builder.get_all_tools()
        names = [t.name for t in all_tools]
        assert "skill_tool" not in names

    def test_merge_dedup_by_name(self):
        """常规 tool 和 skill tool 同名时去重（常规优先）"""
        builder = self._make_builder()
        # 添加一个和 base_tool 同名的 skill tool
        dup_schema = ToolSchema(name="base_tool", description="Duplicate", schema={"type": "object", "properties": {}})
        builder.add_skill_tools("dup_skill", [dup_schema])

        all_tools = builder.get_all_tools()
        base_tools = [t for t in all_tools if t.name == "base_tool"]
        assert len(base_tools) == 1
        assert base_tools[0].description == "Base"  # 常规 tool 优先

    def test_two_skills_same_tool_remove_one(self):
        """两个 skill 绑定同一 tool，移除一个后 tool 仍在"""
        builder = self._make_builder()
        shared = ToolSchema(name="shared_tool", description="Shared", schema={"type": "object", "properties": {}})
        builder.add_skill_tools("skill_a", [shared])
        builder.add_skill_tools("skill_b", [shared])

        builder.remove_skill_tools("skill_a")
        all_tools = builder.get_all_tools()
        names = [t.name for t in all_tools]
        assert "shared_tool" in names

    def test_skill_tools_isolated_from_regular(self):
        """skill tools 操作不影响 _tools 列表"""
        builder = self._make_builder()
        skill_schema = ToolSchema(name="extra", description="Extra", schema={"type": "object", "properties": {}})
        builder.add_skill_tools("sk", [skill_schema])
        builder.remove_skill_tools("sk")

        # 常规 tools 不受影响
        assert builder.tools is not None
        assert len(builder.tools) == 1
        assert builder.tools[0].name == "base_tool"

    def test_build_includes_merged_tools(self):
        """build() 产出的 ChatRequest.tools 包含 merge 结果"""
        builder = self._make_builder()
        skill_schema = ToolSchema(name="skill_tool", description="ST", schema={"type": "object", "properties": {}})
        builder.add_skill_tools("my_skill", [skill_schema])

        request = builder.build()
        assert request.tools is not None
        tool_names = [t.name for t in request.tools]
        assert "base_tool" in tool_names
        assert "skill_tool" in tool_names
