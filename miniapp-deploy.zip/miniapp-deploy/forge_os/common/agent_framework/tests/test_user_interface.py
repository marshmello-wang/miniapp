"""
User Interface 模块测试用例

测试覆盖：
- ImageContent / MessageContent / Message: 输入类型
- AgentConfig / TaskInput: 配置和任务输入
- ContentBlock 及其子类: 内容块
- Event: 事件
- Agent 协议: 协议接口
"""
import pytest
import sys
import os
from time import time

# 添加项目根目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..'))

from common.agent_framework.user_interface import (
    # 输入类型
    ImageContent,
    MessageContent,
    Message,
    AgentConfig,
    TaskInput,
    # 内容块
    ContentBlock,
    TextBlock,
    ImageBlock,
    ToolCallBlock,
    ToolResultBlock,
    ThinkingBlock,
    StructuredDataBlock,
    # 事件
    Event,
    # 协议
    Agent,
)


# ============================================================
# ImageContent 测试
# ============================================================

class TestImageContent:
    """ImageContent 测试类"""
    
    def test_from_base64(self):
        """测试从 base64 创建"""
        img = ImageContent.from_base64("abc123==", "image/png")
        
        assert img.type == "base64"
        assert img.data == "abc123=="
        assert img.mime_type == "image/png"
    
    def test_from_base64_default_mime_type(self):
        """测试默认 mime_type"""
        img = ImageContent.from_base64("data")
        
        assert img.mime_type == "image/jpeg"
    
    def test_from_path(self):
        """测试从路径创建"""
        img = ImageContent.from_path("/path/to/image.png", "image/png")
        
        assert img.type == "path"
        assert img.data == "/path/to/image.png"
        assert img.mime_type == "image/png"
    
    def test_from_path_with_pathlib(self):
        """测试使用 pathlib.Path"""
        from pathlib import Path
        img = ImageContent.from_path(Path("/tmp/test.jpg"))
        
        assert img.type == "path"
        assert img.data == "/tmp/test.jpg"


# ============================================================
# MessageContent 测试
# ============================================================

class TestMessageContent:
    """MessageContent 测试类"""
    
    def test_from_text(self):
        """测试创建文本内容"""
        content = MessageContent.from_text("Hello, world!")
        
        assert content.type == "text"
        assert content.text == "Hello, world!"
        assert content.image is None
    
    def test_from_image(self):
        """测试创建图片内容"""
        img = ImageContent.from_base64("data", "image/jpeg")
        content = MessageContent.from_image(img)
        
        assert content.type == "image"
        assert content.image == img
        assert content.text is None


# ============================================================
# Message 测试
# ============================================================

class TestMessage:
    """Message 测试类"""
    
    def test_from_role_and_text(self):
        """测试从角色和文本创建消息"""
        msg = Message.from_role_and_text("user", "Hello!")
        
        assert msg.role == "user"
        assert len(msg.content) == 1
        assert msg.content[0].type == "text"
        assert msg.content[0].text == "Hello!"
    
    def test_from_role_and_content(self):
        """测试从角色和内容列表创建消息"""
        contents = [
            MessageContent.from_text("Check this image:"),
            MessageContent.from_image(ImageContent.from_base64("data", "image/png"))
        ]
        msg = Message.from_role_and_content("user", contents)
        
        assert msg.role == "user"
        assert len(msg.content) == 2
        assert msg.content[0].type == "text"
        assert msg.content[1].type == "image"
    
    def test_assistant_message(self):
        """测试 assistant 消息"""
        msg = Message.from_role_and_text("assistant", "I can help you.")
        
        assert msg.role == "assistant"
    
    def test_system_message(self):
        """测试 system 消息"""
        msg = Message.from_role_and_text("system", "You are a helpful assistant.")
        
        assert msg.role == "system"


# ============================================================
# AgentConfig 测试
# ============================================================

class TestAgentConfig:
    """AgentConfig 测试类"""
    
    def test_default_values(self):
        """测试默认值"""
        config = AgentConfig()
        
        assert config.model == "gpt-4"
        assert config.temperature == 0.7
        assert config.max_tokens is None
        assert config.top_p == 1.0
        assert config.extra_params == {}
    
    def test_custom_values(self):
        """测试自定义值"""
        config = AgentConfig(
            model="claude-3-5-sonnet",
            temperature=0.5,
            max_tokens=2048,
            extra_params={"custom_key": "value"}
        )
        
        assert config.model == "claude-3-5-sonnet"
        assert config.temperature == 0.5
        assert config.max_tokens == 2048
        assert config.extra_params == {"custom_key": "value"}


# ============================================================
# TaskInput 测试
# ============================================================

class TestTaskInput:
    """TaskInput 测试类"""
    
    def test_basic_task_input(self):
        """测试基本任务输入"""
        messages = [Message.from_role_and_text("user", "Hello")]
        task = TaskInput(
            session_id="session-001",
            task_id="task-001",
            messages=messages
        )
        
        assert task.session_id == "session-001"
        assert task.task_id == "task-001"
        assert len(task.messages) == 1
        assert task.context is None
        assert task.config is None
    
    def test_task_input_with_context(self):
        """测试带上下文的任务输入"""
        task = TaskInput(
            session_id="session-001",
            task_id="task-001",
            messages=[Message.from_role_and_text("user", "Help")],
            context={"project": "my-project", "files": ["a.py", "b.py"]}
        )
        
        assert task.context == {"project": "my-project", "files": ["a.py", "b.py"]}
    
    def test_task_input_with_config(self):
        """测试带配置的任务输入"""
        config = AgentConfig(model="gpt-4o", temperature=0.3)
        task = TaskInput(
            session_id="session-001",
            task_id="task-001",
            messages=[Message.from_role_and_text("user", "Code review")],
            config=config
        )
        
        assert task.config.model == "gpt-4o"
        assert task.config.temperature == 0.3


# ============================================================
# ContentBlock 测试
# ============================================================

class TestTextBlock:
    """TextBlock 测试类"""
    
    def test_create_text_block(self):
        """测试创建文本块"""
        block = TextBlock("Hello, world!")
        
        assert block.type == "text"
        assert block.text == "Hello, world!"
    
    def test_to_dict(self):
        """测试转换为字典"""
        block = TextBlock("Test content")
        result = block.to_dict()
        
        assert result == {"type": "text", "text": "Test content"}


class TestImageBlock:
    """ImageBlock 测试类"""
    
    def test_create_image_block(self):
        """测试创建图片块"""
        img = ImageContent.from_base64("data", "image/jpeg")
        block = ImageBlock(img)
        
        assert block.type == "image"
        assert block.image == img
        assert block.caption is None
    
    def test_image_block_with_caption(self):
        """测试带标题的图片块"""
        img = ImageContent.from_base64("data", "image/png")
        block = ImageBlock(img, caption="Screenshot")
        
        assert block.caption == "Screenshot"
    
    def test_to_dict(self):
        """测试转换为字典"""
        img = ImageContent.from_base64("abc123", "image/jpeg")
        block = ImageBlock(img, caption="Test image")
        result = block.to_dict()
        
        assert result["type"] == "image"
        assert result["image"]["data"] == "abc123"
        assert result["image"]["mime_type"] == "image/jpeg"
        assert result["caption"] == "Test image"


class TestToolCallBlock:
    """ToolCallBlock 测试类"""
    
    def test_create_tool_call_block(self):
        """测试创建工具调用块"""
        block = ToolCallBlock(
            tool_name="search",
            tool_input={"query": "python", "limit": 10}
        )
        
        assert block.type == "tool_call"
        assert block.tool_name == "search"
        assert block.tool_input == {"query": "python", "limit": 10}
        assert block.call_id is None
    
    def test_tool_call_with_id(self):
        """测试带 call_id 的工具调用块"""
        block = ToolCallBlock(
            tool_name="read_file",
            tool_input={"path": "/tmp/test.txt"},
            call_id="call-123"
        )
        
        assert block.call_id == "call-123"
    
    def test_to_dict(self):
        """测试转换为字典"""
        block = ToolCallBlock(
            tool_name="execute",
            tool_input={"code": "print(1)"},
            call_id="call-456"
        )
        result = block.to_dict()
        
        assert result == {
            "type": "tool_call",
            "tool_name": "execute",
            "tool_input": {"code": "print(1)"},
            "call_id": "call-456"
        }


class TestToolResultBlock:
    """ToolResultBlock 测试类"""
    
    def test_create_success_result(self):
        """测试创建成功结果块"""
        block = ToolResultBlock(
            tool_name="search",
            result=["file1.py", "file2.py"],
            call_id="call-123"
        )
        
        assert block.type == "tool_result"
        assert block.tool_name == "search"
        assert block.result == ["file1.py", "file2.py"]
        assert block.call_id == "call-123"
        assert block.is_error is False
        assert block.error_message is None
    
    def test_create_error_result(self):
        """测试创建错误结果块"""
        block = ToolResultBlock(
            tool_name="read_file",
            result=None,
            call_id="call-456",
            is_error=True,
            error_message="File not found"
        )
        
        assert block.is_error is True
        assert block.error_message == "File not found"
    
    def test_to_dict(self):
        """测试转换为字典"""
        block = ToolResultBlock(
            tool_name="test",
            result="success",
            call_id="call-789",
            is_error=False
        )
        result = block.to_dict()
        
        assert result == {
            "type": "tool_result",
            "tool_name": "test",
            "result": "success",
            "call_id": "call-789",
            "is_error": False,
            "error_message": None
        }


class TestThinkingBlock:
    """ThinkingBlock 测试类"""
    
    def test_create_thinking_block(self):
        """测试创建思考块"""
        block = ThinkingBlock("Let me think about this problem...")
        
        assert block.type == "thinking"
        assert block.thinking == "Let me think about this problem..."
    
    def test_to_dict(self):
        """测试转换为字典"""
        block = ThinkingBlock("Step 1: analyze the input")
        result = block.to_dict()
        
        assert result == {"type": "thinking", "thinking": "Step 1: analyze the input"}


class TestStructuredDataBlock:
    """StructuredDataBlock 测试类"""
    
    def test_create_structured_data(self):
        """测试创建结构化数据块"""
        data = {"key": "value", "count": 42}
        block = StructuredDataBlock(data)
        
        assert block.type == "structured_data"
        assert block.data == data
        assert block.schema_name is None
    
    def test_with_schema_name(self):
        """测试带 schema 名称"""
        block = StructuredDataBlock(
            data={"name": "test"},
            schema_name="TestSchema"
        )
        
        assert block.schema_name == "TestSchema"
    
    def test_to_dict(self):
        """测试转换为字典"""
        block = StructuredDataBlock(
            data={"a": 1, "b": 2},
            schema_name="MySchema"
        )
        result = block.to_dict()
        
        assert result == {
            "type": "structured_data",
            "data": {"a": 1, "b": 2},
            "schema_name": "MySchema"
        }


# ============================================================
# Event 测试
# ============================================================

class TestEvent:
    """Event 测试类"""
    
    def test_create_event(self):
        """测试创建事件"""
        content = [TextBlock("Hello")]
        event = Event.create(
            event_id="evt-001",
            session_id="session-001",
            task_id="task-001",
            event_type="reasoning",
            content=content
        )
        
        assert event.event_id == "evt-001"
        assert event.session_id == "session-001"
        assert event.task_id == "task-001"
        assert event.event_type == "reasoning"
        assert len(event.content) == 1
        assert event.metadata is None
        assert event.timestamp > 0
    
    def test_event_with_metadata(self):
        """测试带元数据的事件"""
        event = Event.create(
            event_id="evt-002",
            session_id="session-001",
            task_id="task-001",
            event_type="tool_call",
            content=[ToolCallBlock("search", {"q": "test"})],
            metadata={"iteration": 1, "tool_count": 1}
        )
        
        assert event.metadata == {"iteration": 1, "tool_count": 1}
    
    def test_event_timestamp(self):
        """测试事件时间戳"""
        before = time()
        event = Event.create(
            event_id="evt-003",
            session_id="s",
            task_id="t",
            event_type="test",
            content=[]
        )
        after = time()
        
        assert before <= event.timestamp <= after
    
    def test_to_dict(self):
        """测试转换为字典"""
        event = Event.create(
            event_id="evt-004",
            session_id="session-001",
            task_id="task-001",
            event_type="task_complete",
            content=[TextBlock("Done!")],
            metadata={"reason": "completed"}
        )
        
        result = event.to_dict()
        
        assert result["event_id"] == "evt-004"
        assert result["session_id"] == "session-001"
        assert result["task_id"] == "task-001"
        assert result["event_type"] == "task_complete"
        assert len(result["content"]) == 1
        assert result["content"][0]["type"] == "text"
        assert result["content"][0]["text"] == "Done!"
        assert result["metadata"] == {"reason": "completed"}
        assert "timestamp" in result
    
    def test_multiple_content_blocks(self):
        """测试多个内容块"""
        content = [
            TextBlock("Executing tool..."),
            ToolCallBlock("read_file", {"path": "/tmp/test"}, "call-1"),
            ToolResultBlock("read_file", "file content", "call-1")
        ]
        
        event = Event.create(
            event_id="evt-005",
            session_id="s",
            task_id="t",
            event_type="tool_execution",
            content=content
        )
        
        assert len(event.content) == 3
        assert event.content[0].type == "text"
        assert event.content[1].type == "tool_call"
        assert event.content[2].type == "tool_result"


# ============================================================
# Agent 协议测试
# ============================================================

class TestAgentProtocol:
    """Agent 协议测试类"""
    
    def test_agent_protocol_implementation(self):
        """测试 Agent 协议实现"""
        from typing import Iterator
        
        class MockAgent:
            """Mock Agent 实现"""
            
            def run(self, task_input: TaskInput) -> Iterator[Event]:
                yield Event.create(
                    event_id="evt-1",
                    session_id=task_input.session_id,
                    task_id=task_input.task_id,
                    event_type="task_complete",
                    content=[TextBlock("Mock response")]
                )
        
        # 验证 MockAgent 可以作为 Agent 使用
        agent: Agent = MockAgent()
        
        task = TaskInput(
            session_id="test-session",
            task_id="test-task",
            messages=[Message.from_role_and_text("user", "Hello")]
        )
        
        events = list(agent.run(task))
        
        assert len(events) == 1
        assert events[0].event_type == "task_complete"
        assert events[0].session_id == "test-session"
        assert events[0].task_id == "test-task"


# ============================================================
# 集成测试
# ============================================================

class TestIntegration:
    """集成测试"""
    
    def test_full_message_flow(self):
        """测试完整消息流程"""
        # 1. 创建多模态消息
        messages = [
            Message.from_role_and_text("system", "You are a code assistant."),
            Message.from_role_and_content("user", [
                MessageContent.from_text("What's in this image?"),
                MessageContent.from_image(
                    ImageContent.from_base64("base64data", "image/png")
                )
            ])
        ]
        
        # 2. 创建任务输入
        task = TaskInput(
            session_id="integration-test",
            task_id="task-001",
            messages=messages,
            config=AgentConfig(model="gpt-4o", temperature=0.5)
        )
        
        # 3. 验证任务结构
        assert task.session_id == "integration-test"
        assert len(task.messages) == 2
        assert task.messages[0].role == "system"
        assert task.messages[1].role == "user"
        assert len(task.messages[1].content) == 2
        
        # 4. 创建事件流
        events = [
            Event.create(
                event_id="evt-1",
                session_id=task.session_id,
                task_id=task.task_id,
                event_type="reasoning",
                content=[TextBlock("Analyzing the image...")]
            ),
            Event.create(
                event_id="evt-2",
                session_id=task.session_id,
                task_id=task.task_id,
                event_type="tool_call",
                content=[ToolCallBlock("analyze_image", {"image_id": "123"}, "call-1")]
            ),
            Event.create(
                event_id="evt-3",
                session_id=task.session_id,
                task_id=task.task_id,
                event_type="tool_result",
                content=[ToolResultBlock("analyze_image", "Image shows code", "call-1")]
            ),
            Event.create(
                event_id="evt-4",
                session_id=task.session_id,
                task_id=task.task_id,
                event_type="task_complete",
                content=[TextBlock("The image shows Python code.")]
            )
        ]
        
        # 5. 验证事件流
        assert len(events) == 4
        assert events[0].event_type == "reasoning"
        assert events[1].event_type == "tool_call"
        assert events[2].event_type == "tool_result"
        assert events[3].event_type == "task_complete"
        
        # 6. 验证所有事件都可以序列化
        for event in events:
            d = event.to_dict()
            assert "event_id" in d
            assert "content" in d
            assert isinstance(d["content"], list)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

