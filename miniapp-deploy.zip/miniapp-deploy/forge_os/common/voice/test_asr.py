#!/usr/bin/env python3
"""豆包 ASR 测试脚本。

用法:
  # 识别本地文件
  python -m common.voice.test_asr --file audio/example.wav

  # 识别远程 URL
  python -m common.voice.test_asr --url https://example.com/audio.mp3

  # 用 macOS 系统麦克风录 5 秒后识别（需 pyaudio）
  python -m common.voice.test_asr --record 5

  # 指定 app_key（不设则读 DOUBAO_ASR_APP_KEY 环境变量）
  DOUBAO_ASR_APP_KEY=your-key python -m common.voice.test_asr --file test.wav

环境变量:
  DOUBAO_ASR_APP_KEY    – 火山引擎 App Key（必填）
  DOUBAO_ASR_ACCESS_KEY – Access Key（旧版控制台需要，新版可不填）
"""

import argparse
import logging
import sys
import time
import wave
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(name)s %(levelname)s %(message)s",
)

from common.voice.asr import DoubaoAsrClient


def record_audio(duration: int, sample_rate: int = 16000) -> bytes:
    """用 pyaudio 从麦克风录音，返回 WAV 二进制。"""
    try:
        import pyaudio
    except ImportError:
        print("录音需要 pyaudio，请先安装: pip install pyaudio")
        sys.exit(1)

    channels = 1
    sample_width = 2  # 16-bit
    chunk = 1024

    pa = pyaudio.PyAudio()
    stream = pa.open(
        format=pyaudio.paInt16,
        channels=channels,
        rate=sample_rate,
        input=True,
        frames_per_buffer=chunk,
    )

    print(f"开始录音 ({duration} 秒)...")
    frames = []
    for _ in range(0, int(sample_rate / chunk * duration)):
        data = stream.read(chunk)
        frames.append(data)

    stream.stop_stream()
    stream.close()
    pa.terminate()
    print("录音结束")

    import io
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(sample_width)
        wf.setframerate(sample_rate)
        wf.writeframes(b"".join(frames))
    return buf.getvalue()


def main():
    parser = argparse.ArgumentParser(description="豆包 ASR 测试")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--file", help="本地音频文件路径")
    group.add_argument("--url", help="远程音频 URL")
    group.add_argument("--record", type=int, metavar="SECONDS", help="录音秒数")
    args = parser.parse_args()

    client = DoubaoAsrClient()
    print(f"App Key: {client.app_key[:8]}...") if client.app_key else None

    start = time.time()

    if args.file:
        path = Path(args.file)
        if not path.exists():
            print(f"文件不存在: {path}")
            sys.exit(1)
        print(f"识别文件: {path} ({path.stat().st_size} bytes)")
        result = client.transcribe_file(path)

    elif args.url:
        print(f"识别 URL: {args.url}")
        result = client.transcribe_url(args.url)

    elif args.record:
        wav_data = record_audio(args.record)
        print(f"WAV 数据: {len(wav_data)} bytes")
        result = client.transcribe_bytes(wav_data)

    elapsed = time.time() - start

    print()
    print("=" * 50)
    print(f"识别结果: {result.text}")
    print(f"音频时长: {result.duration_ms} ms")
    print(f"请求耗时: {elapsed:.2f} s")
    print("=" * 50)

    if result.raw and "result" in result.raw:
        utterances = result.raw["result"].get("utterances", [])
        if utterances:
            print(f"\n详细时间戳 ({len(utterances)} 段):")
            for u in utterances:
                print(
                    f"  [{u['start_time']}ms - {u['end_time']}ms] {u['text']}"
                )


if __name__ == "__main__":
    main()
