"""豆包大模型录音文件极速版 ASR 封装。

环境变量：
  DOUBAO_ASR_APP_KEY   – 火山引擎控制台 App Key（新版控制台）
  DOUBAO_ASR_ACCESS_KEY – Access Key（旧版控制台，新版可不填）

一次请求即返回识别结果，支持 WAV / MP3 / OGG OPUS，音频 ≤100MB、时长 ≤2h。
"""

from __future__ import annotations

import base64
import logging
import os
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import requests

logger = logging.getLogger(__name__)

_RECOGNIZE_URL = (
    "https://openspeech.bytedance.com/api/v3/auc/bigmodel/recognize/flash"
)
_RESOURCE_ID = "volc.bigasr.auc_turbo"


@dataclass
class AsrResult:
    text: str
    duration_ms: int = 0
    raw: Optional[dict] = None


class DoubaoAsrClient:
    """豆包 ASR 客户端，可被 skill_creator / skill_observer 共享。"""

    def __init__(
        self,
        app_key: str = "",
        access_key: str = "",
        timeout: int = 60,
    ):
        self.app_key = app_key or os.getenv("DOUBAO_ASR_APP_KEY", "")
        self.access_key = access_key or os.getenv("DOUBAO_ASR_ACCESS_KEY", "")
        self.timeout = timeout

        if not self.app_key:
            logger.warning(
                "DOUBAO_ASR_APP_KEY not set – ASR transcription will fail"
            )

    def _build_headers(self) -> dict:
        headers = {
            "X-Api-Resource-Id": _RESOURCE_ID,
            "X-Api-Request-Id": str(uuid.uuid4()),
            "X-Api-Sequence": "-1",
        }
        if self.access_key:
            headers["X-Api-App-Key"] = self.app_key
            headers["X-Api-Access-Key"] = self.access_key
        else:
            headers["X-Api-Key"] = self.app_key
        return headers

    def transcribe_bytes(self, audio_bytes: bytes) -> AsrResult:
        """从内存中的音频二进制数据进行识别。"""
        b64 = base64.b64encode(audio_bytes).decode("utf-8")
        return self._recognize(audio_data={"data": b64})

    def transcribe_file(self, file_path: str | Path) -> AsrResult:
        """从本地文件进行识别。"""
        data = Path(file_path).read_bytes()
        return self.transcribe_bytes(data)

    def transcribe_url(self, url: str) -> AsrResult:
        """从音频 URL 进行识别。"""
        return self._recognize(audio_data={"url": url})

    def _recognize(self, audio_data: dict) -> AsrResult:
        if not self.app_key:
            raise RuntimeError(
                "ASR 未配置：请设置 DOUBAO_ASR_APP_KEY 环境变量"
            )

        payload = {
            "user": {"uid": self.app_key},
            "audio": audio_data,
            "request": {"model_name": "bigmodel"},
        }

        headers = self._build_headers()
        logger.info("ASR request %s", headers.get("X-Api-Request-Id"))

        resp = requests.post(
            _RECOGNIZE_URL,
            json=payload,
            headers=headers,
            timeout=self.timeout,
        )

        status_code = resp.headers.get("X-Api-Status-Code", "")
        message = resp.headers.get("X-Api-Message", "")
        log_id = resp.headers.get("X-Tt-Logid", "")

        if status_code == "20000000":
            body = resp.json()
            text = body.get("result", {}).get("text", "")
            duration = body.get("audio_info", {}).get("duration", 0)
            logger.info(
                "ASR success: %d ms, logid=%s, text=%s",
                duration, log_id, text[:80],
            )
            return AsrResult(text=text, duration_ms=duration, raw=body)

        if status_code == "20000003":
            logger.info("ASR: silent audio, logid=%s", log_id)
            return AsrResult(text="", duration_ms=0, raw=resp.json() if resp.content else None)

        error_msg = f"ASR failed: status={status_code}, msg={message}, logid={log_id}"
        logger.error(error_msg)
        raise RuntimeError(error_msg)


_default_client: Optional[DoubaoAsrClient] = None


def get_asr_client() -> DoubaoAsrClient:
    """获取/创建全局单例 ASR 客户端。"""
    global _default_client
    if _default_client is None:
        _default_client = DoubaoAsrClient()
    return _default_client
