"""Forge OS v2 filesystem layout helpers.

All on-disk artifacts live under a single `FORGE_DATA_ROOT` and follow
this structure:

    {root}/
      skills/
        company_{cid}/
          skill_{skill_id}/         # SKILL.md + assets/
      observer_log/
        company_{cid}/
          employee_{eid}/
            skill_{skill_id}/
              {segment_name}/       # seg_<ts>/  → low/, high/, qa_log.json
              task_<ts>.json        # 与 segments 兄弟节点，不再按 session 分组
      qa_logs.db
      skill_oa/oa.db

Skill packages are keyed by OA's primary key `skill_id` rather than by
name, which is why `skill_creator` now registers with OA *first*, gets
the assigned id, writes the bundle to disk under the id-keyed path, then
PATCHes OA's `package_path`. observer artifacts (segment results +
per-cycle task logs) are scoped by (company, employee, skill) so a single
employee's logs never get mixed with another's.

Helpers here are deliberately pure (no I/O) so they're trivial to test
and safe to call before the directory exists. All ids are coerced via
`int(...)` so a tampered JWT claim cannot smuggle path segments via
formatting (e.g. `"../../etc"`).
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional


def default_root() -> Path:
    """Return the configured data root.

    Resolution order:
      1. `FORGE_DATA_ROOT` env var (recommended for production deployments).
      2. `<repo_root>/data` — the legacy location, kept for dev parity.

    The repo root is computed relative to this file (common/ → repo/).
    """
    env = os.getenv("FORGE_DATA_ROOT")
    if env:
        return Path(env).expanduser().resolve()
    return Path(__file__).resolve().parent.parent / "data"


def _coerce_root(root: Optional[Path]) -> Path:
    return Path(root) if root is not None else default_root()


# ---- Skill packages --------------------------------------------------------

def skill_root(*, root: Optional[Path] = None) -> Path:
    """Top-level container for every company's skill packages."""
    return _coerce_root(root) / "skills"


def skill_company_dir(company_id: int, *, root: Optional[Path] = None) -> Path:
    """Per-company skill directory: holds all `skill_<id>/` bundles for one company."""
    return skill_root(root=root) / f"company_{int(company_id)}"


def skill_package_dir(company_id: int, skill_id: int,
                      *, root: Optional[Path] = None) -> Path:
    """Concrete on-disk directory for one skill bundle.

    Keyed by OA's `skill_id` (the primary key), not by the human-friendly
    name. The id is globally unique and stable across renames, which makes
    it the natural filesystem key.
    """
    return skill_company_dir(company_id, root=root) / f"skill_{int(skill_id)}"


# ---- Observer logs ---------------------------------------------------------

def observer_log_root(*, root: Optional[Path] = None) -> Path:
    """Top-level container for every employee's segment + task logs."""
    return _coerce_root(root) / "observer_log"


def observer_skill_dir(company_id: int, employee_id: int, skill_id: int,
                       *, root: Optional[Path] = None) -> Path:
    """Per-(company, employee, skill) container for observer artifacts.

    Holds `<segment_name>/` subdirs (frame dumps + qa_log.json) plus
    sibling `task_<ts>.json` files written per pipeline cycle. Task logs
    are not nested under a per-segment dir because one cycle can produce
    0..N segments.
    """
    return (
        observer_log_root(root=root)
        / f"company_{int(company_id)}"
        / f"employee_{int(employee_id)}"
        / f"skill_{int(skill_id)}"
    )


def segment_dir(company_id: int, employee_id: int, skill_id: int,
                segment_name: str, *, root: Optional[Path] = None) -> Path:
    """One segment's directory (frames + qa_log.json).

    `segment_name` is `seg_<ts>` as produced by VideoMonitor; we don't
    sanitize further because the caller already controls the format and
    the (cid, eid, sid) prefix is bounded by int coercion.
    """
    return observer_skill_dir(
        company_id, employee_id, skill_id, root=root,
    ) / segment_name
