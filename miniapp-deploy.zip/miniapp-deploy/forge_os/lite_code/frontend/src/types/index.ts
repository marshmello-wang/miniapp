export interface Workspace {
  name: string
  project_path: string
  enabled_skills: string[]
}

export interface Session {
  session_id: string
  created_at: number
  updated_at: number
  round_count: number
}

export interface ContentBlock {
  type: 'text' | 'thinking' | 'tool_call' | 'tool_result'
  text?: string
  tool_name?: string
  tool_input?: Record<string, unknown>
  result?: string
  is_error?: boolean
  call_id?: string
}

export interface AgentEvent {
  type: 'event' | 'status' | 'error'
  event_id?: string
  event_type?: string
  content?: ContentBlock[]
  metadata?: Record<string, unknown>
  status?: string
  message?: string
  round_idx?: number
}

export interface Round {
  round_idx: number
  user_content: Array<{ type: string; content: string }>
  ai_content: Array<{ type: string; content: string }> | null
  trajectory: AgentEvent[] | null
  created_at: number
  updated_at: number
}

export interface FileNode {
  name: string
  type: 'file' | 'dir'
  path: string
  size?: number
  children?: FileNode[]
}

export interface Skill {
  name: string
  description: string
  path: string
  has_assets: boolean
}
