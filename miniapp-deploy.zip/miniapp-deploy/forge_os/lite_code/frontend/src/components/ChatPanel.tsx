import { useState, useRef, useEffect } from 'react'
import { Send, Loader2 } from 'lucide-react'
import MessageBubble from './MessageBubble.tsx'
import type { Round, ContentBlock } from '../types'

interface Props {
  rounds: Round[]
  streamingBlocks: ContentBlock[]
  isRunning: boolean
  onSend: (content: string) => void
  pendingUserMessage?: string | null
  error?: string | null
  disabled?: boolean
}

export default function ChatPanel({ rounds, streamingBlocks, isRunning, onSend, pendingUserMessage, error, disabled }: Props) {
  const [input, setInput] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [rounds, streamingBlocks])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const trimmed = input.trim()
    if (!trimmed || isRunning || disabled) return
    onSend(trimmed)
    setInput('')
  }

  if (disabled) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-zinc-500">
        <Send size={32} className="mb-3 text-zinc-600" />
        <p className="text-sm">Select or create a session to start chatting</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto px-4 py-4">
        {rounds.length === 0 && streamingBlocks.length === 0 && !pendingUserMessage && (
          <div className="flex items-center justify-center h-full text-zinc-500 text-sm">
            Start a conversation...
          </div>
        )}

        {rounds.map((round) => (
          <div key={round.round_idx}>
            {round.user_content?.map((c, i) => (
              <MessageBubble key={`u-${round.round_idx}-${i}`} role="user" content={c.content} />
            ))}
            {round.ai_content?.map((c, i) => (
              <MessageBubble
                key={`a-${round.round_idx}-${i}`}
                role="assistant"
                content={c.content}
                blocks={_extractBlocks(round.trajectory)}
              />
            ))}
          </div>
        ))}

        {pendingUserMessage && (
          <MessageBubble role="user" content={pendingUserMessage} />
        )}

        {streamingBlocks.length > 0 && (
          <div className="mb-4">
            <MessageBubble
              role="assistant"
              content={_extractText(streamingBlocks)}
              blocks={streamingBlocks}
              streaming
            />
          </div>
        )}

        {isRunning && streamingBlocks.length === 0 && (
          <div className="flex items-center gap-2 text-zinc-500 text-sm mb-4">
            <Loader2 size={14} className="animate-spin" />
            <span>Thinking...</span>
          </div>
        )}

        {error && (
          <div className="mb-4 px-4 py-2 bg-red-900/20 border border-red-800/50 rounded-lg text-red-300 text-sm">
            <strong>Error:</strong> {error}
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="border-t border-zinc-800 px-4 py-3">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask me to code something..."
            className="flex-1 bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-blue-500 transition-colors"
            disabled={isRunning}
          />
          <button
            type="submit"
            disabled={isRunning || !input.trim()}
            className="p-2 bg-blue-600 hover:bg-blue-500 disabled:bg-zinc-700 disabled:text-zinc-500 rounded-lg text-white transition-colors"
          >
            <Send size={16} />
          </button>
        </div>
      </form>
    </div>
  )
}

function _extractBlocks(trajectory: unknown[] | null): ContentBlock[] {
  if (!trajectory) return []
  const blocks: ContentBlock[] = []
  for (const event of trajectory as Array<{ content?: ContentBlock[] }>) {
    if (event.content) {
      for (const block of event.content) {
        if (block.type === 'tool_call' || block.type === 'tool_result' || block.type === 'thinking') {
          blocks.push(block)
        }
      }
    }
  }
  return blocks
}

function _extractText(blocks: ContentBlock[]): string {
  return blocks
    .filter(b => b.type === 'text' && b.text)
    .map(b => b.text!)
    .join('\n')
}
