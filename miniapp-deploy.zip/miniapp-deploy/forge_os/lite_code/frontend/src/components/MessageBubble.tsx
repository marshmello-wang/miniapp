import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { Terminal, ChevronDown, ChevronRight, Brain } from 'lucide-react'
import { useState, useEffect } from 'react'
import type { ContentBlock } from '../types'

interface Props {
  role: 'user' | 'assistant'
  content: string
  blocks?: ContentBlock[]
  streaming?: boolean
}

export default function MessageBubble({ role, content, blocks, streaming }: Props) {
  if (role === 'user') {
    return (
      <div className="flex justify-end mb-4">
        <div className="max-w-[80%] bg-blue-600/20 border border-blue-500/30 rounded-lg px-4 py-2 text-sm text-zinc-200">
          {content}
        </div>
      </div>
    )
  }

  return (
    <div className="mb-4">
      {blocks && blocks.length > 0 && <TrajectoryBlocks blocks={blocks} streaming={streaming} />}
      {content && (
        <div className="max-w-[90%] text-sm">
          <div className="prose prose-invert prose-sm chat-markdown max-w-none">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {content}
            </ReactMarkdown>
          </div>
        </div>
      )}
    </div>
  )
}

function TrajectoryBlocks({ blocks, streaming }: { blocks: ContentBlock[]; streaming?: boolean }) {
  const relevantBlocks = blocks.filter(b => b.type === 'tool_call' || b.type === 'tool_result' || b.type === 'thinking')
  if (relevantBlocks.length === 0) return null

  return (
    <div className="mb-2 space-y-1">
      {relevantBlocks.map((block, i) => {
        if (block.type === 'thinking') {
          const isLast = i === relevantBlocks.length - 1
          return <ThinkingBlockItem key={i} block={block} streaming={!!(streaming && isLast)} />
        }
        return <ToolBlockItem key={i} block={block} />
      })}
    </div>
  )
}

function ThinkingBlockItem({ block, streaming }: { block: ContentBlock; streaming?: boolean }) {
  const [expanded, setExpanded] = useState(true)

  useEffect(() => {
    if (!streaming) {
      setExpanded(false)
    }
  }, [streaming])

  const thinkingText = block.text || ''
  const previewLength = 60
  const preview = thinkingText.length > previewLength
    ? thinkingText.slice(0, previewLength) + '...'
    : thinkingText

  return (
    <div className="border border-purple-800/40 rounded bg-purple-950/20 text-xs">
      <div
        className="flex items-center px-2 py-1 cursor-pointer hover:bg-purple-900/20"
        onClick={() => setExpanded(!expanded)}
      >
        {expanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
        <Brain size={12} className="mx-1 text-purple-400" />
        <span className="text-purple-300 font-medium">Thinking</span>
        {!expanded && (
          <span className="ml-2 text-zinc-500 truncate">{preview}</span>
        )}
        {streaming && (
          <span className="ml-auto text-purple-400/60 animate-pulse text-[10px]">●</span>
        )}
      </div>
      {expanded && (
        <pre className="px-3 py-2 border-t border-purple-800/30 overflow-x-auto text-zinc-400 text-[11px] max-h-64 overflow-y-auto whitespace-pre-wrap break-words">
          {thinkingText}
        </pre>
      )}
    </div>
  )
}

function ToolBlockItem({ block }: { block: ContentBlock }) {
  const [expanded, setExpanded] = useState(false)

  if (block.type === 'tool_call') {
    return (
      <div className="border border-zinc-700/50 rounded bg-zinc-900/50 text-xs">
        <div
          className="flex items-center px-2 py-1 cursor-pointer hover:bg-zinc-800/50"
          onClick={() => setExpanded(!expanded)}
        >
          {expanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
          <Terminal size={12} className="mx-1 text-amber-400" />
          <span className="text-amber-300 font-mono">{block.tool_name}</span>
        </div>
        {expanded && block.tool_input && (
          <pre className="px-3 py-2 border-t border-zinc-800 overflow-x-auto text-zinc-400 text-[11px]">
            {JSON.stringify(block.tool_input, null, 2)}
          </pre>
        )}
      </div>
    )
  }

  if (block.type === 'tool_result') {
    const isError = block.is_error
    return (
      <div className={`border rounded bg-zinc-900/50 text-xs ${isError ? 'border-red-800/50' : 'border-zinc-700/50'}`}>
        <div
          className="flex items-center px-2 py-1 cursor-pointer hover:bg-zinc-800/50"
          onClick={() => setExpanded(!expanded)}
        >
          {expanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
          <span className={`ml-1 font-mono ${isError ? 'text-red-400' : 'text-green-400'}`}>
            {block.tool_name} {isError ? '✗' : '✓'}
          </span>
        </div>
        {expanded && block.result && (
          <pre className="px-3 py-2 border-t border-zinc-800 overflow-x-auto text-zinc-400 text-[11px] max-h-48 overflow-y-auto">
            {block.result}
          </pre>
        )}
      </div>
    )
  }

  return null
}
