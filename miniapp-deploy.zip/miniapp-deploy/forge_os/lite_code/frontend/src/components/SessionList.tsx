import { Plus, Trash2, MessageSquare } from 'lucide-react'
import type { Session } from '../types'

interface Props {
  sessions: Session[]
  activeSessionId: string | null
  onSelect: (sessionId: string) => void
  onCreate: () => void
  onDelete: (sessionId: string) => void
}

export default function SessionList({ sessions, activeSessionId, onSelect, onCreate, onDelete }: Props) {
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-2 border-b border-zinc-800">
        <h2 className="text-sm font-medium text-zinc-300">Sessions</h2>
        <button
          onClick={onCreate}
          className="p-1 rounded hover:bg-zinc-700 text-zinc-400 hover:text-zinc-200 transition-colors"
          title="New session"
        >
          <Plus size={16} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {sessions.length === 0 ? (
          <div className="px-3 py-8 text-center text-zinc-500 text-xs">
            No sessions yet
          </div>
        ) : (
          <ul className="py-1">
            {sessions.map((s) => (
              <li
                key={s.session_id}
                className={`group flex items-center px-3 py-2 cursor-pointer transition-colors ${
                  s.session_id === activeSessionId
                    ? 'bg-zinc-800 text-zinc-100'
                    : 'text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-200'
                }`}
                onClick={() => onSelect(s.session_id)}
              >
                <MessageSquare size={14} className="mr-2 shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="text-xs truncate">
                    {s.session_id.slice(0, 16)}...
                  </div>
                  <div className="text-[10px] text-zinc-500">
                    {s.round_count} rounds
                  </div>
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); onDelete(s.session_id) }}
                  className="p-1 rounded opacity-0 group-hover:opacity-100 hover:bg-zinc-700 text-zinc-500 hover:text-red-400 transition-all"
                >
                  <Trash2 size={12} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
