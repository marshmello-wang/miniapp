import { useCallback, useRef } from 'react'

interface Props {
  onResize: (delta: number) => void
}

export default function ResizeHandle({ onResize }: Props) {
  const startXRef = useRef(0)
  const draggingRef = useRef(false)

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault()
    startXRef.current = e.clientX
    draggingRef.current = true

    const handleMouseMove = (ev: MouseEvent) => {
      if (!draggingRef.current) return
      const delta = ev.clientX - startXRef.current
      startXRef.current = ev.clientX
      onResize(delta)
    }

    const handleMouseUp = () => {
      draggingRef.current = false
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseup', handleMouseUp)
      document.body.style.cursor = ''
      document.body.style.userSelect = ''
    }

    document.addEventListener('mousemove', handleMouseMove)
    document.addEventListener('mouseup', handleMouseUp)
    document.body.style.cursor = 'col-resize'
    document.body.style.userSelect = 'none'
  }, [onResize])

  return (
    <div
      onMouseDown={handleMouseDown}
      className="w-1 cursor-col-resize bg-zinc-800 hover:bg-blue-500/50 active:bg-blue-500/70 transition-colors shrink-0"
    />
  )
}
