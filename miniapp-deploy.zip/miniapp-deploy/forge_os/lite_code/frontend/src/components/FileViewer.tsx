import { FileCode, Loader2 } from 'lucide-react'

interface Props {
  filePath: string | null
  content: string | null
  loading: boolean
}

export default function FileViewer({ filePath, content, loading }: Props) {
  if (!filePath) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-zinc-500">
        <FileCode size={40} className="mb-3 text-zinc-600" />
        <p className="text-sm">Click a file in the tree to view its contents</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-zinc-500">
        <Loader2 size={20} className="animate-spin mb-2" />
        <p className="text-xs">Loading...</p>
      </div>
    )
  }

  const lines = (content || '').split('\n')
  const gutterWidth = String(lines.length).length

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center px-3 py-1.5 border-b border-zinc-800 bg-zinc-900/50 shrink-0">
        <FileCode size={14} className="mr-2 text-zinc-500" />
        <span className="text-xs text-zinc-300 truncate font-mono">{filePath}</span>
      </div>
      <div className="flex-1 overflow-auto font-mono text-xs leading-5">
        <table className="w-full border-collapse">
          <tbody>
            {lines.map((line, i) => (
              <tr key={i} className="hover:bg-zinc-800/40">
                <td className="sticky left-0 bg-zinc-900/80 text-zinc-600 text-right pr-3 pl-2 select-none border-r border-zinc-800" style={{ width: `${gutterWidth + 2}ch` }}>
                  {i + 1}
                </td>
                <td className="pl-3 pr-4 text-zinc-300 whitespace-pre">
                  {line || ' '}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
