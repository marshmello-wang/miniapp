import { useState } from 'react'
import { ChevronRight, ChevronDown, File, Folder } from 'lucide-react'
import type { FileNode } from '../types'

interface Props {
  tree: FileNode[]
  onFileClick?: (path: string) => void
}

export default function FileTree({ tree, onFileClick }: Props) {
  return (
    <div className="flex flex-col h-full">
      <div className="px-3 py-2 border-b border-zinc-800">
        <h2 className="text-sm font-medium text-zinc-300">Files</h2>
      </div>
      <div className="flex-1 overflow-y-auto py-1">
        {tree.length === 0 ? (
          <div className="px-3 py-8 text-center text-zinc-500 text-xs">
            No workspace loaded
          </div>
        ) : (
          tree.map((node) => (
            <TreeNode key={node.path} node={node} depth={0} onFileClick={onFileClick} />
          ))
        )}
      </div>
    </div>
  )
}

function TreeNode({ node, depth, onFileClick }: { node: FileNode; depth: number; onFileClick?: (path: string) => void }) {
  const [expanded, setExpanded] = useState(depth < 1)

  const paddingLeft = 12 + depth * 16

  if (node.type === 'file') {
    return (
      <div
        className="flex items-center py-0.5 px-2 text-xs text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-200 cursor-pointer transition-colors"
        style={{ paddingLeft }}
        onClick={() => onFileClick?.(node.path)}
      >
        <File size={12} className="mr-1.5 shrink-0 text-zinc-500" />
        <span className="truncate">{node.name}</span>
      </div>
    )
  }

  return (
    <div>
      <div
        className="flex items-center py-0.5 px-2 text-xs text-zinc-300 hover:bg-zinc-800/50 cursor-pointer transition-colors"
        style={{ paddingLeft }}
        onClick={() => setExpanded(!expanded)}
      >
        {expanded ? (
          <ChevronDown size={12} className="mr-1 shrink-0 text-zinc-500" />
        ) : (
          <ChevronRight size={12} className="mr-1 shrink-0 text-zinc-500" />
        )}
        <Folder size={12} className="mr-1.5 shrink-0 text-zinc-500" />
        <span className="truncate">{node.name}</span>
      </div>
      {expanded && node.children && (
        <div>
          {node.children.map((child) => (
            <TreeNode key={child.path} node={child} depth={depth + 1} onFileClick={onFileClick} />
          ))}
        </div>
      )}
    </div>
  )
}
