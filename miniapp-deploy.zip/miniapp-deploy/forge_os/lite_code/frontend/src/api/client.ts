import type { Workspace, Session, Round, FileNode, Skill, AgentEvent } from '../types'

const BASE = ''

export async function fetchWorkspaces(): Promise<Workspace[]> {
  const res = await fetch(`${BASE}/api/workspaces`)
  const data = await res.json()
  return data.workspaces
}

export async function createWorkspace(name: string, projectPath: string): Promise<Workspace> {
  const res = await fetch(`${BASE}/api/workspaces`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, project_path: projectPath }),
  })
  return res.json()
}

export async function fetchSessions(workspaceName: string): Promise<Session[]> {
  const res = await fetch(`${BASE}/api/workspace/${workspaceName}/sessions`)
  const data = await res.json()
  return data.sessions
}

export async function createSession(workspaceName: string): Promise<string> {
  const res = await fetch(`${BASE}/api/workspace/${workspaceName}/sessions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({}),
  })
  const data = await res.json()
  return data.session_id
}

export async function deleteSession(workspaceName: string, sessionId: string): Promise<void> {
  await fetch(`${BASE}/api/workspace/${workspaceName}/sessions/${sessionId}`, {
    method: 'DELETE',
  })
}

export async function fetchRounds(workspaceName: string, sessionId: string): Promise<Round[]> {
  const res = await fetch(`${BASE}/api/workspace/${workspaceName}/sessions/${sessionId}/rounds`)
  const data = await res.json()
  return data.rounds
}

export async function fetchFileTree(workspaceName: string): Promise<FileNode[]> {
  const res = await fetch(`${BASE}/api/workspace/${workspaceName}/files`)
  const data = await res.json()
  return data.tree
}

export async function fetchFileContent(workspaceName: string, filePath: string): Promise<string> {
  const res = await fetch(`${BASE}/api/workspace/${workspaceName}/file?path=${encodeURIComponent(filePath)}`)
  const data = await res.json()
  return data.content
}

export async function fetchSkills(): Promise<Skill[]> {
  const res = await fetch(`${BASE}/api/skills`)
  const data = await res.json()
  return data.skills
}

export async function updateWorkspaceSkills(workspaceName: string, enabledSkills: string[]): Promise<void> {
  await fetch(`${BASE}/api/workspace/${workspaceName}/skills`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ enabled_skills: enabledSkills }),
  })
}

export function createWebSocket(workspaceName: string): WebSocket {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
  const host = window.location.host
  return new WebSocket(`${protocol}//${host}/ws/${workspaceName}`)
}
