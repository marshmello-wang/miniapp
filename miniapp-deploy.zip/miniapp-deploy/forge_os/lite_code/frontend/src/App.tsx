import { useState, useEffect, useCallback } from 'react'
import { FolderOpen, Settings } from 'lucide-react'
import SessionList from './components/SessionList.tsx'
import ChatPanel from './components/ChatPanel.tsx'
import FileTree from './components/FileTree.tsx'
import FileViewer from './components/FileViewer.tsx'
import ResizeHandle from './components/ResizeHandle.tsx'
import { useWebSocket } from './hooks/useWebSocket.ts'
import {
  fetchWorkspaces,
  createWorkspace,
  fetchSessions,
  createSession,
  deleteSession,
  fetchRounds,
  fetchFileTree,
  fetchFileContent,
} from './api/client.ts'
import type { Workspace, Session, Round, FileNode, ContentBlock } from './types'

export default function App() {
  const [workspaces, setWorkspaces] = useState<Workspace[]>([])
  const [activeWorkspace, setActiveWorkspace] = useState<string | null>(null)
  const [sessions, setSessions] = useState<Session[]>([])
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null)
  const [rounds, setRounds] = useState<Round[]>([])
  const [fileTree, setFileTree] = useState<FileNode[]>([])
  const [streamingBlocks, setStreamingBlocks] = useState<ContentBlock[]>([])
  const [isRunning, setIsRunning] = useState(false)
  const [pendingUserMessage, setPendingUserMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const [activeFilePath, setActiveFilePath] = useState<string | null>(null)
  const [fileContent, setFileContent] = useState<string | null>(null)
  const [fileLoading, setFileLoading] = useState(false)

  const [panelWidths, setPanelWidths] = useState({
    sessions: 224,
    chat: 320,
    fileTree: 256,
  })

  const handleEvent = useCallback((event: { type: string; event_type?: string; content?: ContentBlock[]; status?: string; message?: string }) => {
    if (event.type === 'event') {
      if (event.event_type === 'reasoning' && event.content) {
        setStreamingBlocks(prev => [...prev, ...event.content!])
      } else if (event.event_type === 'tool_result' && event.content) {
        setStreamingBlocks(prev => [...prev, ...event.content!])
      } else if (event.event_type === 'error' && event.content) {
        const errText = event.content.map(b => b.text || '').join(' ')
        setError(errText || 'Agent error')
        setIsRunning(false)
        setPendingUserMessage(null)
      }
    } else if (event.type === 'status') {
      if (event.status === 'running') {
        setIsRunning(true)
        setError(null)
        setStreamingBlocks([])
      } else if (event.status === 'complete') {
        setIsRunning(false)
        setPendingUserMessage(null)
        setStreamingBlocks([])
        if (activeWorkspace && activeSessionId) {
          fetchRounds(activeWorkspace, activeSessionId).then(setRounds)
        }
        if (activeWorkspace) {
          fetchFileTree(activeWorkspace).then(setFileTree)
        }
      }
    } else if (event.type === 'error') {
      setIsRunning(false)
      setError(event.message || 'Unknown error')
      setPendingUserMessage(null)
      if (activeWorkspace && activeSessionId) {
        fetchRounds(activeWorkspace, activeSessionId).then(setRounds)
      }
    }
  }, [activeWorkspace, activeSessionId])

  const { sendMessage, connected } = useWebSocket(activeWorkspace, handleEvent)

  useEffect(() => {
    fetchWorkspaces().then((ws) => {
      setWorkspaces(ws)
      if (ws.length > 0 && !activeWorkspace) {
        setActiveWorkspace(ws[0].name)
      }
    })
  }, [])

  useEffect(() => {
    if (!activeWorkspace) return
    setActiveSessionId(null)
    setRounds([])
    fetchSessions(activeWorkspace).then((ss) => {
      setSessions(ss)
      if (ss.length > 0) {
        setActiveSessionId(ss[0].session_id)
      }
    })
    fetchFileTree(activeWorkspace).then(setFileTree)
  }, [activeWorkspace])

  useEffect(() => {
    if (!activeWorkspace || !activeSessionId) {
      setRounds([])
      return
    }
    fetchRounds(activeWorkspace, activeSessionId).then(setRounds)
  }, [activeWorkspace, activeSessionId])

  const handleCreateSession = async () => {
    if (!activeWorkspace) return
    const sid = await createSession(activeWorkspace)
    setSessions(prev => [{ session_id: sid, created_at: Date.now() / 1000, updated_at: Date.now() / 1000, round_count: 0 }, ...prev])
    setActiveSessionId(sid)
    setRounds([])
  }

  const handleDeleteSession = async (sessionId: string) => {
    if (!activeWorkspace) return
    await deleteSession(activeWorkspace, sessionId)
    setSessions(prev => prev.filter(s => s.session_id !== sessionId))
    if (activeSessionId === sessionId) {
      setActiveSessionId(null)
      setRounds([])
    }
  }

  const handleSend = (content: string) => {
    if (!activeSessionId || !connected) {
      setError(`Cannot send: ${!activeSessionId ? 'no active session' : 'not connected'}`)
      return
    }
    setPendingUserMessage(content)
    setError(null)
    sendMessage({ type: 'chat', session_id: activeSessionId, content })
  }

  const handleCreateWorkspace = async () => {
    const name = prompt('Workspace name:')
    if (!name) return
    const path = prompt('Project path (absolute):')
    if (!path) return
    await createWorkspace(name, path)
    const ws = await fetchWorkspaces()
    setWorkspaces(ws)
    setActiveWorkspace(name)
  }

  const handleFileClick = async (filePath: string) => {
    if (!activeWorkspace) return
    setActiveFilePath(filePath)
    setFileLoading(true)
    setFileContent(null)
    try {
      const content = await fetchFileContent(activeWorkspace, filePath)
      setFileContent(content)
    } catch {
      setFileContent('Failed to load file content')
    } finally {
      setFileLoading(false)
    }
  }

  const handleResize = (panel: 'sessions' | 'chat' | 'fileTree', delta: number) => {
    setPanelWidths(prev => {
      const minWidth = 120
      const newWidth = Math.max(minWidth, prev[panel] + delta)
      return { ...prev, [panel]: newWidth }
    })
  }

  return (
    <div className="h-screen flex flex-col bg-zinc-950 text-zinc-100">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-2 border-b border-zinc-800 bg-zinc-900/50">
        <div className="flex items-center gap-3">
          <span className="text-lg font-semibold">⚡ Lite Code</span>
          <select
            value={activeWorkspace || ''}
            onChange={(e) => setActiveWorkspace(e.target.value || null)}
            className="bg-zinc-800 border border-zinc-700 rounded px-2 py-1 text-xs text-zinc-300"
          >
            {workspaces.map(w => (
              <option key={w.name} value={w.name}>{w.name}</option>
            ))}
          </select>
          <button
            onClick={handleCreateWorkspace}
            className="p-1 rounded hover:bg-zinc-700 text-zinc-400 hover:text-zinc-200"
            title="Add workspace"
          >
            <FolderOpen size={16} />
          </button>
        </div>
        <div className="flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full ${connected ? 'bg-green-500' : 'bg-red-500'}`} />
          <span className="text-xs text-zinc-500">{connected ? 'Connected' : 'Disconnected'}</span>
          <button className="p-1 rounded hover:bg-zinc-700 text-zinc-400">
            <Settings size={16} />
          </button>
        </div>
      </header>

      {/* Main four-panel layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left: Session List */}
        <div className="shrink-0 overflow-hidden border-r border-zinc-800 bg-zinc-900/30" style={{ width: panelWidths.sessions }}>
          <SessionList
            sessions={sessions}
            activeSessionId={activeSessionId}
            onSelect={setActiveSessionId}
            onCreate={handleCreateSession}
            onDelete={handleDeleteSession}
          />
        </div>

        <ResizeHandle onResize={(d) => handleResize('sessions', d)} />

        {/* Chat Panel */}
        <div className="shrink-0 overflow-hidden border-r border-zinc-800" style={{ width: panelWidths.chat }}>
          <ChatPanel
            rounds={rounds}
            streamingBlocks={streamingBlocks}
            isRunning={isRunning}
            onSend={handleSend}
            pendingUserMessage={pendingUserMessage}
            error={error}
            disabled={!activeSessionId}
          />
        </div>

        <ResizeHandle onResize={(d) => handleResize('chat', d)} />

        {/* Center: File Viewer (flex-1, takes remaining space) */}
        <div className="flex-1 min-w-0 overflow-hidden">
          <FileViewer
            filePath={activeFilePath}
            content={fileContent}
            loading={fileLoading}
          />
        </div>

        <ResizeHandle onResize={(d) => handleResize('fileTree', -d)} />

        {/* Right: File Tree */}
        <div className="shrink-0 overflow-hidden border-l border-zinc-800 bg-zinc-900/30" style={{ width: panelWidths.fileTree }}>
          <FileTree tree={fileTree} onFileClick={handleFileClick} />
        </div>
      </div>
    </div>
  )
}
