import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 3690,
    proxy: {
      '/api': {
        target: 'http://localhost:8690',
        changeOrigin: true,
      },
      '/ws': {
        target: 'ws://localhost:8690',
        ws: true,
      },
    },
  },
})
