"""
Lite Code - 本地 Coding Agent 应用
"""
