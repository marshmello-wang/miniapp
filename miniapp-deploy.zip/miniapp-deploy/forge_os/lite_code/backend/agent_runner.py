"""
Agent Runner - 编排 + 执行 Coding Agent

使用 OrchestratorAgent 编排单个 ReactAgent 节点。
负责根据配置构建 agent 实例并执行任务。
"""
import sys
import os
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from common.llm import LLMClient, LLMConfig
from common.agent_framework.agent_loop.react_agent import ReactAgent
from common.agent_framework.agent_loop.config import ReactAgentConfig, SkillConfig
from common.agent_framework.agent_loop.graph import StateGraph, AgentNode, END
from common.agent_framework.agent_loop.orchestrator_agent import (
    OrchestratorAgent, OrchestratorConfig,
)
from common.agent_framework.tool_adapter.registry import ToolRegistry
from common.agent_framework.context_strategy.default_strategy import DefaultContextStrategy
from common.agent_framework.context_strategy.memory.config import (
    MemoryConfig, L1Config, L2Config,
    AllocationBudgetConfig, HistoryCollapseConfig, CollapseStrategyConfig,
)
from common.agent_framework.user_interface.inputs import TaskInput, Message
from common.agent_framework.user_interface.events import Event
from common.agent_framework.builtin_tools import BashTool, TextEditTool
from common.agent_framework.builtin_tools.bash_tool import BashResult

from .tools import ReadFileTool, ListFilesTool, GrepSearchTool
from .config import get_llm_config, get_agent_config, get_memory_config
from .skill_loader import build_skill_config
from .context.system_prompt import get_system_prompt


class _CwdBashExecutor:
    """LocalBashExecutor with working directory support"""

    def __init__(self, cwd: str = "."):
        self._cwd = cwd

    async def execute(self, command: str, timeout: float) -> BashResult:
        import asyncio
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=self._cwd,
        )
        try:
            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                process.communicate(), timeout=timeout,
            )
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()
            raise

        return BashResult(
            exit_code=process.returncode or 0,
            stdout=stdout_bytes.decode("utf-8", errors="replace"),
            stderr=stderr_bytes.decode("utf-8", errors="replace"),
        )


def _build_memory_config(memory_dict: Dict[str, Any]) -> Optional[MemoryConfig]:
    """从 config dict 构建 MemoryConfig"""
    l1_dict = memory_dict.get("l1")
    if not l1_dict:
        return None

    budget_dict = l1_dict.get("budget", {})
    budget = AllocationBudgetConfig(
        max_total_tokens=budget_dict.get("max_total_tokens", 128000),
        system_prompt_tokens=budget_dict.get("system_prompt_tokens", 4000),
        memory_tokens=budget_dict.get("memory_tokens", 4000),
        react_stack_reserve=budget_dict.get("react_stack_reserve", 10000),
        final_output_reserve=budget_dict.get("final_output_reserve", 16000),
    )

    hc_dict = l1_dict.get("history_collapse", {})
    history_collapse = _build_history_collapse(hc_dict)

    l1 = L1Config(
        budget=budget,
        history_collapse=history_collapse,
        tool_call_collapse_whitelist=l1_dict.get("tool_call_collapse_whitelist", []),
        tool_response_collapse_whitelist=l1_dict.get("tool_response_collapse_whitelist", []),
    )

    l2 = None
    l2_dict = memory_dict.get("l2")
    if l2_dict:
        l2_hc = _build_history_collapse(l2_dict.get("history_collapse", {}))
        l2 = L2Config(
            history_collapse=l2_hc,
            after_collapse_max_length=l2_dict.get("after_collapse_max_length", 94000),
            tool_call_collapse_whitelist=l2_dict.get("tool_call_collapse_whitelist", []),
            tool_response_collapse_whitelist=l2_dict.get("tool_response_collapse_whitelist", []),
            protected_steps=l2_dict.get("protected_steps", 1),
            fallback_strategy=l2_dict.get("fallback_strategy", "abandon"),
        )

    return MemoryConfig(l1=l1, l2=l2)


def _build_history_collapse(hc_dict: Dict[str, Any]) -> HistoryCollapseConfig:
    """构建 HistoryCollapseConfig"""
    def _collapse(d: Dict[str, Any]) -> CollapseStrategyConfig:
        return CollapseStrategyConfig(
            type=d.get("type", "none"),
            collapse_prefix_length=d.get("collapse_prefix_length", 200),
        )

    return HistoryCollapseConfig(
        thinking_collapse=_collapse(hc_dict.get("thinking_collapse", {"type": "remove"})),
        tool_call_collapse=_collapse(hc_dict.get("tool_call_collapse", {"type": "none"})),
        tool_response_collapse=_collapse(hc_dict.get("tool_response_collapse", {"type": "prefix", "collapse_prefix_length": 200})),
    )


def create_agent(
    workspace_path: str,
    enabled_skills: Optional[List[str]] = None,
    config_override: Optional[Dict[str, Any]] = None,
) -> OrchestratorAgent:
    """
    创建 Coding Agent 实例

    Args:
        workspace_path: 工作区项目路径
        enabled_skills: 启用的 skill 名称列表
        config_override: 配置覆盖

    Returns:
        OrchestratorAgent 实例
    """
    llm_cfg = get_llm_config(config_override)
    agent_cfg = get_agent_config(config_override)
    memory_cfg_dict = get_memory_config(config_override)

    llm_client = LLMClient(LLMConfig(
        provider=llm_cfg["provider"],
        api_key=llm_cfg["api_key"],
        model=llm_cfg["model"],
        base_url=llm_cfg.get("base_url"),
    ))

    tool_registry = ToolRegistry()

    bash_executor = _CwdBashExecutor(cwd=workspace_path)
    tool_registry.register(BashTool(executor=bash_executor))
    tool_registry.register(TextEditTool(working_directory=workspace_path))
    tool_registry.register(ReadFileTool(working_directory=workspace_path))
    tool_registry.register(ListFilesTool(working_directory=workspace_path))
    tool_registry.register(GrepSearchTool(working_directory=workspace_path))

    memory_config = _build_memory_config(memory_cfg_dict)

    skill_config = None
    if enabled_skills:
        skill_dict = build_skill_config(enabled_skills)
        if skill_dict:
            skill_config = SkillConfig(
                skills_config=skill_dict["skills_config"],
                base_path=skill_dict["base_path"],
            )

    react_agent = ReactAgent(ReactAgentConfig(
        llm_client=llm_client,
        tool_registry=tool_registry,
        context_strategy=DefaultContextStrategy(),
        system_prompt=get_system_prompt(),
        max_iterations=agent_cfg.get("max_iterations", 30),
        max_tokens=agent_cfg.get("max_tokens", 8192),
        temperature=agent_cfg.get("temperature", 0.7),
        thinking_level=agent_cfg.get("thinking_level"),
        memory_config=memory_config,
        skill_config=skill_config,
    ))

    graph = StateGraph()
    graph.add_node("coding_agent", AgentNode(
        name="coding_agent",
        agent=react_agent,
        input_mapper=lambda state: state["task_input"],
        output_key="result",
    ))
    graph.set_entry_point("coding_agent")
    graph.set_finish_point("coding_agent")

    compiled = graph.compile()
    return OrchestratorAgent(OrchestratorConfig(graph=compiled))


def run_task(
    agent: OrchestratorAgent,
    session_id: str,
    task_id: str,
    user_message: str,
    history_messages: Optional[List[Dict[str, str]]] = None,
) -> Iterator[Event]:
    """
    执行一轮对话任务

    Args:
        agent: OrchestratorAgent 实例
        session_id: 会话 ID
        task_id: 任务 ID
        user_message: 用户输入文本
        history_messages: 历史消息 [{"role": "user"/"assistant", "content": "..."}]

    Yields:
        Event 事件流
    """
    messages = []
    if history_messages:
        for msg in history_messages:
            messages.append(Message.from_role_and_text(msg["role"], msg["content"]))
    messages.append(Message.from_role_and_text("user", user_message))

    task_input = TaskInput(
        session_id=session_id,
        task_id=task_id,
        messages=messages,
    )

    for event in agent.run(task_input):
        yield event
