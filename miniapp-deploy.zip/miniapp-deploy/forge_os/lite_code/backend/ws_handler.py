"""
WebSocket 处理 - 实时推送 agent 执行事件
"""
import asyncio
import json
import traceback
from typing import Any, Dict, Optional
from uuid import uuid4

from fastapi import WebSocket, WebSocketDisconnect

from common.agent_framework.user_interface.events import Event
from common.agent_framework.user_interface.content_blocks import (
    TextBlock, ToolCallBlock, ToolResultBlock, ThinkingBlock,
)
from common.agent_framework.message_store import MessageStore

from .agent_runner import create_agent, run_task
from .workspace import load_workspace, get_db_path


class ConnectionManager:
    """WebSocket 连接管理"""

    def __init__(self):
        self._active: Dict[str, WebSocket] = {}

    async def connect(self, websocket: WebSocket, connection_id: str):
        await websocket.accept()
        self._active[connection_id] = websocket

    def disconnect(self, connection_id: str):
        self._active.pop(connection_id, None)

    async def send_json(self, connection_id: str, data: Dict[str, Any]):
        ws = self._active.get(connection_id)
        if ws:
            await ws.send_json(data)


manager = ConnectionManager()


def _event_to_dict(event: Event) -> Dict[str, Any]:
    """将 Event 转换为可序列化的 dict"""
    content_list = []
    for block in event.content:
        if isinstance(block, TextBlock):
            content_list.append({"type": "text", "text": block.text})
        elif isinstance(block, ThinkingBlock):
            content_list.append({"type": "thinking", "text": block.thinking})
        elif isinstance(block, ToolCallBlock):
            content_list.append({
                "type": "tool_call",
                "tool_name": block.tool_name,
                "tool_input": block.tool_input,
                "call_id": block.call_id,
            })
        elif isinstance(block, ToolResultBlock):
            content_list.append({
                "type": "tool_result",
                "tool_name": block.tool_name,
                "result": block.result if isinstance(block.result, str) else str(block.result)[:2000],
                "is_error": block.is_error,
                "call_id": block.call_id,
            })

    return {
        "type": "event",
        "event_id": event.event_id,
        "event_type": event.event_type,
        "content": content_list,
        "metadata": event.metadata,
    }


async def handle_websocket(websocket: WebSocket, workspace_name: str):
    """处理 WebSocket 连接的主循环"""
    connection_id = str(uuid4())
    await manager.connect(websocket, connection_id)

    ws_config = load_workspace(workspace_name)
    if not ws_config:
        await websocket.send_json({"type": "error", "message": f"Workspace '{workspace_name}' not found"})
        await websocket.close()
        return

    project_path = ws_config["project_path"]
    enabled_skills = ws_config.get("enabled_skills", [])

    agent = create_agent(
        workspace_path=project_path,
        enabled_skills=enabled_skills,
    )

    db_path = get_db_path(workspace_name)
    store = MessageStore(db_path=db_path)
    store.ensure_user(workspace_name)

    try:
        while True:
            raw = await websocket.receive_text()
            data = json.loads(raw)

            msg_type = data.get("type")
            if msg_type == "chat":
                await _handle_chat(
                    connection_id=connection_id,
                    data=data,
                    agent=agent,
                    store=store,
                    workspace_name=workspace_name,
                )
            elif msg_type == "ping":
                await manager.send_json(connection_id, {"type": "pong"})
    except WebSocketDisconnect:
        pass
    except Exception as e:
        try:
            await manager.send_json(connection_id, {
                "type": "error",
                "message": str(e),
                "traceback": traceback.format_exc(),
            })
        except Exception:
            pass
    finally:
        manager.disconnect(connection_id)
        store.close()


async def _handle_chat(
    connection_id: str,
    data: Dict[str, Any],
    agent,
    store: MessageStore,
    workspace_name: str,
):
    """处理用户 chat 消息"""
    session_id = data.get("session_id", "")
    content = data.get("content", "")

    if not session_id:
        await manager.send_json(connection_id, {"type": "error", "message": "session_id required"})
        return

    if not content:
        await manager.send_json(connection_id, {"type": "error", "message": "content required"})
        return

    user_content = [{"type": "text", "content": content}]
    round_idx = store.start_round(session_id, user_content)

    history = _load_history(store, session_id, exclude_round=round_idx)

    task_id = f"task_{uuid4().hex[:8]}"

    trajectory = []
    ai_text_parts = []

    await manager.send_json(connection_id, {
        "type": "status", "status": "running", "round_idx": round_idx,
    })

    loop = asyncio.get_event_loop()

    def _run_agent():
        events = []
        for event in run_task(
            agent=agent,
            session_id=session_id,
            task_id=task_id,
            user_message=content,
            history_messages=history,
        ):
            events.append(event)
        return events

    try:
        events = await loop.run_in_executor(None, _run_agent)
    except Exception as e:
        await manager.send_json(connection_id, {
            "type": "error", "message": f"Agent execution failed: {e}",
        })
        store.complete_round(session_id, round_idx, [{"type": "text", "content": f"Error: {e}"}])
        return

    for event in events:
        event_dict = _event_to_dict(event)
        await manager.send_json(connection_id, event_dict)
        trajectory.append(event_dict)

        if event.event_type == "reasoning":
            for block in event.content:
                if isinstance(block, TextBlock) and block.text:
                    ai_text_parts.append(block.text)

    ai_content = [{"type": "text", "content": "\n".join(ai_text_parts)}] if ai_text_parts else []
    store.complete_round(session_id, round_idx, ai_content, trajectory)

    await manager.send_json(connection_id, {
        "type": "status", "status": "complete", "round_idx": round_idx,
    })


def _load_history(store: MessageStore, session_id: str, exclude_round: int) -> list:
    """加载历史对话消息（用于构建 agent 上下文）"""
    rounds = store.get_rounds(session_id)
    history = []
    for rnd in rounds:
        if rnd.round_idx >= exclude_round:
            break
        if rnd.user_content:
            text_parts = [c["content"] for c in rnd.user_content if c.get("type") == "text"]
            if text_parts:
                history.append({"role": "user", "content": "\n".join(text_parts)})
        if rnd.ai_content:
            text_parts = [c["content"] for c in rnd.ai_content if c.get("type") == "text"]
            if text_parts:
                history.append({"role": "assistant", "content": "\n".join(text_parts)})
    return history
