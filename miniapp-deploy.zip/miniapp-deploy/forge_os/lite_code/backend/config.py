"""
配置管理 - ~/.lite_code 目录初始化与 config.json 读写
"""
import json
from pathlib import Path
from typing import Any, Dict, Optional


LITE_CODE_HOME = Path.home() / ".lite_code"
CONFIG_FILE = LITE_CODE_HOME / "config.json"
SKILLS_DIR = LITE_CODE_HOME / "skills"
WORKSPACE_DIR = LITE_CODE_HOME / "workspace"

DEFAULT_CONFIG: Dict[str, Any] = {
    "llm": {
        "provider": "claude",
        "api_key": "",
        "model": "claude-sonnet-4-20250514",
        "base_url": None,
    },
    "agent": {
        "max_iterations": 30,
        "max_tokens": 8192,
        "temperature": 0.7,
        "thinking_level": "medium",
    },
    "memory": {
        "l1": {
            "budget": {
                "max_total_tokens": 128000,
                "system_prompt_tokens": 4000,
                "memory_tokens": 4000,
                "react_stack_reserve": 10000,
                "final_output_reserve": 16000,
            },
            "history_collapse": {
                "thinking_collapse": {"type": "remove"},
                "tool_call_collapse": {"type": "none"},
                "tool_response_collapse": {
                    "type": "prefix",
                    "collapse_prefix_length": 200,
                },
            },
            "tool_response_collapse_whitelist": ["text_edit"],
        },
        "l2": {
            "history_collapse": {
                "thinking_collapse": {"type": "remove"},
                "tool_call_collapse": {"type": "remove"},
                "tool_response_collapse": {
                    "type": "prefix",
                    "collapse_prefix_length": 100,
                },
            },
            "after_collapse_max_length": 94000,
            "protected_steps": 1,
            "fallback_strategy": "abandon",
        },
    },
}


def ensure_directories() -> None:
    """确保 ~/.lite_code 及其子目录存在"""
    LITE_CODE_HOME.mkdir(parents=True, exist_ok=True)
    SKILLS_DIR.mkdir(exist_ok=True)
    WORKSPACE_DIR.mkdir(exist_ok=True)


def load_config() -> Dict[str, Any]:
    """加载配置，不存在则创建默认配置"""
    ensure_directories()
    if not CONFIG_FILE.exists():
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG.copy()
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_config(config: Dict[str, Any]) -> None:
    """保存配置到 config.json"""
    ensure_directories()
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def update_config(patch: Dict[str, Any]) -> Dict[str, Any]:
    """局部更新配置（浅合并顶层 key）"""
    config = load_config()
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(config.get(key), dict):
            config[key].update(value)
        else:
            config[key] = value
    save_config(config)
    return config


def get_llm_config(config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """提取 LLM 相关配置"""
    if config is None:
        config = load_config()
    return config.get("llm", DEFAULT_CONFIG["llm"])


def get_agent_config(config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """提取 Agent 相关配置"""
    if config is None:
        config = load_config()
    return config.get("agent", DEFAULT_CONFIG["agent"])


def get_memory_config(config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """提取 Memory 相关配置"""
    if config is None:
        config = load_config()
    return config.get("memory", DEFAULT_CONFIG["memory"])
