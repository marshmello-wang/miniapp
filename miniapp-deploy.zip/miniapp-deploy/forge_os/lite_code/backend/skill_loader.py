"""
Skill 加载器 - 扫描 ~/.lite_code/skills/ 并构建 SkillConfig
"""
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import SKILLS_DIR


def scan_skills(skills_dir: Optional[Path] = None) -> List[Dict[str, Any]]:
    """
    扫描 skills 目录，返回所有可用 skill 的元信息列表

    每个 skill 目录需包含 SKILL.md 文件。
    返回: [{"name": "...", "description": "...", "path": "..."}]
    """
    base = skills_dir or SKILLS_DIR
    if not base.exists():
        return []

    skills = []
    for entry in sorted(base.iterdir()):
        if not entry.is_dir():
            continue
        skill_md = entry / "SKILL.md"
        if not skill_md.exists():
            continue

        description = _extract_description(skill_md)
        skills.append({
            "name": entry.name,
            "description": description,
            "path": str(skill_md),
            "has_assets": (entry / "assets").is_dir(),
        })

    return skills


def _extract_description(skill_md: Path) -> str:
    """从 SKILL.md 中提取描述（第一个非标题、非空行，或首行标题去掉 #）"""
    try:
        content = skill_md.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return ""

    lines = content.strip().splitlines()
    if not lines:
        return ""

    first_line = lines[0].strip()
    if first_line.startswith("#"):
        return re.sub(r"^#+\s*", "", first_line)

    return first_line[:120]


def build_skill_config(
    enabled_skills: List[str],
    skills_dir: Optional[Path] = None,
) -> Optional[Dict[str, Any]]:
    """
    根据启用的 skill 列表构建 SkillConfig 参数

    返回可直接传入 ReactAgentConfig.skill_config 的 SkillConfig 构造参数。
    若没有启用任何 skill，返回 None。
    """
    if not enabled_skills:
        return None

    base = skills_dir or SKILLS_DIR
    skills_config: Dict[str, Any] = {}

    for skill_name in enabled_skills:
        skill_dir = base / skill_name
        skill_md = skill_dir / "SKILL.md"
        if not skill_md.exists():
            continue

        description = _extract_description(skill_md)
        skills_config[skill_name] = {
            "description": description,
            "content_file_path": "SKILL.md",
            "load_type": "static",
        }

    if not skills_config:
        return None

    return {
        "skills_config": skills_config,
        "base_path": str(base),
    }
