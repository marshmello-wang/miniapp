"""
Lite Code Backend - FastAPI 后端服务
"""
