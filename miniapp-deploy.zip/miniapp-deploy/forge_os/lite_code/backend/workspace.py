"""
工作区管理 - 加载项目目录、文件树生成、workspace 配置管理
"""
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import WORKSPACE_DIR


DEFAULT_IGNORE_PATTERNS = {
    ".git", "__pycache__", "node_modules", ".venv", "venv",
    ".DS_Store", ".idea", ".vscode", "dist", "build",
    "*.pyc", "*.pyo", ".egg-info",
}


def list_workspaces() -> List[Dict[str, Any]]:
    """列出所有已创建的工作区"""
    WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)
    workspaces = []
    for entry in sorted(WORKSPACE_DIR.iterdir()):
        if entry.is_dir():
            config_file = entry / "workspace.json"
            if config_file.exists():
                with open(config_file, "r", encoding="utf-8") as f:
                    config = json.load(f)
                workspaces.append({
                    "name": entry.name,
                    "project_path": config.get("project_path", ""),
                    "enabled_skills": config.get("enabled_skills", []),
                })
    return workspaces


def create_workspace(name: str, project_path: str) -> Dict[str, Any]:
    """创建新工作区"""
    ws_dir = WORKSPACE_DIR / name
    ws_dir.mkdir(parents=True, exist_ok=True)

    config = {
        "project_path": str(Path(project_path).resolve()),
        "enabled_skills": [],
    }
    config_file = ws_dir / "workspace.json"
    with open(config_file, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    return config


def load_workspace(name: str) -> Optional[Dict[str, Any]]:
    """加载工作区配置"""
    config_file = WORKSPACE_DIR / name / "workspace.json"
    if not config_file.exists():
        return None
    with open(config_file, "r", encoding="utf-8") as f:
        return json.load(f)


def save_workspace(name: str, config: Dict[str, Any]) -> None:
    """保存工作区配置"""
    ws_dir = WORKSPACE_DIR / name
    ws_dir.mkdir(parents=True, exist_ok=True)
    config_file = ws_dir / "workspace.json"
    with open(config_file, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def get_db_path(workspace_name: str) -> str:
    """获取 workspace 的 sessions.db 路径"""
    return str(WORKSPACE_DIR / workspace_name / "sessions.db")


def build_file_tree(
    root_path: str,
    max_depth: int = 4,
    ignore_patterns: Optional[set] = None,
) -> List[Dict[str, Any]]:
    """
    生成项目目录的文件树结构

    返回格式: [{"name": "src", "type": "dir", "children": [...]}, ...]
    """
    if ignore_patterns is None:
        ignore_patterns = DEFAULT_IGNORE_PATTERNS

    root = Path(root_path)
    if not root.exists() or not root.is_dir():
        return []

    return _scan_dir(root, max_depth, ignore_patterns, current_depth=0)


def _scan_dir(
    path: Path,
    max_depth: int,
    ignore_patterns: set,
    current_depth: int,
) -> List[Dict[str, Any]]:
    """递归扫描目录"""
    if current_depth >= max_depth:
        return []

    entries: List[Dict[str, Any]] = []

    try:
        items = sorted(path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
    except PermissionError:
        return []

    for item in items:
        if _should_ignore(item.name, ignore_patterns):
            continue

        if item.is_dir():
            children = _scan_dir(item, max_depth, ignore_patterns, current_depth + 1)
            entries.append({
                "name": item.name,
                "type": "dir",
                "path": str(item),
                "children": children,
            })
        elif item.is_file():
            entries.append({
                "name": item.name,
                "type": "file",
                "path": str(item),
                "size": item.stat().st_size,
            })

    return entries


def _should_ignore(name: str, patterns: set) -> bool:
    """判断文件/目录是否应被忽略"""
    if name in patterns:
        return True
    for pattern in patterns:
        if pattern.startswith("*") and name.endswith(pattern[1:]):
            return True
    return False


def read_file_content(file_path: str, start_line: Optional[int] = None, end_line: Optional[int] = None) -> str:
    """读取文件内容，可选指定行范围"""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    if not path.is_file():
        raise ValueError(f"Not a file: {file_path}")

    content = path.read_text(encoding="utf-8")

    if start_line is not None or end_line is not None:
        lines = content.splitlines(keepends=True)
        start = (start_line - 1) if start_line else 0
        end = end_line if end_line else len(lines)
        content = "".join(lines[start:end])

    return content
