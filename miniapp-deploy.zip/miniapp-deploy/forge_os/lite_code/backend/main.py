"""
Lite Code Backend - FastAPI 应用入口

启动方式:
    cd forge_os
    python -m lite_code.backend.main [--port 8690]
"""
import argparse
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from .config import ensure_directories
from .ws_handler import handle_websocket
from .routers.session_router import router as session_router
from .routers.workspace_router import router as workspace_router
from .routers.config_router import router as config_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    ensure_directories()
    yield


app = FastAPI(title="Lite Code", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(session_router, prefix="/api")
app.include_router(workspace_router, prefix="/api")
app.include_router(config_router, prefix="/api")


@app.websocket("/ws/{workspace_name}")
async def websocket_endpoint(websocket: WebSocket, workspace_name: str):
    await handle_websocket(websocket, workspace_name)


@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "lite_code"}


if __name__ == "__main__":
    import uvicorn

    parser = argparse.ArgumentParser(description="Lite Code Backend")
    parser.add_argument("--port", type=int, default=8690)
    parser.add_argument("--host", type=str, default="127.0.0.1")
    args = parser.parse_args()

    uvicorn.run(app, host=args.host, port=args.port)
