"""
Config API - 全局配置读写
"""
from typing import Any, Dict
from fastapi import APIRouter
from pydantic import BaseModel

from ..config import load_config, update_config

router = APIRouter(tags=["config"])


class UpdateConfigReq(BaseModel):
    patch: Dict[str, Any]


@router.get("/config")
async def api_get_config():
    config = load_config()
    masked = _mask_secrets(config)
    return {"config": masked}


@router.put("/config")
async def api_update_config(req: UpdateConfigReq):
    config = update_config(req.patch)
    masked = _mask_secrets(config)
    return {"config": masked}


def _mask_secrets(config: Dict[str, Any]) -> Dict[str, Any]:
    """隐藏敏感信息"""
    result = {}
    for key, value in config.items():
        if isinstance(value, dict):
            result[key] = _mask_secrets(value)
        elif key in ("api_key",) and isinstance(value, str) and len(value) > 8:
            result[key] = value[:4] + "..." + value[-4:]
        else:
            result[key] = value
    return result
