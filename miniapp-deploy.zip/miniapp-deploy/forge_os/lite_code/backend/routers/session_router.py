"""
Session CRUD API
"""
from typing import Any, Dict, List, Optional
from fastapi import APIRouter
from pydantic import BaseModel

from common.agent_framework.message_store import MessageStore
from ..workspace import get_db_path, load_workspace
from ..config import WORKSPACE_DIR

router = APIRouter(tags=["sessions"])


class CreateSessionReq(BaseModel):
    session_id: Optional[str] = None


def _get_store(workspace_name: str) -> MessageStore:
    db_path = get_db_path(workspace_name)
    return MessageStore(db_path=db_path)


@router.get("/workspace/{workspace_name}/sessions")
async def list_sessions(workspace_name: str):
    store = _get_store(workspace_name)
    try:
        store.ensure_user(workspace_name)
        sessions = store.list_sessions(workspace_name)
        return {
            "sessions": [
                {
                    "session_id": s.session_id,
                    "created_at": s.created_at,
                    "updated_at": s.updated_at,
                    "round_count": s.round_count,
                }
                for s in sessions
            ]
        }
    finally:
        store.close()


@router.post("/workspace/{workspace_name}/sessions")
async def create_session(workspace_name: str, req: CreateSessionReq):
    store = _get_store(workspace_name)
    try:
        sid = store.create_session(workspace_name, req.session_id)
        return {"session_id": sid}
    finally:
        store.close()


@router.delete("/workspace/{workspace_name}/sessions/{session_id}")
async def delete_session(workspace_name: str, session_id: str):
    store = _get_store(workspace_name)
    try:
        store._conn.execute(
            "DELETE FROM messages WHERE session_id = ?", (session_id,)
        )
        store._conn.execute(
            "DELETE FROM sessions WHERE session_id = ?", (session_id,)
        )
        store._conn.commit()
        return {"ok": True}
    finally:
        store.close()


@router.get("/workspace/{workspace_name}/sessions/{session_id}/rounds")
async def get_rounds(workspace_name: str, session_id: str):
    store = _get_store(workspace_name)
    try:
        rounds = store.get_rounds(session_id)
        return {
            "rounds": [
                {
                    "round_idx": r.round_idx,
                    "user_content": r.user_content,
                    "ai_content": r.ai_content,
                    "trajectory": r.trajectory,
                    "created_at": r.created_at,
                    "updated_at": r.updated_at,
                }
                for r in rounds
            ]
        }
    finally:
        store.close()
