"""
Workspace API - 工作区管理 + 文件树
"""
from typing import Any, Dict, List, Optional
from fastapi import APIRouter
from pydantic import BaseModel

from ..workspace import (
    list_workspaces,
    create_workspace,
    load_workspace,
    save_workspace,
    build_file_tree,
    read_file_content,
)
from ..skill_loader import scan_skills

router = APIRouter(tags=["workspace"])


class CreateWorkspaceReq(BaseModel):
    name: str
    project_path: str


class UpdateSkillsReq(BaseModel):
    enabled_skills: List[str]


@router.get("/workspaces")
async def api_list_workspaces():
    return {"workspaces": list_workspaces()}


@router.post("/workspaces")
async def api_create_workspace(req: CreateWorkspaceReq):
    config = create_workspace(req.name, req.project_path)
    return {"name": req.name, **config}


@router.get("/workspace/{name}")
async def api_get_workspace(name: str):
    config = load_workspace(name)
    if not config:
        return {"error": "Workspace not found"}, 404
    return {"name": name, **config}


@router.get("/workspace/{name}/files")
async def api_file_tree(name: str, max_depth: int = 4):
    config = load_workspace(name)
    if not config:
        return {"error": "Workspace not found"}, 404
    tree = build_file_tree(config["project_path"], max_depth=max_depth)
    return {"tree": tree}


@router.get("/workspace/{name}/file")
async def api_read_file(name: str, path: str, start_line: Optional[int] = None, end_line: Optional[int] = None):
    config = load_workspace(name)
    if not config:
        return {"error": "Workspace not found"}, 404
    try:
        content = read_file_content(path, start_line, end_line)
        return {"content": content, "path": path}
    except FileNotFoundError as e:
        return {"error": str(e)}, 404
    except ValueError as e:
        return {"error": str(e)}, 400


@router.put("/workspace/{name}/skills")
async def api_update_skills(name: str, req: UpdateSkillsReq):
    config = load_workspace(name)
    if not config:
        return {"error": "Workspace not found"}, 404
    config["enabled_skills"] = req.enabled_skills
    save_workspace(name, config)
    return {"ok": True, "enabled_skills": req.enabled_skills}


@router.get("/skills")
async def api_list_skills():
    """列出所有可用的 skills（来自 ~/.lite_code/skills/）"""
    skills = scan_skills()
    return {"skills": skills}
